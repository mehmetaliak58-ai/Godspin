#!/usr/bin/env bash
set -euo pipefail

GODSPIN_PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODSPIN_GODOT_BIN="${GODOT_BIN:-godot}"
GODSPIN_QA_RUN_DIR="$(mktemp -d "${TMPDIR:-/tmp}/godspin-visual-qa.XXXXXX")"
GODSPIN_X_PID=""
GODSPIN_LOG_DIR="${GODSPIN_PROJECT_DIR}/dist/qa"
mkdir -p "$GODSPIN_LOG_DIR"

cleanup() {
    if [[ -n "$GODSPIN_X_PID" ]]; then
        kill "$GODSPIN_X_PID" 2>/dev/null || true
        wait "$GODSPIN_X_PID" 2>/dev/null || true
    fi
    rm -rf "$GODSPIN_QA_RUN_DIR"
}
trap cleanup EXIT

# Fresh per-run userdata keeps screenshots at the default Ares / 100,000 chips.
export XDG_DATA_HOME="${GODSPIN_QA_RUN_DIR}/data"
export XDG_CONFIG_HOME="${GODSPIN_QA_RUN_DIR}/config"
export XDG_CACHE_HOME="${GODSPIN_QA_RUN_DIR}/cache"
export XDG_RUNTIME_DIR="${GODSPIN_QA_RUN_DIR}/run"
mkdir -p "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME" "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR"
export LIBGL_ALWAYS_SOFTWARE=1
export GALLIUM_DRIVER=llvmpipe
export GODSPIN_QA_CAPTURE=1

if [[ -n "${GODSPIN_DISPLAY:-}" ]]; then
    export DISPLAY="$GODSPIN_DISPLAY"
fi
if [[ -z "${DISPLAY:-}" ]]; then
    GODSPIN_DISPLAY_NUMBER="${GODSPIN_X_DISPLAY_NUMBER:-94}"
    export DISPLAY=":${GODSPIN_DISPLAY_NUMBER}"
    if command -v Xvfb >/dev/null 2>&1; then
        Xvfb "$DISPLAY" -screen 0 1280x1600x24 -ac -nolisten tcp >"${GODSPIN_LOG_DIR}/display.log" 2>&1 &
        GODSPIN_X_PID="$!"
    elif command -v Xorg >/dev/null 2>&1 && [[ -f /usr/lib/xorg/modules/drivers/dummy_drv.so ]]; then
        cat > "${GODSPIN_QA_RUN_DIR}/xorg-dummy.conf" <<'CONFIG'
Section "ServerLayout"
 Identifier "DummyLayout"
 Screen 0 "DummyScreen"
EndSection
Section "ServerFlags"
 Option "AutoAddDevices" "false"
 Option "AutoEnableDevices" "false"
EndSection
Section "Device"
 Identifier "DummyDevice"
 Driver "dummy"
 VideoRam 256000
EndSection
Section "Monitor"
 Identifier "DummyMonitor"
 HorizSync 30.0-1000.0
 VertRefresh 5.0-200.0
 Modeline "1280x1600" 180.00 1280 1360 1496 1712 1600 1601 1604 1640 -HSync +Vsync
EndSection
Section "Screen"
 Identifier "DummyScreen"
 Device "DummyDevice"
 Monitor "DummyMonitor"
 DefaultDepth 24
 SubSection "Display"
  Depth 24
  Modes "1280x1600"
 EndSubSection
EndSection
CONFIG
        # The X11 UNIX/abstract socket must be allowed by the execution sandbox.
        mkdir -p /tmp/.X11-unix
        Xorg "$DISPLAY" -config "${GODSPIN_QA_RUN_DIR}/xorg-dummy.conf" \
            -logfile "${GODSPIN_LOG_DIR}/Xorg.log" -ac -nolisten tcp -noreset \
            >"${GODSPIN_LOG_DIR}/display.log" 2>&1 &
        GODSPIN_X_PID="$!"
    else
        echo "Görsel yakalama için DISPLAY, Xvfb veya Xorg dummy sürücüsü gerekli." >&2
        exit 1
    fi

    # Fail quickly if the sandbox blocks the display socket.
    GODSPIN_DISPLAY_READY=0
    for attempt in {1..40}; do
        if ! kill -0 "$GODSPIN_X_PID" 2>/dev/null; then
            cat "${GODSPIN_LOG_DIR}/display.log" >&2
            echo "X11 başlatılamadı. Yerel ekran soketi izni gereken ortamda yeniden çalıştırın." >&2
            exit 1
        fi
        if [[ -S "/tmp/.X11-unix/X${GODSPIN_DISPLAY_NUMBER}" ]]; then
            GODSPIN_DISPLAY_READY=1
            break
        fi
        sleep 0.1
    done
    if [[ "$GODSPIN_DISPLAY_READY" != 1 ]]; then
        echo "X11 ekranı 4 saniye içinde hazır olmadı." >&2
        exit 1
    fi
fi

# Import uses a real Godot process but does not need the display.
timeout 60s "$GODSPIN_GODOT_BIN" --headless --audio-driver Dummy \
    --path "$GODSPIN_PROJECT_DIR" --editor --import --quit \
    >"${GODSPIN_LOG_DIR}/screenshot-import.log" 2>&1

# Rendering is real software OpenGL, not Godot's dummy headless renderer.
touch "${GODSPIN_QA_RUN_DIR}/capture-start"
timeout 30s "$GODSPIN_GODOT_BIN" --display-driver x11 --rendering-driver opengl3 \
    --rendering-method gl_compatibility --audio-driver Dummy \
    --path "$GODSPIN_PROJECT_DIR" --resolution 720x1280 -- --qa-screenshot \
    2>&1 | tee "${GODSPIN_LOG_DIR}/screenshots.log"

if rg -q 'SCRIPT ERROR:|Parse Error:|Failed to load script|save_png' "${GODSPIN_LOG_DIR}/screenshots.log"; then
    echo "Ekran görüntüsü çalıştırmasında hata bulundu." >&2
    exit 1
fi
for image in lobby slot; do
    test -s "${GODSPIN_PROJECT_DIR}/dist/${image}.png"
    test "${GODSPIN_PROJECT_DIR}/dist/${image}.png" -nt "${GODSPIN_QA_RUN_DIR}/capture-start"
    file "${GODSPIN_PROJECT_DIR}/dist/${image}.png"
done
echo "GODSPIN_VISUAL_CAPTURE_PASS: dist/lobby.png, dist/slot.png"
