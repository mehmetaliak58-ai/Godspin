#!/usr/bin/env bash
# Download authentic named releases; do not disable the session proxy or TLS.
set -euo pipefail
TASK_TOOLCHAIN_ROOT="${GODSPIN_TOOLCHAIN_ROOT:-/workspace/toolchain}"
TASK_DOWNLOAD_ROOT="$TASK_TOOLCHAIN_ROOT/downloads"
TASK_TEMPLATE_ROOT="$TASK_TOOLCHAIN_ROOT/xdg-data/godot/export_templates/4.6.3.stable"
TASK_SDK_ROOT="${ANDROID_SDK_ROOT:-$TASK_TOOLCHAIN_ROOT/android-sdk}"
TASK_TEMPLATE_FILE=Godot_v4.6.3-stable_export_templates.tpz
TASK_TEMPLATE_BASE=https://godot-releases.nbg1.your-objectstorage.com/4.6.3-stable
TASK_SDK_FILE=commandlinetools-linux-15859902_latest.zip
TASK_SDK_SHA256=4e4c464f145a7512b57d088ac6c278c03c9eea610886b35a5e0804e74eedf583

mkdir -p "$TASK_DOWNLOAD_ROOT" "$TASK_TEMPLATE_ROOT"
TASK_FREE_KB="$(df -Pk "$TASK_TOOLCHAIN_ROOT" | awk 'NR==2 {print $4}')"
if [[ "$TASK_FREE_KB" -lt 3145728 ]]; then
  printf 'Toolchain için en az 3 GiB boş disk gerekir.\n' >&2
  exit 4
fi
download() {
  local task_url="$1" task_dest="$2"
  if [[ -s "$task_dest" ]]; then return; fi
  printf 'İndiriliyor: %s\n' "$task_url"
  curl --fail --location --connect-timeout 12 --max-time 900 --continue-at - \
    --speed-time 30 --speed-limit 1024 --retry 0 "$task_url" --output "$task_dest.part"
  mv "$task_dest.part" "$task_dest"
}

# This storage host is the target of the export-templates link on the official
# https://godotengine.org/download/archive/4.6.3-stable/ page, verified 2026-10-08.
# SourceForge is unaffiliated and is deliberately not used.
download "$TASK_TEMPLATE_BASE/SHA512-SUMS.txt" "$TASK_DOWNLOAD_ROOT/Godot-4.6.3-SHA512-SUMS.txt"
download "$TASK_TEMPLATE_BASE/$TASK_TEMPLATE_FILE" "$TASK_DOWNLOAD_ROOT/$TASK_TEMPLATE_FILE"
python3 - "$TASK_DOWNLOAD_ROOT/$TASK_TEMPLATE_FILE" "$TASK_DOWNLOAD_ROOT/Godot-4.6.3-SHA512-SUMS.txt" <<'PY'
import hashlib, pathlib, sys
archive, sums = map(pathlib.Path, sys.argv[1:])
matching = [line.split()[0] for line in sums.read_text().splitlines()
            if len(line.split()) == 2 and line.split()[1].lstrip('*') == archive.name]
if len(matching) != 1 or len(matching[0]) != 128:
    raise SystemExit('Godot yayımlanan SHA-512 kaydı bulunamadı; template kullanılmayacak.')
with archive.open('rb') as stream:
    actual = hashlib.file_digest(stream, 'sha512').hexdigest()
if actual != matching[0]:
    raise SystemExit('Godot SHA-512 uyuşmuyor; template kullanılmayacak.')
print('Godot SHA-512 eşleşti:', actual)
PY
unzip -p "$TASK_DOWNLOAD_ROOT/$TASK_TEMPLATE_FILE" templates/android_debug.apk > "$TASK_TEMPLATE_ROOT/android_debug.apk.part"
unzip -p "$TASK_DOWNLOAD_ROOT/$TASK_TEMPLATE_FILE" templates/android_release.apk > "$TASK_TEMPLATE_ROOT/android_release.apk.part"
unzip -t "$TASK_TEMPLATE_ROOT/android_debug.apk.part" > /dev/null
unzip -t "$TASK_TEMPLATE_ROOT/android_release.apk.part" > /dev/null
mv "$TASK_TEMPLATE_ROOT/android_debug.apk.part" "$TASK_TEMPLATE_ROOT/android_debug.apk"
mv "$TASK_TEMPLATE_ROOT/android_release.apk.part" "$TASK_TEMPLATE_ROOT/android_release.apk"

# SDK download/use requires the explicit SDK license acceptance. No implicit yes.
if [[ "${GODSPIN_ACCEPT_ANDROID_SDK_LICENSE:-0}" != 1 ]]; then
  printf 'Godot templates hazır. Android SDK lisans kabulü eksik; SDK indirilmedi.\n' >&2
  printf 'Lisans: https://developer.android.com/studio#terms-and-conditions\n' >&2
  exit 3
fi
download "https://dl.google.com/android/repository/$TASK_SDK_FILE" "$TASK_DOWNLOAD_ROOT/$TASK_SDK_FILE"
printf '%s  %s\n' "$TASK_SDK_SHA256" "$TASK_DOWNLOAD_ROOT/$TASK_SDK_FILE" | sha256sum --check
mkdir -p "$TASK_SDK_ROOT/cmdline-tools" "$TASK_TOOLCHAIN_ROOT/android-user"
if [[ ! -x "$TASK_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]]; then
  unzip -q "$TASK_DOWNLOAD_ROOT/$TASK_SDK_FILE" -d "$TASK_SDK_ROOT/cmdline-tools"
  mv "$TASK_SDK_ROOT/cmdline-tools/cmdline-tools" "$TASK_SDK_ROOT/cmdline-tools/latest"
fi
export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-21-openjdk-amd64}"
export ANDROID_SDK_ROOT="$TASK_SDK_ROOT"
export ANDROID_USER_HOME="$TASK_TOOLCHAIN_ROOT/android-user"
export XDG_CONFIG_HOME="$TASK_TOOLCHAIN_ROOT/xdg-config"
export XDG_DATA_HOME="$TASK_TOOLCHAIN_ROOT/xdg-data"
export XDG_CACHE_HOME="$TASK_TOOLCHAIN_ROOT/xdg-cache"
TASK_JAVA_TRUST="$TASK_TOOLCHAIN_ROOT/java-cacerts"
if [[ -f "${CODEX_PROXY_CERT:-}" ]]; then
  cp "$JAVA_HOME/lib/security/cacerts" "$TASK_JAVA_TRUST"
  "$JAVA_HOME/bin/keytool" -importcert -noprompt -alias godspin-environment-proxy \
    -file "$CODEX_PROXY_CERT" -keystore "$TASK_JAVA_TRUST" -storepass changeit
  export JAVA_TOOL_OPTIONS="${JAVA_TOOL_OPTIONS:-} -Djavax.net.ssl.trustStore=$TASK_JAVA_TRUST"
fi
TASK_PROXY_ARGS=()
if [[ -n "${HTTPS_PROXY:-}" ]]; then
  read -r TASK_PROXY_HOST TASK_PROXY_PORT < <(python3 - <<'PY'
import os, urllib.parse
p = urllib.parse.urlparse(os.environ['HTTPS_PROXY'])
print(p.hostname, p.port or 80)
PY
)
  TASK_PROXY_ARGS=(--proxy=http "--proxy_host=$TASK_PROXY_HOST" "--proxy_port=$TASK_PROXY_PORT")
fi
TASK_ACCEPT_FILE="$TASK_TOOLCHAIN_ROOT/android-user/license-answers.txt"
python3 - "$TASK_ACCEPT_FILE" <<'PY'
import pathlib, sys
pathlib.Path(sys.argv[1]).write_text('y\n' * 100)
PY
"$TASK_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$TASK_SDK_ROOT" "${TASK_PROXY_ARGS[@]}" --licenses < "$TASK_ACCEPT_FILE"
"$TASK_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$TASK_SDK_ROOT" "${TASK_PROXY_ARGS[@]}" \
  'platform-tools' 'platforms;android-35' 'build-tools;35.0.1' < "$TASK_ACCEPT_FILE"
sha256sum "$TASK_TEMPLATE_ROOT"/*.apk "$TASK_DOWNLOAD_ROOT/$TASK_SDK_FILE" > "$TASK_DOWNLOAD_ROOT/INSTALLED-SHA256SUMS.txt"
python3 - "$TASK_DOWNLOAD_ROOT/DOWNLOAD-PROVENANCE.json" "$TASK_TEMPLATE_BASE/$TASK_TEMPLATE_FILE" "$TASK_SDK_FILE" "$TASK_SDK_SHA256" <<'PY'
import datetime, json, pathlib, sys
path, template_url, sdk_file, sdk_sha = sys.argv[1:]
pathlib.Path(path).write_text(json.dumps({
  'installed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'godot_release': '4.6.3.stable',
  'godot_primary_source': 'https://godotengine.org/download/archive/4.6.3-stable/',
  'godot_download': template_url,
  'godot_integrity': 'Verified SHA-512 from release SHA512-SUMS.txt before extraction',
  'android_cli_source': 'https://developer.android.com/studio#command-line-tools-only',
  'android_cli_download': 'https://dl.google.com/android/repository/' + sdk_file,
  'android_cli_published_sha256': sdk_sha,
  'android_sdk_license': 'https://developer.android.com/studio#terms-and-conditions',
  'android_sdk_license_accepted': True,
  'installed_packages': ['platform-tools', 'platforms;android-35', 'build-tools;35.0.1']
}, indent=2) + '\n')
PY
printf 'Godot template ve Android SDK kuruldu. Lisanslar: %s/licenses\n' "$TASK_SDK_ROOT"
