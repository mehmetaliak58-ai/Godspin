extends SceneTree

## Geometric layout audit only. This is not a renderer/screenshot test.
var failures := 0
var warnings: Array[String] = []

func _initialize() -> void:
	create_timer(20).timeout.connect(func():
		push_error("LAYOUT_FAIL: audit timed out")
		quit(2)
	)
	call_deferred("_run")

func _descendants(node: Node, buttons: Array[Button], labels: Array[Label]) -> void:
	for child in node.get_children():
		if child is Button and child.is_visible_in_tree():
			buttons.append(child)
		elif child is Label and child.is_visible_in_tree():
			labels.append(child)
		_descendants(child, buttons, labels)

func _run() -> void:
	var main: Control = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	if main.game == null or main.audio == null:
		push_error("LAYOUT_FAIL: main scene dependency failed to initialize")
		quit(2)
		return
	main.game.state.settings.reduced_motion = true
	for dimensions in [Vector2i(720, 1280), Vector2i(720, 1600)]:
		root.size = dimensions
		await process_frame
		await process_frame
		for screen in ["lobby", "slot"]:
			main.call("_show_" + screen)
			await process_frame
			await process_frame
			var buttons: Array[Button] = []
			var labels: Array[Label] = []
			_descendants(main, buttons, labels)
			var viewport_rect := root.get_visible_rect()
			var scope := "%s %s" % [screen, dimensions]
			for b in buttons:
				var rect := b.get_global_rect()
				if not viewport_rect.encloses(rect):
					failures += 1
					push_error("LAYOUT_FAIL %s: button '%s' outside %s: %s" % [scope, b.text, viewport_rect, rect])
			for i in buttons.size():
				for j in range(i + 1, buttons.size()):
					if buttons[i].get_global_rect().intersects(buttons[j].get_global_rect()):
						failures += 1
						push_error("LAYOUT_FAIL %s: buttons overlap '%s' / '%s'" % [scope, buttons[i].text, buttons[j].text])
			for label in labels:
				if label.autowrap_mode != TextServer.AUTOWRAP_OFF or "\n" in label.text:
					continue
				var width := label.get_theme_font("font").get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, label.get_theme_font_size("font_size")).x
				if width > label.size.x + 1:
					warnings.append("%s clipped label '%s': %.1f > %.1f" % [scope, label.text, width, label.size.x])
			print("LAYOUT_AUDIT ", scope, " viewport=", viewport_rect.size, " visible_buttons=", buttons.size())
	for warning in warnings:
		print("LAYOUT_WARNING ", warning)
	main.audio.stop_all()
	await create_timer(0.1).timeout
	main.queue_free()
	await process_frame
	await process_frame
	print("UI_LAYOUT_RESULT failures=", failures, " text_warnings=", warnings.size(), " rendering_verified=false")
	quit(1 if failures > 0 else 0)
