#!/usr/bin/env bash
set -euo pipefail

# Each suite has separate Godot userdata and test-save paths.
# Logs remain reviewable; temporary save files are removed after the run.
GODSPIN_PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODSPIN_GODOT_BIN="${GODOT_BIN:-godot}"
GODSPIN_REPORT_DIR="${GODSPIN_QA_REPORT_DIR:-${GODSPIN_PROJECT_DIR}/dist/qa}"
GODSPIN_RUN_DIR="$(mktemp -d "${TMPDIR:-/tmp}/godspin-qa.XXXXXX")"
trap 'rm -rf "$GODSPIN_RUN_DIR"' EXIT
mkdir -p "$GODSPIN_REPORT_DIR"

if ! command -v "$GODSPIN_GODOT_BIN" >/dev/null 2>&1; then
    echo "Godot 4.x bulunamadı. GODOT_BIN değişkenini ayarlayın." >&2
    exit 1
fi

godspin_prepare_suite() {
    local suite="$1"
    export XDG_DATA_HOME="${GODSPIN_RUN_DIR}/${suite}/data"
    export XDG_CONFIG_HOME="${GODSPIN_RUN_DIR}/${suite}/config"
    export XDG_CACHE_HOME="${GODSPIN_RUN_DIR}/${suite}/cache"
    export GODSPIN_TEST_DIR="${GODSPIN_RUN_DIR}/${suite}/saves"
    mkdir -p "$XDG_DATA_HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME" "$GODSPIN_TEST_DIR"
}

godspin_run() {
    local suite="$1"
    shift
    godspin_prepare_suite "$suite"
    echo "TEST: ${suite}"
    timeout 180s "$GODSPIN_GODOT_BIN" --headless --path "$GODSPIN_PROJECT_DIR" "$@" 2>&1 | tee "${GODSPIN_REPORT_DIR}/${suite}.log"
    if rg -q 'SCRIPT ERROR:|Parse Error:|Failed to load script|FAIL:' "${GODSPIN_REPORT_DIR}/${suite}.log"; then
        echo "${suite}: hata çıktısı bulundu." >&2
        return 1
    fi
}

godspin_run import --editor --import --quit
godspin_run engine --script res://tests/test_slot_engine.gd
rg -q '"failed":0' "${GODSPIN_REPORT_DIR}/engine.log"
godspin_run meta --script res://tests/test_meta.gd
rg -q '0 failures' "${GODSPIN_REPORT_DIR}/meta.log"
godspin_run ui -- --qa-smoke
rg -q 'UI_SMOKE_PASS' "${GODSPIN_REPORT_DIR}/ui.log"
godspin_run reel --script res://tests/test_reel_visual.gd
rg -q '"failures":0' "${GODSPIN_REPORT_DIR}/reel.log"
godspin_run vfx --script res://tests/test_vfx_upgrade.gd
rg -q 'VFX_UPGRADE_PASS' "${GODSPIN_REPORT_DIR}/vfx.log"
godspin_run layout --script res://tests/test_ui_layout.gd
rg -q '0 failures' "${GODSPIN_REPORT_DIR}/layout.log"
echo "GODSPIN_QA_PASS: motor, meta, arayüz, makara, sinematik ve ekran geometrisi. Loglar: ${GODSPIN_REPORT_DIR}"
