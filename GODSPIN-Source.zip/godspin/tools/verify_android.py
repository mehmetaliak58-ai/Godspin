#!/usr/bin/env python3
"""Validate the built artifact rather than trusting export success."""
import pathlib
import json
import re
import subprocess
import sys
import zipfile

apk = pathlib.Path(sys.argv[1])
aapt = sys.argv[2]
with zipfile.ZipFile(apk) as archive:
    if archive.testzip() is not None:
        raise SystemExit('APK ZIP bütünlüğü başarısız.')
    files = set(archive.namelist())
    for required in ('AndroidManifest.xml', 'classes.dex', 'lib/arm64-v8a/libgodot_android.so'):
        if required not in files:
            raise SystemExit(f'APK bileşeni eksik: {required}')
    project_markers = files.intersection({'assets/project.binary', 'assets/project.godot'})
    packs = [name for name in files if name.startswith('assets/') and name.endswith('.pck')]
    if not project_markers and not packs:
        raise SystemExit('GODSPIN proje içeriği yok; boş Godot template oyun APK olarak kabul edilmez.')
    if project_markers:
        if not any(archive.getinfo(name).file_size > 0 for name in project_markers):
            raise SystemExit('APK proje yapılandırması boş.')
        character_path = 'assets/data/characters.json'
        if character_path not in files:
            raise SystemExit('APK karakter verisi eksik.')
        characters = json.loads(archive.read(character_path))
        if not isinstance(characters, list) or len(characters) != 8:
            raise SystemExit('APK sekiz karakterin gerçek verisini içermiyor.')
        expected_slots = {
            'golden_empire': 3, 'neon_chaos': 3, 'gods_of_thunder': 4,
            'joker_madness': 3, 'empress_treasure': 4, 'cosmic_infinity': 3,
        }
        for slot_id, rows in expected_slots.items():
            slot_path = f'assets/data/slots/{slot_id}.json'
            if slot_path not in files:
                raise SystemExit(f'APK slot verisi eksik: {slot_id}')
            slot = json.loads(archive.read(slot_path))
            if slot.get('id') != slot_id or slot.get('columns') != 5 or slot.get('rows') != rows:
                raise SystemExit(f'APK slot konfigürasyonu hatalı: {slot_id}')
            if not slot.get('weights') or not slot.get('paytable'):
                raise SystemExit(f'APK slot matematiği eksik: {slot_id}')
        if not any(name.startswith('assets/scenes/main.') for name in files):
            raise SystemExit('APK ana oyun sahnesi eksik.')
        textures = [name for name in files if name.startswith('assets/') and
                    name.endswith(('.ctex', '.webp', '.png', '.svg'))]
        if len(textures) < 8:
            raise SystemExit('APK karakter ve sahne texture içeriği yetersiz.')
        payload_validation = 'ana sahne, 8 karakter, 6 slot matematiği ve texture içerikleri okundu'
    else:
        # Native Godot export normally uses loose assets. If a different export
        # wraps them in a PCK, validate its real header without pretending to
        # have decoded and inspected the packed game configuration.
        valid_packs = [name for name in packs if archive.getinfo(name).file_size > 1024 and
                       archive.read(name)[:4] == b'GDPC']
        if not valid_packs:
            raise SystemExit('APK geçerli Godot PCK proje paketi içermiyor.')
        payload_validation = 'Godot PCK başlığı doğrulandı; paket içi JSON içerikleri doğrudan denetlenmedi'

badging = subprocess.check_output([aapt, 'dump', 'badging', str(apk)], text=True)
permissions = subprocess.check_output([aapt, 'dump', 'permissions', str(apk)], text=True)
manifest = subprocess.check_output([aapt, 'dump', 'xmltree', str(apk), 'AndroidManifest.xml'], text=True)
if "package: name='com.godspin.empireoffortune'" not in badging:
    raise SystemExit('APK paket adı yanlış.')
if 'launchable-activity:' not in badging:
    raise SystemExit('APK açılış etkinliği yok.')
if 'android.permission.INTERNET' in permissions or 'android.permission.ACCESS_NETWORK_STATE' in permissions:
    raise SystemExit('Offline APK ağ izni içeriyor.')
# ActivityInfo.SCREEN_ORIENTATION_PORTRAIT == 1, SENSOR_PORTRAIT == 7.
orientation_lines = [line for line in manifest.splitlines() if 'screenOrientation' in line]
if not orientation_lines or not any(re.search(r'\(type 0x10\)0x(?:1|7)\b', line) for line in orientation_lines):
    raise SystemExit('Dikey ekran yönü APK manifestinde doğrulanamadı.')
print(badging.splitlines()[0])
print('Oyun içeriği:', payload_validation)
print(f'APK doğrulandı: ZIP, arm64, açılış etkinliği, dikey yön, offline izinler; {apk.stat().st_size:,} bayt.')
