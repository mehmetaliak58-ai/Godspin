#!/usr/bin/env bash
# Offline native Godot Android export; does not fetch tools or change HOME.
set -euo pipefail

TASK_PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
TASK_TOOLCHAIN_ROOT="${GODSPIN_TOOLCHAIN_ROOT:-/workspace/toolchain}"
TASK_GODOT_BIN="${GODOT_BIN:-$(command -v godot || true)}"
TASK_SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$TASK_TOOLCHAIN_ROOT/android-sdk}}"
TASK_JAVA_ROOT="${JAVA_HOME:-/usr/lib/jvm/java-21-openjdk-amd64}"
TASK_TEMPLATE_ROOT="${GODOT_TEMPLATE_DIR:-$TASK_TOOLCHAIN_ROOT/xdg-data/godot/export_templates/4.6.3.stable}"
TASK_OUTPUT="${GODSPIN_APK_PATH:-$TASK_PROJECT_ROOT/dist/GODSPIN-EmpireOfFortune.apk}"
TASK_KEYSTORE="$TASK_TOOLCHAIN_ROOT/debug.keystore"
TASK_CONFIG_ROOT="$TASK_TOOLCHAIN_ROOT/xdg-config"
TASK_DATA_ROOT="$TASK_TOOLCHAIN_ROOT/xdg-data"
TASK_CACHE_ROOT="$TASK_TOOLCHAIN_ROOT/xdg-cache"

TASK_MISSING=0
require_file() {
  if [[ ! -f "$1" ]]; then printf 'Eksik: %s\n' "$1" >&2; TASK_MISSING=1; fi
}
if [[ -z "$TASK_GODOT_BIN" || ! -x "$TASK_GODOT_BIN" ]]; then
  printf 'Eksik: Godot 4.6.3 (GODOT_BIN ile seçilebilir).\n' >&2
  TASK_MISSING=1
fi
require_file "$TASK_JAVA_ROOT/bin/java"
require_file "$TASK_JAVA_ROOT/bin/keytool"
require_file "$TASK_TEMPLATE_ROOT/android_debug.apk"
require_file "$TASK_TEMPLATE_ROOT/android_release.apk"
require_file "$TASK_SDK_ROOT/platform-tools/adb"
require_file "$TASK_SDK_ROOT/platforms/android-35/android.jar"
require_file "$TASK_SDK_ROOT/build-tools/35.0.1/aapt"
require_file "$TASK_SDK_ROOT/build-tools/35.0.1/apksigner"
require_file "$TASK_SDK_ROOT/build-tools/35.0.1/zipalign"
if [[ "$TASK_MISSING" != 0 ]]; then
  printf 'APK üretilmedi. Kurulum adımları: %s/docs/ANDROID.md\n' "$TASK_PROJECT_ROOT" >&2
  exit 2
fi

TASK_GODOT_VERSION="$("$TASK_GODOT_BIN" --version 2>/dev/null)"
if [[ "$TASK_GODOT_VERSION" != 4.6.3.stable* ]]; then
  printf 'Bu preset Godot 4.6.3 gerektirir; bulunan sürüm: %s\n' "$TASK_GODOT_VERSION" >&2
  exit 2
fi
mkdir -p "$TASK_CONFIG_ROOT/godot" "$TASK_DATA_ROOT/godot/export_templates/4.6.3.stable" "$TASK_CACHE_ROOT" "$(dirname -- "$TASK_OUTPUT")"
export XDG_CONFIG_HOME="$TASK_CONFIG_ROOT"
export XDG_DATA_HOME="$TASK_DATA_ROOT"
export XDG_CACHE_HOME="$TASK_CACHE_ROOT"
export JAVA_HOME="$TASK_JAVA_ROOT"
export ANDROID_SDK_ROOT="$TASK_SDK_ROOT"
export PATH="$TASK_JAVA_ROOT/bin:$TASK_SDK_ROOT/platform-tools:$TASK_SDK_ROOT/build-tools/35.0.1:$PATH"

# Godot's native APK export only needs the debug template.
if [[ "$TASK_TEMPLATE_ROOT" != "$TASK_DATA_ROOT/godot/export_templates/4.6.3.stable" ]]; then
  cp "$TASK_TEMPLATE_ROOT/android_debug.apk" "$TASK_DATA_ROOT/godot/export_templates/4.6.3.stable/android_debug.apk"
  cp "$TASK_TEMPLATE_ROOT/android_release.apk" "$TASK_DATA_ROOT/godot/export_templates/4.6.3.stable/android_release.apk"
fi
if [[ ! -f "$TASK_KEYSTORE" ]]; then
  "$TASK_JAVA_ROOT/bin/keytool" -genkeypair -keystore "$TASK_KEYSTORE" \
    -alias androiddebugkey -storepass android -keypass android \
    -dname 'CN=Android Debug,O=GODSPIN,C=TR' -keyalg RSA -keysize 2048 -validity 10000
fi

TASK_EDITOR_SETTINGS="$TASK_CONFIG_ROOT/godot/editor_settings-4.6.tres"
python3 - "$TASK_EDITOR_SETTINGS" "$TASK_SDK_ROOT" "$TASK_JAVA_ROOT" "$TASK_KEYSTORE" <<'PY'
import json, pathlib, sys
path, sdk, java, keystore = sys.argv[1:]
pathlib.Path(path).write_text(
    '[gd_resource type="EditorSettings" format=3]\n\n[resource]\n' +
    'export/android/android_sdk_path = ' + json.dumps(sdk) + '\n' +
    'export/android/java_sdk_path = ' + json.dumps(java) + '\n' +
    'export/android/debug_keystore = ' + json.dumps(keystore) + '\n' +
    'export/android/debug_keystore_user = "androiddebugkey"\n' +
    'export/android/debug_keystore_pass = "android"\n', encoding='utf-8')
PY

"$TASK_GODOT_BIN" --headless --path "$TASK_PROJECT_ROOT" --editor --import --quit
"$TASK_GODOT_BIN" --headless --path "$TASK_PROJECT_ROOT" --export-debug Android "$TASK_OUTPUT"
test -s "$TASK_OUTPUT"
"$TASK_SDK_ROOT/build-tools/35.0.1/apksigner" verify --verbose "$TASK_OUTPUT"
python3 "$TASK_PROJECT_ROOT/tools/verify_android.py" "$TASK_OUTPUT" "$TASK_SDK_ROOT/build-tools/35.0.1/aapt"
if [[ "$TASK_OUTPUT" == "$TASK_PROJECT_ROOT/dist/GODSPIN-EmpireOfFortune.apk" ]]; then
  cp "$TASK_OUTPUT" "$TASK_PROJECT_ROOT/dist/GODSPIN.apk"
fi
sha256sum "$TASK_OUTPUT"
printf 'Doğrulanan debug APK: %s\n' "$TASK_OUTPUT"
