# GODSPIN: EMPIRE OF FORTUNE

Godot **4.6.3** ile geliştirilmiş, dikey ekranlı, Türkçe ve çevrimdışı çalışan tek oyunculu fantasy arcade slot oyunu. Başlangıç bakiyesi **100.000 sanal çip**tir. Gerçek para, çip satın alma, nakit çekme, reklam zorunluluğu veya gerçek para ödülü bulunmaz.

Bu teslim gerçek oyun dosyaları, özgün görsel kaynaklar, sentezlenmiş sesler ve çalıştırılmış testler içerir. Sekiz karakter ile altı salonun veri ve mekanikleri uygulanmıştır. Karakterler 2D illüstrasyonlar, katman hareketleri ve karaktere özel prosedürel güç efektleriyle sunulur. Tam 3D karakter rigleri, elle hazırlanmış iskelet animasyonları ve profesyonel seslendirme bu sürümde yoktur; ticari bir mobil oyunun tüm görsel ve cihaz kalite güvencesi tamamlanmış gibi sunulmaz.

## Çalıştırma

1. Godot 4.6.3'ü kurun.
2. Godot proje yöneticisinde bu klasördeki `project.godot` dosyasını içe aktarın.
3. Projeyi açıp **F5** ile ana oyunu çalıştırın.

Komut satırından, proje klasöründe:

```bash
godot --path . --editor
godot --path .
```

Görüntüleme **GL Compatibility** kullanır; tasarım alanı 720×1280, ekran yönü diktir. Kaynak paketindeki `assets/` klasörünü koruyun; oyun görselleri, sesler ve Türkçe yazı tipleri bu klasörden yüklenir.

## Android APK

Hedef paket: `com.godspin.empireoffortune`.

Hedef dosya: `dist/GODSPIN-EmpireOfFortune.apk`.

```bash
bash tools/build_android.sh
```

SDK, JDK, export template kurulumu, derleme sonucu, paket doğrulaması ve cihaz testi durumu için [Android talimatlarını](docs/ANDROID.md) okuyun. Üretilen APK test amaçlı **debug** imzalıdır. Üretim yayını için kullanıcıya ait yayın anahtarı ve ayrı yayın kontrolleri gerekir.

**Bu oturumda APK oluşmadı.** SDK ve Android şablonu indirmelerini çalışma ortamının komut ağ izni engelledi. [Resmî kaynak ve checksum kullanan kurulum betiği](tools/bootstrap_android.sh) ve [elle çalıştırılabilir GitHub Actions alternatifi](.github/workflows/android.yml) hazırlanmıştır; uzak build gönderilmemiş veya çalıştırılmamıştır.

APK teslim dosyasında mevcutsa Android telefonunuza kopyalayın, dosyayı açın ve gerektiğinde kullandığınız dosya yöneticisine uygulama kurma izni verin. ADB ile kurulum:

```bash
adb install -r dist/GODSPIN-EmpireOfFortune.apk
```

Oyunun çalışması için internet bağlantısı gerekmez. Android derleme araçlarının ilk kurulumu ayrı bir geliştirme işlemi olabilir.

## Oynama

- Lobiden **Salona Gir** ile Altın İmparatorluğu'nu açın. İlk dönüş birkaç dokunuşla başlar.
- **ÇEVİR** gerçek RNG sonucunu hesaplar ve makaralarda gösterir. **− / +** bahis tutarını değiştirir.
- **OTOMATİK** 25 dönüşlük bir seri açar; aynı kontrol seriyi durdurur. Yetersiz bakiye durumunda otomatik oyun durur.
- **TURBO** makara animasyonlarını kısaltır.
- Güç göstergesi 100 olduğunda kahramanın **tanrısal gücüne** basın. Sinematik geçişten sonra üç ücretsiz güç dönüşü açılır. Uzun güç ve büyük kazanç gösterilerini atlayabilirsiniz; atlamak sonucu değiştirmez.
- **Kahramanlar**, **Görevler ve ödüller**, **Profil ve başarımlar**, **Kozmetik koleksiyonu** ve **Ayarlar** işlevlidir.
- Slot ekranındaki ödeme tablosu ve geçmiş, gerçek kuralları ve son 30 dönüşü gösterir.
- Ücretsiz ve güç dönüşleri boyunca bahis, karakter ve salon sabittir; kayıt yüklenirken de korunur.

## İlerleme ve ayarlar

Normal dönüşler güç enerjisi ve XP verir. Günlük görev ödülünü almak 10 ek güç enerjisi verir. Ares ve Luna başlangıçta açıktır; diğer karakterler 2–7. seviyelerde, diğer salonlar 2–6. seviyelerde açılır. Her yeni genel seviye **2.500 × yeni seviye** sanal çip verir; bu ödül slot kazancından ayrı gösterilir. Seraphine'in görev, başarım ve seviye ödülü avantajı uygulanır.

Salon statüsü 1. seviyede **Altın Salon**, 5. seviyede **Kraliyet Salonu**, 10. seviyede **Kozmik Saray** olur. Bunlar ortak lobinin ilerleme unvanlarıdır; ayrı gezilebilir 3D dünyalar değildir.

Bakiyeniz 10.000 çipin altındaysa ayarlardan **Ücretsiz Toparlanma** ile 25.000 çip alabilirsiniz. Ödeme, reklam ve bekleme süresi yoktur. Kozmetikler sanal çiple alınır veya başarımlardan kazanılır; portre çerçevesi ve aura değiştirir, kazanma olasılığını değiştirmez.

**Düşük / Orta / Yüksek / Ultra** profilleri efekt yoğunluğunu, hareketli arka plan ayrıntılarını ve aura shader'ını gerçekten değiştirir. **30 / 60 FPS**, bağımsız ses/müzik açma-kapama ve **azaltılmış efekt ve hareket** seçenekleri bulunur. 60 FPS hedefi gerçek telefonlarda ölçülmüş bir performans garantisi değildir.

Kayıt otomatik olarak Godot'un yerel `user://` alanına yazılır. Geçici dosya, doğrulama ve yedek ile güvenli kayıt yapılır; bozuk ana kayıt geçerli yedekten kurtarılabilir. Uygulamayı kaldırmak yerel kaydı silebilir; bulut eşitlemesi bulunmaz.

## Testler ve belgeler

```bash
bash tools/run_tests.sh
```

Godot farklı bir konumdaysa:

```bash
GODOT_BIN=/tam/yol/godot bash tools/run_tests.sh
```

Testler kullanıcı oyun kaydına dokunmadan ayrı geçici dizinlerde çalışır; loglar `dist/qa/` altında saklanır. Motor: **600.319 kontrol / 100.002 simüle dönüş / 0 hata**. Meta sistemleri: **2.553 kontrol / 1.200 simüle dönüş / 0 hata**. Gerçek makara ve güç animasyonlarını bekleyen arayüz akış testi de geçmiştir. Bunlar fiziksel Android cihaz testi ve görsel kalite onayı değildir.

- [Tamamlananlar ve sınırlar](docs/FEATURES.md)
- [Test raporu](docs/TEST_REPORT.md)
- [Salon matematiği ve olasılıklar](docs/SLOT_MATH.md)
- [Motor simülasyon raporu](docs/ENGINE_TEST_REPORT.md)
- [Android derleme ve kurulum](docs/ANDROID.md)
- [Görsel üretim kayıtları](assets/ART_NOTES.md)
- [Yazı tipleri ve SVG kaynakları](docs/ASSETS.md)
- [Görsel yükseltme ve doğrulama](docs/VISUAL_UPGRADE.md)
- [İnternet kaynakları ve lisanslar](ASSET_CREDITS.md)

## Proje yapısı

```text
project.godot          Godot proje ayarları
scenes/               Ana oyun sahnesi
scripts/core/         Matematik, ekonomi, kayıt, görev, karakter ve ses sistemleri
scripts/ui/           Lobi, mobil arayüz, makara gösterimi ve arka plan
scripts/vfx/          Karaktere özel güç ve kazanç efektleri
data/characters.json  Sekiz karakterin açıklamaları ve kilit seviyeleri
data/slots/           Altı ayrı salon matematiği yapılandırması
assets/               Portreler, atlaslar, salonlar, semboller, sesler, yazı tipleri
shaders/              Aura shader'ı
tests/                Bağımsız motor ve meta testleri
tools/                Yeniden üretilebilir test ve Android derleme betikleri
docs/                 Kurallar, testler, kaynak ve kurulum belgeleri
dist/                 Derleme çıktıları ve QA logları
```
