class_name EconomyManager
extends RefCounted

const BETS := [100, 500, 1000, 5000, 10000, 25000, 100000, 500000, 1000000]
const MAX_BALANCE := 9000000000000000

static func bet(state: Dictionary) -> int:
	return int(BETS[clampi(int(state.get("bet_index", 1)), 0, BETS.size() - 1)])

static func max_bet_index(state: Dictionary) -> int:
	return mini(BETS.size() - 1, 2 + int((CharacterManager.level(state) - 1) / 2))

static func can_spin(state: Dictionary) -> bool:
	return int(state.get("free_spins", 0)) > 0 or int(state.get("bonus_remaining", 0)) > 0 or int(state.get("balance", 0)) >= bet(state)

static func credit(state: Dictionary, amount: int) -> int:
	var old := int(state.get("balance", 0))
	state["balance"] = clampi(old + maxi(0, amount), 0, MAX_BALANCE)
	return int(state["balance"]) - old

static func rescue(state: Dictionary) -> int:
	if int(state.get("balance", 0)) >= 10000:
		return 0
	state["rescue_count"] = int(state.get("rescue_count", 0)) + 1
	return credit(state, 25000)

static func cosmetics() -> Array:
	return [
		{"id": "royal_frame", "title": "İmparatorluk Çerçevesi", "description": "Portre çevresinde çift altın hale.", "price": 15000, "level": 1},
		{"id": "starlight_aura", "title": "Yıldız Tozu Aurası", "description": "Karakter etrafında kozmik yıldız parçacıkları.", "price": 50000, "level": 2},
		{"id": "divine_glow", "title": "Tanrısal Işıltı", "description": "Karakter çevresinde parlak bir güç halkası.", "price": 150000, "level": 4}
	]

static func purchase(state: Dictionary, id: String) -> bool:
	for item in cosmetics():
		if str(item["id"]) != id:
			continue
		if id in state.get("cosmetics", []) or CharacterManager.level(state) < int(item["level"]) or int(state["balance"]) < int(item["price"]):
			return false
		state["balance"] = int(state["balance"]) - int(item["price"])
		state["cosmetics"].append(id)
		state["active_cosmetic"] = id
		return true
	return false
