class_name GodspinAudio
extends Node
## Original offline procedural audio; no speech recordings or external copyrighted samples.
const ROOT := "res://assets/audio/"
const CHARACTER_IDS: Array[String] = ["ares", "luna", "vex", "noctis", "kael", "seraphine", "dante", "orion"]
const SLOT_ALIASES := {"golden": "golden_empire", "neon": "neon_chaos", "thunder": "gods_of_thunder", "joker": "joker_madness", "empress": "empress_treasure", "cosmic": "cosmic_infinity"}
var _voices: Array[AudioStreamPlayer] = []
var _ambience_player: AudioStreamPlayer
var _next_voice := 0
var _music_volume := 0.45
var _sfx_volume := 0.65
var _music_enabled := true
var _sfx_enabled := true
var _slot := ""
var _cache: Dictionary = {}

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ambience_player = AudioStreamPlayer.new()
	_ambience_player.name = "SlotAmbiyansi"
	add_child(_ambience_player)
	for i in range(8):
		var voice := AudioStreamPlayer.new()
		voice.name = "Efekt%d" % i
		add_child(voice)
		_voices.append(voice)
	_apply_volumes()

func configure(settings: Dictionary) -> void:
	_music_volume = clampf(float(settings.get("music_volume", 0.45)), 0.0, 1.0)
	_sfx_volume = clampf(float(settings.get("sfx_volume", 0.65)), 0.0, 1.0)
	_music_enabled = bool(settings.get("music_enabled", settings.get("music", true)))
	_sfx_enabled = bool(settings.get("sfx_enabled", settings.get("sound", true)))
	_apply_volumes()
	if not _music_enabled and _ambience_player != null:
		_ambience_player.stop()
	elif _slot != "" and _ambience_player != null and not _ambience_player.playing:
		var old_slot := _slot
		_slot = ""
		ambience(old_slot)

func play(cue: String, character_id: String = "ares") -> void:
	if not _sfx_enabled or _sfx_volume <= 0.001 or _voices.is_empty():
		return
	var id := character_id.to_lower()
	if not CHARACTER_IDS.has(id):
		id = "ares"
	var file_name := cue
	if cue == "ultimate" or cue == "ready":
		file_name += "_" + id
	var stream := _get_stream(file_name)
	if stream == null:
		return
	var player := _voices[_next_voice]
	_next_voice = (_next_voice + 1) % _voices.size()
	player.stop()
	player.stream = stream
	player.pitch_scale = 1.0
	player.play()

func ambience(slot_id: String) -> void:
	if _ambience_player == null:
		return
	var id := slot_id.to_lower().replace(" ", "_")
	id = str(SLOT_ALIASES.get(id, id))
	if _slot == id and (_ambience_player.playing or not _music_enabled):
		return
	_slot = id
	_ambience_player.stop()
	var source := _get_stream("ambience_" + id)
	if source == null:
		source = _get_stream("ambience_golden_empire")
	if source == null:
		return
	var loop_stream := source.duplicate() as AudioStreamWAV
	if loop_stream != null:
		loop_stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		loop_stream.loop_begin = 0
		loop_stream.loop_end = int(loop_stream.get_length() * loop_stream.mix_rate)
		_ambience_player.stream = loop_stream
	else:
		_ambience_player.stream = source
	if _music_enabled and _music_volume > 0.001:
		_ambience_player.play()

func stop_ambience() -> void:
	_slot = ""
	if _ambience_player != null:
		_ambience_player.stop()

func stop_all() -> void:
	# Release active playback references before QA shutdown or a full audio reset.
	stop_ambience()
	if is_instance_valid(_ambience_player):
		_ambience_player.stream = null
	for voice in _voices:
		if is_instance_valid(voice):
			voice.stop()
			voice.stream = null
	_cache.clear()

func _exit_tree() -> void:
	stop_all()

func _get_stream(file_name: String) -> AudioStream:
	if _cache.has(file_name):
		return _cache[file_name]
	var path := ROOT + file_name + ".wav"
	if not ResourceLoader.exists(path):
		return null
	var stream := load(path) as AudioStream
	_cache[file_name] = stream
	return stream

func _apply_volumes() -> void:
	if _ambience_player != null:
		_ambience_player.volume_db = linear_to_db(maxf(_music_volume * 0.62, 0.0001))
	for voice in _voices:
		voice.volume_db = linear_to_db(maxf(_sfx_volume, 0.0001))
