class_name QuestManager
extends RefCounted

const DEFINITIONS := [
	{"id": "daily_spins", "title": "Talih Kapısı", "description": "Bugün 10 dönüş yap.", "stat": "spins", "target": 10, "reward": 10000},
	{"id": "daily_wins", "title": "Altın İzleri", "description": "Bugün toplam 15.000 sanal çip kazan.", "stat": "won", "target": 15000, "reward": 15000},
	{"id": "daily_power", "title": "Tanrısal Uyanış", "description": "Bugün bir Ultimate kullan.", "stat": "ultimates", "target": 1, "reward": 20000}
]

static func today() -> String:
	return Time.get_date_string_from_system(true)

static func refresh(state: Dictionary) -> void:
	if str(state.get("daily", {}).get("date", "")) != today():
		state["daily"] = {"date": today(), "spins": 0, "won": 0, "ultimates": 0, "claimed": []}

static func record(state: Dictionary, stat: String, amount: int) -> void:
	refresh(state)
	state["daily"][stat] = int(state["daily"].get(stat, 0)) + maxi(0, amount)

static func items(state: Dictionary) -> Array:
	refresh(state)
	var result: Array = []
	for definition in DEFINITIONS:
		var item: Dictionary = definition.duplicate(true)
		item["progress"] = mini(int(state["daily"].get(item["stat"], 0)), int(item["target"]))
		item["claimed"] = item["id"] in state["daily"].get("claimed", [])
		item["ready"] = int(item["progress"]) >= int(item["target"]) and not bool(item["claimed"])
		item["reward"] = int(int(item["reward"]) * CharacterManager.reward_multiplier(str(state.get("character", "ares"))))
		result.append(item)
	return result

static func claim(state: Dictionary, id: String) -> int:
	for item in items(state):
		if str(item["id"]) == id and bool(item["ready"]):
			state["daily"]["claimed"].append(id)
			return EconomyManager.credit(state, int(item["reward"]))
	return 0
