class_name SlotEngine
extends RefCounted
## Deterministic, presentation-independent slot mathematics.
## A grid is column-major: grid[column][row]. No animation can change a result.

const SLOT_IDS: Array[String] = ["golden_empire", "neon_chaos", "gods_of_thunder", "joker_madness", "empress_treasure", "cosmic_infinity"]
const SYMBOLS: Array[String] = ["crown", "gem", "chalice", "ring", "ace", "wild", "scatter"]
const SYMBOL_NAMES := {"crown": "Taç", "gem": "Mücevher", "chalice": "Kadeh", "ring": "Yüzük", "ace": "As", "wild": "Joker", "scatter": "Bonus"}
var rng := RandomNumberGenerator.new()

func _init() -> void:
	rng.randomize()

func set_seed(value: int) -> void:
	rng.seed = value

func load_config(id: String) -> Dictionary:
	if id not in SLOT_IDS:
		return {}
	var path := "res://data/slots/%s.json" % id
	if not FileAccess.file_exists(path):
		return {}
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if parsed is Dictionary and _valid_config(parsed):
		return parsed
	return {}

func _valid_config(config: Dictionary) -> bool:
	if int(config.get("columns", 0)) != 5 or int(config.get("rows", 0)) not in [3, 4]:
		return false
	if not config.get("weights", {}) is Dictionary or not config.get("paytable", {}) is Dictionary:
		return false
	var total := 0.0
	for symbol in SYMBOLS:
		var weight := float(config.get("weights", {}).get(symbol, 0.0))
		if weight < 0 or not is_finite(weight):
			return false
		total += weight
	if total <= 0:
		return false
	var lines: Array = config.get("paylines", [])
	if lines.is_empty():
		return false
	for line in lines:
		if not line is Array or line.size() != 5:
			return false
		for row in line:
			if int(row) < 0 or int(row) >= int(config.rows):
				return false
	return true

func spin(config: Dictionary, bet: int, ultimate: Dictionary = {}) -> Dictionary:
	if not _valid_config(config) or bet <= 0 or bet > 1000000000:
		return _empty_result("Geçersiz salon veya sanal bahis.")
	var grid := _new_grid(config)
	var natural_grid := grid.duplicate(true)
	var multiplier := 1.0
	var notices: Array[String] = []
	var transformations: Array = []
	var extra_payout := 0
	var extra_free := 0
	var bonus_data: Dictionary = {}
	var natural_scatter := _count_symbol(grid, "scatter")
	var mechanics: Dictionary = config.get("mechanic", {})
	match String(mechanics.get("type", "classic")):
		"neon_chain":
			var originals := _symbol_cells(grid, "wild")
			var added := 0
			for cell in originals:
				if cell.x < 4 and String(grid[cell.x + 1][cell.y]) not in ["scatter", "wild"] and rng.randf() < float(mechanics.get("chain_chance", 0.25)):
					_set_symbol(grid, Vector2i(cell.x + 1, cell.y), "wild", transformations)
					added += 1
			if added > 0:
				multiplier *= float(mechanics.get("chain_multiplier", 2))
				notices.append("Neon zinciri · %s yeni Joker · ×%s" % [added, multiplier])
		"thunder":
			if natural_scatter >= int(mechanics.get("trigger_scatter", 2)) or bool(ultimate.get("thunder_ready", false)):
				_add_wild_cells(grid, int(mechanics.get("wild_cells", 2)), transformations)
				extra_free += int(mechanics.get("extra_free_spins", 1))
				notices.append("Yıldırım düştü · 2 Joker ve 1 ücretsiz dönüş")
		"wheel":
			if natural_scatter >= int(mechanics.get("trigger_scatter", 2)):
				var wheel := _wheel(mechanics.get("wheel", _default_wheel()))
				bonus_data["wheel"] = wheel
				extra_payout += int(round(bet * float(wheel.get("chips", 0))))
				extra_free += int(wheel.get("free_spins", 0))
				_add_wild_cells(grid, int(wheel.get("wild_cells", 0)), transformations)
				notices.append("Joker çarkı · " + String(wheel.get("label", "Ödül")))
		"cosmic":
			if bool(ultimate.get("cosmic_ready", false)):
				_expand_reel(grid, rng.randi_range(0, 4), transformations)
				multiplier *= 2.0
				notices.append("Kozmik sayaç doldu · ek Joker makarası ve ×2")
			var wild_cells := _symbol_cells(grid, "wild")
			var expanded := 0
			for cell in wild_cells:
				if expanded >= int(mechanics.get("max_expanded_reels", 1)):
					break
				if rng.randf() < float(mechanics.get("expand_chance", 0.20)):
					_expand_reel(grid, cell.x, transformations)
					expanded += 1
					notices.append("Kozmik Joker · %s. makara genişledi" % (cell.x + 1))
			var cosmic := float(_weighted_choice(mechanics.get("multipliers", {"1": 81.5, "2": 15, "3": 3, "5": 0.5})))
			multiplier *= cosmic
			if cosmic > 1:
				notices.append("Kozmik çarpan · ×%s" % cosmic)
			# A jackpot requires five natural crowns, never substituted wilds.
			var crown_row := int(mechanics.get("jackpot_row", 1))
			var jackpot := true
			for column in range(5):
				if String(natural_grid[column][crown_row]) != "crown":
					jackpot = false
			if jackpot:
				extra_payout += bet * int(mechanics.get("jackpot_bet_multiplier", 1000))
				bonus_data["jackpot"] = true
				notices.append("TANRISAL BÜYÜK ÖDÜL · 5 doğal taç")

	var ultimate_result := _apply_ultimate(grid, bet, ultimate, transformations)
	multiplier *= float(ultimate_result.get("multiplier", 1.0))
	extra_payout += int(ultimate_result.get("payout", 0))
	extra_free += int(ultimate_result.get("free_spins", 0))
	if not String(ultimate_result.get("text", "")).is_empty():
		notices.append(String(ultimate_result.text))
	bonus_data.merge(ultimate_result.get("bonus_data", {}), true)
	var result := evaluate(grid, config, bet, multiplier)
	result["transformations"] = transformations
	result["bonus_data"] = bonus_data
	result["mechanic"] = String(mechanics.get("type", "classic"))
	result["natural_scatter_count"] = natural_scatter
	result["base_payout"] = int(result.payout)
	result["bonus_payout"] = extra_payout
	result["payout"] = int(result.payout) + extra_payout
	result["free_spins"] = int(result.free_spins) + extra_free
	result["cascades"] = []
	result["final_grid"] = grid.duplicate(true)
	if String(mechanics.get("type", "")) == "cascade":
		_run_cascades(result, config, bet, multiplier)
	if int(result.free_spins) > 0:
		notices.append("%s ücretsiz dönüş" % int(result.free_spins))
	result["bonus_text"] = " · ".join(notices)
	result["tier"] = win_tier(int(result.payout), bet)
	result["bet"] = bet
	result["error"] = ""
	result["bonus_triggered"] = not notices.is_empty() or extra_payout > 0 or extra_free > 0
	return result

func evaluate(grid: Array, config: Dictionary, bet: int, multiplier: float = 1.0) -> Dictionary:
	if not _valid_config(config) or not _valid_grid(grid, int(config.rows)) or bet <= 0 or not is_finite(multiplier) or multiplier < 0:
		return _empty_result("Geçersiz sonuç verisi.")
	var lines: Array = config.paylines
	var wins: Array = []
	var payout := 0
	var line_bet := float(bet) / float(lines.size())
	for line_id in range(lines.size()):
		var line: Array = lines[line_id]
		var best: Dictionary = {}
		var best_amount := 0
		# Compare all substitutions: a wild-leading line always pays the best valid symbol.
		for symbol in SYMBOLS:
			if symbol == "scatter":
				continue
			var count := 0
			var cells: Array = []
			for column in range(5):
				var current := String(grid[column][int(line[column])])
				if current != symbol and current != "wild":
					break
				if symbol == "wild" and current != "wild":
					break
				count += 1
				cells.append(Vector2i(column, int(line[column])))
			var symbol_pays: Dictionary = config.paytable.get(symbol, {})
			var amount := int(floor(line_bet * float(symbol_pays.get(str(count), 0.0)) * multiplier))
			if amount > best_amount:
				best_amount = amount
				best = {"symbol": symbol, "count": count, "cells": cells, "payout": amount, "line": line_id}
		if best_amount > 0:
			wins.append(best)
			payout += best_amount
	var scatter_count := _count_symbol(grid, "scatter")
	var free_spins := 0
	var scatter_payout := 0
	if bool(config.get("scatter_enabled", true)) and scatter_count >= 3:
		var scatter_rules: Dictionary = config.get("scatter", {})
		var paid_count := mini(scatter_count, int(scatter_rules.get("max_count", 5)))
		scatter_payout = int(floor(float(bet) * float(scatter_rules.get("payouts", {}).get(str(paid_count), 0)) * multiplier))
		free_spins = int(scatter_rules.get("free_spins", {}).get(str(paid_count), 0))
		if scatter_payout > 0:
			wins.append({"symbol": "scatter", "count": scatter_count, "cells": _symbol_cells(grid, "scatter"), "payout": scatter_payout, "line": -1})
		payout += scatter_payout
	return {"grid": grid.duplicate(true), "payout": payout, "wins": wins, "free_spins": free_spins, "multiplier": multiplier, "scatter_count": scatter_count, "scatter_payout": scatter_payout, "bonus_text": "", "tier": win_tier(payout, bet), "cascades": [], "error": ""}

func _apply_ultimate(grid: Array, bet: int, power: Dictionary, transformations: Array) -> Dictionary:
	var out := {"multiplier": maxf(float(power.get("multiplier", 1)), 0.0), "payout": 0, "free_spins": 0, "text": "", "bonus_data": {}}
	if power.is_empty():
		return out
	match String(power.get("character", "")).to_lower():
		"ares":
			if not power.has("multiplier"):
				out.multiplier = 2.0
			out.text = "İlahi Altın Yağmuru · ×%s" % out.multiplier
		"luna":
			var reels := clampi(int(power.get("wild_reels", 1)), 1, 2)
			var choices := _distinct_columns(reels)
			for column in choices:
				_expand_reel(grid, column, transformations)
			out.text = "Gerçeklik Kırılması · %s Joker makarası" % reels
		"vex":
			var chaos := float(_weighted_choice({"1": 45, "2": 30, "4": 15, "8": 8, "15": 2}))
			out.multiplier *= chaos
			out.bonus_data = {"chaos_multiplier": chaos}
			out.text = "Kaosun Serveti · ×%s" % chaos
		"noctis":
			var wheel := _wheel(_default_wheel())
			out.payout = int(round(bet * float(wheel.get("chips", 0))))
			out.free_spins = int(wheel.get("free_spins", 0))
			_add_wild_cells(grid, int(wheel.get("wild_cells", 0)), transformations)
			out.bonus_data = {"fate_wheel": wheel}
			out.text = "Kaderin Eli · " + String(wheel.get("label", "Ödül"))
		"kael":
			_add_wild_cells(grid, clampi(int(power.get("wild_cells", 3)), 1, 6), transformations)
			out.text = "Yıldırım Hükmü · zincir Jokerler"
		"seraphine":
			if not power.has("multiplier"):
				out.multiplier = 2.0
			var gems := _count_symbol(grid, "gem")
			out.payout = int(floor(float(bet) * float(gems) * 0.25))
			out.bonus_data = {"gem_count": gems, "gem_reward": out.payout}
			out.text = "Sonsuz Lütuf · %s mücevher toplandı" % gems
		"dante":
			if not power.has("multiplier"):
				out.multiplier = 2.0
			var count := 0
			for column in range(5):
				for row in range(grid[column].size()):
					if String(grid[column][row]) == "ace":
						_set_symbol(grid, Vector2i(column, row), "crown", transformations)
						count += 1
			out.text = "Kraliyet Egemenliği · %s As, Taç oldu" % count
		"orion":
			_expand_reel(grid, rng.randi_range(0, 4), transformations)
			var cosmic := float(_weighted_choice({"2": 65, "3": 25, "5": 9, "10": 1}))
			out.multiplier *= cosmic
			out.bonus_data = {"ultimate_cosmic_multiplier": cosmic}
			out.text = "Evrenin Çöküşü · Kozmik Joker ve ×%s" % cosmic
		_:
			_add_wild_cells(grid, clampi(int(power.get("wild_cells", 0)), 0, 6), transformations)
	return out

func _run_cascades(result: Dictionary, config: Dictionary, bet: int, initial_multiplier: float) -> void:
	var working: Array = result.grid.duplicate(true)
	var previous_wins: Array = result.wins
	var mechanic: Dictionary = config.mechanic
	var cascade_config := config.duplicate(true)
	cascade_config["scatter_enabled"] = false # The same scatter never pays twice.
	var limit := clampi(int(mechanic.get("max_cascades", 4)), 0, 8)
	for index in range(limit):
		var removed: Array = []
		for win in previous_wins:
			if String(win.symbol) == "scatter":
				continue
			for cell in win.cells:
				if cell not in removed:
					removed.append(cell)
		if removed.is_empty():
			break
		for column in range(5):
			var remaining: Array = []
			for row in range(int(config.rows)):
				if Vector2i(column, row) not in removed:
					remaining.append(working[column][row])
			while remaining.size() < int(config.rows):
				remaining.push_front(_draw_symbol(config))
			working[column] = remaining
		var stage_multiplier := initial_multiplier * float(index + 2)
		var stage := evaluate(working, cascade_config, bet, stage_multiplier)
		stage["removed_cells"] = removed
		stage["index"] = index + 1
		result.cascades.append(stage)
		result.payout = int(result.payout) + int(stage.payout)
		previous_wins = stage.wins
	result.final_grid = working.duplicate(true)
	result["cascade_count"] = result.cascades.size()

func _new_grid(config: Dictionary) -> Array:
	var grid: Array = []
	for column in range(5):
		var values: Array = []
		for row in range(int(config.rows)):
			values.append(_draw_symbol(config))
		grid.append(values)
	return grid

func _draw_symbol(config: Dictionary) -> String:
	return _weighted_choice(config.weights, SYMBOLS)

func _weighted_choice(weights: Dictionary, order: Array = []) -> String:
	var keys: Array = order if not order.is_empty() else weights.keys()
	var total := 0.0
	for key in keys:
		total += maxf(float(weights.get(key, 0)), 0)
	if total <= 0:
		return String(keys[0]) if not keys.is_empty() else "ace"
	var point := rng.randf() * total
	for key in keys:
		point -= maxf(float(weights.get(key, 0)), 0)
		if point < 0:
			return String(key)
	return String(keys[-1])

func _wheel(entries: Array) -> Dictionary:
	var weights: Dictionary = {}
	for index in range(entries.size()):
		weights[str(index)] = float(entries[index].get("weight", 1))
	return entries[int(_weighted_choice(weights))].duplicate(true)

func _default_wheel() -> Array:
	return [{"label": "2× sanal bahis", "weight": 40, "chips": 2}, {"label": "5× sanal bahis", "weight": 25, "chips": 5}, {"label": "2 ücretsiz dönüş", "weight": 20, "free_spins": 2}, {"label": "3 Joker", "weight": 12, "wild_cells": 3}, {"label": "20× sanal bahis", "weight": 3, "chips": 20}]

func _distinct_columns(count: int) -> Array:
	var columns: Array = [0, 1, 2, 3, 4]
	var picked: Array = []
	for index in range(mini(count, 5)):
		var choice := rng.randi_range(0, columns.size() - 1)
		picked.append(columns[choice])
		columns.remove_at(choice)
	return picked

func _add_wild_cells(grid: Array, count: int, transformations: Array) -> void:
	var available: Array = []
	for column in range(5):
		for row in range(grid[column].size()):
			if String(grid[column][row]) not in ["wild", "scatter"]:
				available.append(Vector2i(column, row))
	for index in range(mini(count, available.size())):
		var picked := rng.randi_range(0, available.size() - 1)
		_set_symbol(grid, available[picked], "wild", transformations)
		available.remove_at(picked)

func _expand_reel(grid: Array, column: int, transformations: Array) -> void:
	for row in range(grid[column].size()):
		# Preserve natural bonus symbols so a power cannot erase an earned bonus.
		if String(grid[column][row]) != "scatter":
			_set_symbol(grid, Vector2i(column, row), "wild", transformations)

func _set_symbol(grid: Array, cell: Vector2i, symbol: String, transformations: Array) -> void:
	var old := String(grid[cell.x][cell.y])
	if old != symbol:
		grid[cell.x][cell.y] = symbol
		transformations.append({"cell": cell, "from": old, "to": symbol})

func _symbol_cells(grid: Array, symbol: String) -> Array:
	var cells: Array = []
	for column in range(grid.size()):
		for row in range(grid[column].size()):
			if String(grid[column][row]) == symbol:
				cells.append(Vector2i(column, row))
	return cells

func _count_symbol(grid: Array, symbol: String) -> int:
	var count := 0
	for column in grid:
		for value in column:
			if String(value) == symbol:
				count += 1
	return count

func _valid_grid(grid: Array, rows: int) -> bool:
	if grid.size() != 5:
		return false
	for column in grid:
		if not column is Array or column.size() != rows:
			return false
		for symbol in column:
			if String(symbol) not in SYMBOLS:
				return false
	return true

static func win_tier(payout: int, bet: int) -> String:
	if payout <= 0 or bet <= 0:
		return ""
	var ratio := float(payout) / float(bet)
	if ratio >= 1000:
		return "TANRISAL BÜYÜK ÖDÜL"
	if ratio >= 250:
		return "TANRISAL KAZANÇ"
	if ratio >= 100:
		return "EFSANEVİ KAZANÇ"
	if ratio >= 50:
		return "DESTANSI KAZANÇ"
	if ratio >= 20:
		return "DEV KAZANÇ"
	if ratio >= 5:
		return "BÜYÜK KAZANÇ"
	return "GÜZEL KAZANÇ"

func _empty_result(reason: String) -> Dictionary:
	return {"grid": [], "payout": 0, "wins": [], "free_spins": 0, "multiplier": 1.0, "bonus_text": "", "tier": "", "cascades": [], "scatter_count": 0, "error": reason, "bonus_payout": 0, "transformations": [], "bonus_data": {}}
