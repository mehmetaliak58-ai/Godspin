class_name GodspinGame
extends RefCounted

var state: Dictionary = {}
var characters: Array = []
var slot_ids: Array = SaveManager.SLOTS.duplicate()
var engine := SlotEngine.new()
var saves := SaveManager.new()
var character_manager := CharacterManager.new()
var rng := RandomNumberGenerator.new()
var last_save_ok := true
const SLOT_LEVELS := {"golden_empire": 1, "neon_chaos": 2, "gods_of_thunder": 3, "joker_madness": 4, "empress_treasure": 5, "cosmic_infinity": 6}

func initialize(load_saved: bool = true) -> void:
	characters = character_manager.characters
	state = saves.load_state() if load_saved else SaveManager.defaults()
	QuestManager.refresh(state)
	rng.randomize()
	if not character_unlocked(str(state["character"])):
		state["character"] = "ares"
	if not slot_unlocked(str(state["slot"])):
		state["slot"] = "golden_empire"
	if int(state.get("bonus_remaining", 0)) > 0:
		state["slot"] = state["bonus_slot"]
		state["character"] = state["bonus_character"]
	elif int(state.get("free_spins", 0)) > 0:
		state["slot"] = state["free_slot"]
	SettingsManager.apply(state["settings"])

func set_seed(value: int) -> void:
	engine.set_seed(value)
	rng.seed = value

func character() -> Dictionary:
	return character_manager.find(str(state.get("character", "ares")))

func level() -> int:
	return CharacterManager.level(state)

func character_level(id: String = "") -> int:
	return CharacterManager.hero_level(state, str(state.get("character", "ares")) if id.is_empty() else id)

func character_unlocked(id: String) -> bool:
	return id in SaveManager.CHARACTERS and character_manager.unlocked(state, id)

func slot_unlocked(id: String) -> bool:
	return id in slot_ids and level() >= int(SLOT_LEVELS.get(id, 999))

func select_character(id: String) -> bool:
	if not character_unlocked(id) or int(state.get("bonus_remaining", 0)) > 0 or int(state.get("free_spins", 0)) > 0:
		return false
	state["character"] = id
	save()
	return true

func select_slot(id: String) -> bool:
	if not slot_unlocked(id) or int(state.get("bonus_remaining", 0)) > 0 or int(state.get("free_spins", 0)) > 0:
		return false
	state["slot"] = id
	save()
	return true

func selected_config() -> Dictionary:
	return engine.load_config(str(state.get("slot", "golden_empire")))

func bet() -> int:
	if int(state.get("bonus_remaining", 0)) > 0:
		return int(state.get("bonus_bet", 500))
	if int(state.get("free_spins", 0)) > 0:
		return int(state.get("free_bet", 500))
	return EconomyManager.bet(state)

func change_bet(delta: int) -> int:
	if int(state.get("bonus_remaining", 0)) > 0 or int(state.get("free_spins", 0)) > 0:
		return bet()
	state["bet_index"] = clampi(int(state.get("bet_index", 1)) + delta, 0, EconomyManager.max_bet_index(state))
	save()
	return bet()

func energy() -> int:
	return int(state.get("energy", {}).get(str(state.get("character", "ares")), 0))

func can_spin() -> bool:
	return not selected_config().is_empty() and EconomyManager.can_spin(state)

func spin() -> Dictionary:
	if not can_spin():
		return {"ok": false, "error": "Yeterli sanal çip yok. Ücretsiz toparlanma ödülünü alabilirsin.", "payout": 0}
	var character_id := str(state["character"])
	var slot_id := str(state["slot"])
	var wager := bet()
	var bonus := int(state["bonus_remaining"]) > 0
	var free := not bonus and int(state["free_spins"]) > 0
	var charge := 0 if bonus or free else wager
	var options: Dictionary = UltimateManager.spin_options(str(state["bonus_character"]), int(state["bonus_index"]), state) if bonus else {}
	options["passive_character"] = character_id
	var lightning_after := int(state["lightning_progress"])
	var cosmic_after := int(state["cosmic_progress"])
	if not bonus and slot_id == "gods_of_thunder":
		lightning_after += 2 if character_id == "kael" else 1
		options["thunder_ready"] = lightning_after >= 10
	if not bonus and slot_id == "cosmic_infinity":
		cosmic_after += 2 if character_id == "orion" else 1
		options["cosmic_ready"] = cosmic_after >= 12
	var result: Dictionary = engine.spin(selected_config(), wager, options)
	if not str(result.get("error", "")).is_empty():
		result["ok"] = false
		return result
	var old_balance := int(state["balance"])
	var old_level := level()
	var previous_free := int(state["free_spins"])
	state["balance"] = old_balance - charge
	if bonus:
		state["bonus_remaining"] = maxi(0, int(state["bonus_remaining"]) - 1)
		state["bonus_index"] = int(state["bonus_index"]) + 1
	elif free:
		state["free_spins"] = maxi(0, int(state["free_spins"]) - 1)
	state["free_spins"] = mini(100000, int(state["free_spins"]) + int(result.get("free_spins", 0)))
	state["lightning_progress"] = lightning_after % 10 if bool(options.get("thunder_ready", false)) else lightning_after
	state["cosmic_progress"] = cosmic_after % 12 if bool(options.get("cosmic_ready", false)) else cosmic_after
	var base_payout := int(result.get("payout", 0))
	var passive_payout := 0
	var passive_text := ""
	if character_id == "vex" and bool(result.get("bonus_triggered", false)):
		passive_payout += int(floor(base_payout * 0.25))
		passive_text = "Kaos payı · bonus kazancına %25 ek sanal çip"
	if not bonus:
		state["passive_spins"][character_id] = int(state["passive_spins"].get(character_id, 0)) + 1
		var hero_spins := int(state["passive_spins"][character_id])
		if character_id == "ares" and hero_spins % 8 == 0:
			state["free_spins"] = int(state["free_spins"]) + 1
			passive_text = "İmparatorun armağanı · 1 ücretsiz dönüş"
		elif character_id == "noctis" and hero_spins % 12 == 0:
			state["chests"] = int(state["chests"]) + 1
			passive_payout += wager * 3
			passive_text = "Gölge sandığı açıldı · 3× bahis değerinde sanal çip"
		state["energy"][character_id] = mini(100, energy() + CharacterManager.energy_gain(character_id, float(base_payout) / wager))
	if int(state["free_spins"]) > 0 and previous_free == 0:
		state["free_bet"] = wager
		state["free_slot"] = slot_id
	var credited := EconomyManager.credit(state, base_payout + passive_payout)
	state["total_won"] = mini(EconomyManager.MAX_BALANCE, int(state["total_won"]) + credited)
	state["spins"] = int(state["spins"]) + 1
	var earned_xp := CharacterManager.xp_gain(character_id)
	state["xp"] = int(state["xp"]) + earned_xp
	state["character_xp"][character_id] = int(state["character_xp"].get(character_id, 0)) + earned_xp
	state["vip_xp"] = int(state["vip_xp"]) + (15 if character_id == "dante" else 10)
	var progress_reward := 0
	if level() > old_level:
		progress_reward = EconomyManager.credit(state, int(2500 * level() * CharacterManager.reward_multiplier(character_id)))
	QuestManager.record(state, "spins", 1)
	QuestManager.record(state, "won", credited)
	result["ok"] = true
	result["payout"] = credited
	result["slot_payout"] = base_payout
	result["passive_payout"] = passive_payout
	result["passive_text"] = passive_text
	result["tier"] = SlotEngine.win_tier(credited, wager)
	result["win_ratio"] = float(credited) / wager
	result["charge"] = charge
	result["free"] = free or bonus
	result["is_bonus"] = bonus
	result["character"] = character_id
	result["slot"] = slot_id
	result["balance_before"] = old_balance
	result["balance_after"] = int(state["balance"])
	result["energy_after"] = energy()
	result["xp_gained"] = earned_xp
	result["level_before"] = old_level
	result["level_after"] = level()
	result["progress_reward"] = progress_reward
	state["history"].append({"spin": int(state["spins"]), "slot": slot_id, "character": character_id, "bet": wager, "charge": charge, "payout": credited, "tier": result["tier"], "free": free or bonus, "multiplier": result.get("multiplier", 1.0), "balance_after": state["balance"], "progress_reward": progress_reward})
	while state["history"].size() > 30:
		state["history"].pop_front()
	if int(state["bonus_remaining"]) == 0:
		state["bonus_character"] = ""
	save()
	return result

func activate_ultimate() -> Dictionary:
	var current_wager := bet()
	var result := UltimateManager.activation(state, character(), rng)
	if bool(result.get("ok", false)):
		state["bonus_bet"] = current_wager
		state["bonus_slot"] = state["slot"]
		QuestManager.record(state, "ultimates", 1)
		save()
	return result

func save() -> bool:
	last_save_ok = saves.save_state(state)
	return last_save_ok

func claim_quest(id: String) -> int:
	var amount := QuestManager.claim(state, id)
	if amount > 0:
		var character_id := str(state["character"])
		state["energy"][character_id] = mini(100, energy() + 10)
		save()
	return amount

func claim_achievement(id: String) -> int:
	var amount := AchievementManager.claim(state, id)
	if amount > 0:
		save()
	return amount

func rescue() -> int:
	var amount := EconomyManager.rescue(state)
	if amount > 0:
		save()
	return amount

func set_setting(key: String, value: Variant) -> void:
	var candidate: Dictionary = state["settings"].duplicate(true)
	candidate[key] = value
	state["settings"] = SettingsManager.normalize(candidate)
	SettingsManager.apply(state["settings"])
	save()

func purchase_cosmetic(id: String) -> bool:
	if id in state.get("cosmetics", []):
		return equip_cosmetic(id)
	var purchased := EconomyManager.purchase(state, id)
	if purchased:
		save()
	return purchased

func equip_cosmetic(id: String) -> bool:
	if id not in state.get("cosmetics", []):
		return false
	state["active_cosmetic"] = id
	save()
	return true

func quests() -> Array:
	return QuestManager.items(state)

func achievements() -> Array:
	return AchievementManager.items(state)

func cosmetics() -> Array:
	var result := EconomyManager.cosmetics()
	var colors := {"royal_frame": "#ffd778", "starlight_aura": "#9fabff", "divine_glow": "#fff1be"}
	for item in result:
		item["owned"] = item["id"] in state["cosmetics"]
		item["equipped"] = str(state.get("active_cosmetic", "")) == str(item["id"])
		item["color"] = colors.get(item["id"], "#ffd778")
	return result

func next_unlocks() -> Array:
	var result: Array = []
	for hero in characters:
		if not character_unlocked(str(hero["id"])):
			result.append({"title": hero["name"], "level": hero["unlock_level"], "kind": "character", "id": hero["id"]})
	for slot_id in slot_ids:
		if not slot_unlocked(str(slot_id)):
			result.append({"title": engine.load_config(str(slot_id)).get("title", slot_id), "level": SLOT_LEVELS[slot_id], "kind": "slot", "id": slot_id})
	return result
