class_name CharacterManager
extends RefCounted

var characters: Array = []

func _init() -> void:
	var file := FileAccess.open("res://data/characters.json", FileAccess.READ)
	if file:
		var parsed: Variant = JSON.parse_string(file.get_as_text())
		if parsed is Array:
			characters = parsed

func find(id: String) -> Dictionary:
	for item in characters:
		if str(item.get("id", "")) == id:
			return item
	return characters[0] if not characters.is_empty() else {}

static func level(state: Dictionary) -> int:
	return 1 + int(int(state.get("xp", 0)) / 120)

static func hero_level(state: Dictionary, id: String) -> int:
	return 1 + int(int(state.get("character_xp", {}).get(id, 0)) / 90)

func unlocked(state: Dictionary, id: String) -> bool:
	return level(state) >= int(find(id).get("unlock_level", 1))

static func energy_gain(id: String, win_ratio: float) -> int:
	var base := 14 if id == "luna" else 10
	if win_ratio >= 10.0:
		base += 5
	return base

static func xp_gain(id: String) -> int:
	return 13 if id == "dante" else 10

static func reward_multiplier(id: String) -> float:
	return 1.25 if id == "seraphine" else 1.0
