class_name PaytableManager
extends RefCounted
## Text is derived directly from the same mathematics used for real results.

static func describe(config: Dictionary) -> String:
	if config.is_empty():
		return "Salon bilgileri yüklenemedi."
	var lines: Array[String] = []
	lines.append(String(config.get("title", "Salon")))
	lines.append("%s×%s makara · %s ödeme çizgisi" % [config.get("columns", 5), config.get("rows", 3), config.get("paylines", []).size()])
	lines.append("Çizgiler soldan sağa, ilk makaradan başlayarak en az 3 eşleşmeyle öder. Sanal bahis, bütün çizgilere eşit bölünür. Her çizgi en yüksek eşleşmeyi bir kez öder; küsurat aşağı yuvarlanır.")
	lines.append("Joker, Bonus dışındaki sembollerin yerine geçer. Aynı hücre farklı ödeme çizgilerinde kazanabilir.")
	lines.append("3 / 4 / 5 sembol için çizgi bahsi çarpanları:")
	for symbol in ["crown", "gem", "chalice", "ring", "ace", "wild"]:
		var pays: Dictionary = config.get("paytable", {}).get(symbol, {})
		lines.append("%s: ×%s / ×%s / ×%s" % [SlotEngine.SYMBOL_NAMES[symbol], pays.get("3", 0), pays.get("4", 0), pays.get("5", 0)])
	var scatter: Dictionary = config.get("scatter", {})
	lines.append("Her yerde 3 / 4 / 5+ Bonus: toplam bahsin ×%s / ×%s / ×%s kadarı ve %s / %s / %s ücretsiz dönüş. Bonus ödemesi çarpanlarla artar." % [scatter.get("payouts", {}).get("3", 0), scatter.get("payouts", {}).get("4", 0), scatter.get("payouts", {}).get("5", 0), scatter.get("free_spins", {}).get("3", 0), scatter.get("free_spins", {}).get("4", 0), scatter.get("free_spins", {}).get("5", 0)])
	lines.append(String(config.get("rules", "")))
	lines.append("Ağırlıklı, bağımsız sanal çekiliş. Sonuçlar çevirmeden önce hesaplanır; animasyon sonucu değiştirmez. Kazanç garantisi yoktur.")
	var weights: Dictionary = config.get("weights", {})
	var total := 0.0
	for key in weights:
		total += float(weights[key])
	var odds: Array[String] = []
	for symbol in SlotEngine.SYMBOLS:
		odds.append("%s %0.2f%%" % [SlotEngine.SYMBOL_NAMES[symbol], 100.0 * float(weights.get(symbol, 0)) / maxf(total, 1)])
	lines.append("Her hücrede temel sembol olasılıkları: " + ", ".join(odds))
	lines.append("Kazanç etiketleri toplam ödül / sanal bahis oranına göre: Büyük ≥5×, Dev ≥20×, Destansı ≥50×, Efsanevi ≥100×, Tanrısal ≥250×, Tanrısal Büyük Ödül ≥1000×.")
	lines.append("Yalnızca sanal çip kullanılır. Satın alma, nakit çekim ve gerçek para ödülü yoktur.")
	return "\n\n".join(lines)

static func ultimate_rules(character: String) -> String:
	match character.to_lower():
		"ares": return "Altın Yağmuru: 3 ücretsiz güç dönüşünde bütün çizgi ve Bonus ödemeleri sırasıyla ×2, ×3 ve ×5 artar."
		"luna": return "Gerçeklik Kırılması: 3 ücretsiz güç dönüşünün her birinde rastgele seçilen 2 makara Joker olur; Bonus sembolleri korunur."
		"vex": return "Kaos çarpanı: ×1 %45, ×2 %30, ×4 %15, ×8 %8, ×15 %2. Görünen çarpan gerçek ödüle uygulanır."
		"noctis": return "Kader çarkı: 2× bahis %40, 5× bahis %25, 2 ücretsiz dönüş %20, 3 Joker %12, 20× bahis %3."
		"kael": return "Yıldırım Hükmü: 3 ücretsiz güç dönüşünün her birinde farklı ve Bonus olmayan 5 hücre Joker olur."
		"seraphine": return "Sonsuz Lütuf: 3 ücretsiz güç dönüşünde 3× ödeme çarpanı; ilk görünen sonuçtaki her mücevher toplam bahsin %25'i kadar ek ödül verir."
		"dante": return "Kraliyet Egemenliği: 3 ücretsiz güç dönüşünde bütün As sembolleri Taç olur; temel ödüller 3× artar."
		"orion": return "Evrenin Çöküşü: 3 ücretsiz güç dönüşünün her birinde bir Joker makarası; temel ×4 üzerine ilave kozmik çarpan ×2 %65, ×3 %25, ×5 %9, ×10 %1 uygulanır."
	return ""
