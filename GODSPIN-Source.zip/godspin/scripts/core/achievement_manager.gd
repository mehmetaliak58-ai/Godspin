class_name AchievementManager
extends RefCounted

const DEFINITIONS := [
	{"id": "first_spin", "title": "İlk Kader", "description": "İlk dönüşünü tamamla.", "stat": "spins", "target": 1, "reward": 5000},
	{"id": "fifty_spins", "title": "Servet Yolcusu", "description": "50 dönüş tamamla.", "stat": "spins", "target": 50, "reward": 50000},
	{"id": "hundred_spins", "title": "Casino Hükümdarı", "description": "100 dönüş tamamla.", "stat": "spins", "target": 100, "reward": 100000, "cosmetic": "royal_frame"},
	{"id": "first_power", "title": "İlahi Müdahale", "description": "Bir tanrısal güç kullan.", "stat": "ultimate_count", "target": 1, "reward": 20000},
	{"id": "ten_powers", "title": "Tanrılar Meclisi", "description": "10 tanrısal güç kullan.", "stat": "ultimate_count", "target": 10, "reward": 150000, "cosmetic": "starlight_aura"},
	{"id": "million_won", "title": "Milyonların Efendisi", "description": "Toplam 1.000.000 sanal çip kazan.", "stat": "total_won", "target": 1000000, "reward": 250000},
	{"id": "billion_won", "title": "Servet İmparatorluğu", "description": "Toplam 1.000.000.000 sanal çip kazan.", "stat": "total_won", "target": 1000000000, "reward": 10000000, "cosmetic": "divine_glow"}
]

static func items(state: Dictionary) -> Array:
	var result: Array = []
	for definition in DEFINITIONS:
		var item: Dictionary = definition.duplicate(true)
		item["progress"] = mini(int(state.get(item["stat"], 0)), int(item["target"]))
		item["claimed"] = item["id"] in state.get("achievements_claimed", [])
		item["ready"] = int(item["progress"]) >= int(item["target"]) and not bool(item["claimed"])
		item["reward"] = int(int(item["reward"]) * CharacterManager.reward_multiplier(str(state.get("character", "ares"))))
		result.append(item)
	return result

static func claim(state: Dictionary, id: String) -> int:
	for item in items(state):
		if str(item["id"]) != id or not bool(item["ready"]):
			continue
		state["achievements_claimed"].append(id)
		var cosmetic: String = str(item.get("cosmetic", ""))
		if not cosmetic.is_empty() and cosmetic not in state["cosmetics"]:
			state["cosmetics"].append(cosmetic)
		return EconomyManager.credit(state, int(item["reward"]))
	return 0
