class_name SaveManager
extends RefCounted

const VERSION := 1
const CHARACTERS := ["ares", "luna", "vex", "noctis", "kael", "seraphine", "dante", "orion"]
const SLOTS := ["golden_empire", "neon_chaos", "gods_of_thunder", "joker_madness", "empress_treasure", "cosmic_infinity"]
var path := "user://godspin-save.json"
var recovered := false
var last_error := ""

static func defaults() -> Dictionary:
	var energies := {}
	var hero_xp := {}
	for id in CHARACTERS:
		energies[id] = 50 if id == "ares" else 0
		hero_xp[id] = 0
	return {
		"version": VERSION, "balance": 100000, "character": "ares", "slot": "golden_empire", "bet_index": 1,
		"bets": EconomyManager.BETS.duplicate(), "energy": energies, "character_xp": hero_xp, "xp": 0,
		"spins": 0, "ultimate_count": 0, "total_won": 0, "free_spins": 0, "bonus_remaining": 0,
		"bonus_character": "", "bonus_index": 0, "bonus_bet": 500, "bonus_slot": "golden_empire", "free_bet": 500, "free_slot": "golden_empire", "wheel_segment": 0, "history": [],
		"settings": SettingsManager.DEFAULTS.duplicate(true), "cosmetics": [], "active_cosmetic": "",
		"achievements_claimed": [], "daily": {}, "rescue_count": 0, "chests": 0, "vip_xp": 0,
		"passive_spins": {}, "lightning_progress": 0, "cosmic_progress": 0
	}

static func safe_int(value: Variant, fallback: int, maximum: int = EconomyManager.MAX_BALANCE) -> int:
	if value is int or value is float:
		if not is_finite(float(value)):
			return fallback
		return clampi(int(value), 0, maximum)
	return fallback

static func safe_float(value: Variant, fallback: float = 1.0) -> float:
	if (value is int or value is float) and is_finite(float(value)):
		return clampf(float(value), 0.0, 1000000.0)
	return fallback

static func validate(raw: Variant) -> Dictionary:
	var clean := defaults()
	if not raw is Dictionary:
		return clean
	for key in ["balance", "xp", "spins", "ultimate_count", "total_won", "rescue_count", "chests", "vip_xp", "lightning_progress", "cosmic_progress"]:
		clean[key] = safe_int(raw.get(key), int(clean[key]))
	clean["bet_index"] = safe_int(raw.get("bet_index"), 1, EconomyManager.BETS.size() - 1)
	for key in ["free_spins", "bonus_remaining", "bonus_index", "wheel_segment"]:
		clean[key] = safe_int(raw.get(key), 0, {"free_spins": 100000, "bonus_remaining": 3, "bonus_index": 3, "wheel_segment": 2}[key])
	clean["bonus_bet"] = maxi(100, safe_int(raw.get("bonus_bet"), 500, 1000000))
	# Older version-1 saves without frozen free-spin fields retain their current wager/salon.
	clean["free_bet"] = maxi(100, safe_int(raw.get("free_bet"), int(EconomyManager.BETS[int(clean["bet_index"])]), 1000000))
	for key in ["character", "bonus_character"]:
		if raw.get(key) in CHARACTERS:
			clean[key] = raw[key]
	for key in ["slot", "bonus_slot", "free_slot"]:
		if raw.get(key) in SLOTS:
			clean[key] = raw[key]
	if not raw.has("free_slot"):
		clean["free_slot"] = clean["slot"]
	if int(clean["bonus_remaining"]) > 0 and str(clean["bonus_character"]).is_empty():
		clean["bonus_remaining"] = 0
	for key in ["energy", "character_xp", "passive_spins"]:
		var values: Variant = raw.get(key)
		if values is Dictionary:
			for id in CHARACTERS:
				clean[key][id] = safe_int(values.get(id), int(clean[key].get(id, 0)), 100 if key == "energy" else EconomyManager.MAX_BALANCE)
	clean["settings"] = SettingsManager.normalize(raw.get("settings"))
	var allowed_cosmetics: Array = []
	for item in EconomyManager.cosmetics():
		allowed_cosmetics.append(item["id"])
	var raw_cosmetics: Variant = raw.get("cosmetics", [])
	if raw_cosmetics is Array:
		for cosmetic in raw_cosmetics:
			if cosmetic in allowed_cosmetics and cosmetic not in clean["cosmetics"]:
				clean["cosmetics"].append(cosmetic)
	if raw.get("active_cosmetic") in clean["cosmetics"]:
		clean["active_cosmetic"] = raw["active_cosmetic"]
	var achievements: Variant = raw.get("achievements_claimed", [])
	if achievements is Array:
		for definition in AchievementManager.DEFINITIONS:
			if definition["id"] in achievements:
				clean["achievements_claimed"].append(definition["id"])
	var daily: Variant = raw.get("daily")
	if daily is Dictionary:
		clean["daily"] = {"date": str(daily.get("date", "")), "spins": safe_int(daily.get("spins"), 0), "won": safe_int(daily.get("won"), 0), "ultimates": safe_int(daily.get("ultimates"), 0), "claimed": []}
		var claims: Variant = daily.get("claimed", [])
		if claims is Array:
			for definition in QuestManager.DEFINITIONS:
				if definition["id"] in claims:
					clean["daily"]["claimed"].append(definition["id"])
	var history: Variant = raw.get("history")
	if history is Array:
		for index in range(maxi(0, history.size() - 30), history.size()):
			var entry: Variant = history[index]
			if entry is Dictionary:
				var copy := {"spin": safe_int(entry.get("spin"), 0), "slot": str(entry.get("slot", "golden_empire")), "character": str(entry.get("character", "ares")), "bet": safe_int(entry.get("bet"), 100), "charge": safe_int(entry.get("charge"), 0), "payout": safe_int(entry.get("payout"), 0), "tier": str(entry.get("tier", "")), "free": entry.get("free", false) == true, "multiplier": safe_float(entry.get("multiplier")), "balance_after": safe_int(entry.get("balance_after"), 0), "progress_reward": safe_int(entry.get("progress_reward"), 0)}
				clean["history"].append(copy)
	clean["bet_index"] = mini(int(clean["bet_index"]), EconomyManager.max_bet_index(clean))
	QuestManager.refresh(clean)
	return clean

func _read(candidate: String) -> Variant:
	var file := FileAccess.open(candidate, FileAccess.READ)
	if not file or file.get_length() > 4000000:
		return null
	var parser := JSON.new()
	if parser.parse(file.get_as_text()) != OK or not parser.data is Dictionary:
		return null
	var raw: Dictionary = parser.data
	if not raw.has("version") or not (raw.get("version") is int or raw.get("version") is float) or int(raw.get("version", 0)) > VERSION or not raw.has("balance"):
		return null
	return raw

func load_state() -> Dictionary:
	recovered = false
	var raw: Variant = _read(path)
	if raw is Dictionary:
		return validate(raw)
	var backup: Variant = _read(path + ".bak")
	if backup is Dictionary:
		recovered = true
		return validate(backup)
	return defaults()

func save_state(state: Dictionary) -> bool:
	last_error = ""
	var clean := validate(state)
	var temporary := path + ".tmp"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if not file:
		last_error = "Kayıt dosyası açılamadı."
		return false
	file.store_string(JSON.stringify(clean))
	file.flush()
	file.close()
	if not _read(temporary) is Dictionary:
		last_error = "Kayıt doğrulaması başarısız."
		return false
	var absolute := ProjectSettings.globalize_path(path)
	if _read(path) is Dictionary:
		var copied := DirAccess.copy_absolute(absolute, absolute + ".bak")
		if copied != OK:
			last_error = "Yedek kayıt oluşturulamadı."
			return false
	var renamed := DirAccess.rename_absolute(ProjectSettings.globalize_path(temporary), absolute)
	if renamed != OK:
		last_error = "Kayıt güvenli biçimde taşınamadı."
		return false
	return true
