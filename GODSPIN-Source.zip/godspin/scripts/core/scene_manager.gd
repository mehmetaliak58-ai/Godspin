class_name GodspinSceneManager
extends RefCounted

signal changed(screen: String)
var current := "lobby"

func open(screen: String) -> void:
	current = screen
	changed.emit(screen)
