class_name UltimateManager
extends RefCounted

static func activation(state: Dictionary, character: Dictionary, _rng: RandomNumberGenerator) -> Dictionary:
	var id := str(character.get("id", "ares"))
	if int(state.get("energy", {}).get(id, 0)) < 100 or int(state.get("bonus_remaining", 0)) > 0:
		return {"ok": false, "error": "Tanrısal güç henüz hazır değil."}
	state["energy"][id] = 0
	state["bonus_remaining"] = 3
	state["bonus_character"] = id
	state["bonus_index"] = 0
	state["ultimate_count"] = int(state.get("ultimate_count", 0)) + 1
	return {"ok": true, "character": id, "title": character.get("ultimate", ""), "description": character.get("power", ""), "spins": 3, "wheel_reward": "", "payout": 0}

static func spin_options(id: String, index: int, _state: Dictionary) -> Dictionary:
	var options := {"character": id, "bonus_index": index}
	match id:
		"ares": options["multiplier"] = [2.0, 3.0, 5.0][clampi(index, 0, 2)]
		"luna": options["wild_reels"] = 2
		"vex": options["chaos"] = true
		"noctis":
			options["multiplier"] = 1.0
		"kael": options["wild_cells"] = 5
		"seraphine":
			options["multiplier"] = 3.0
			options["gem_bonus"] = true
		"dante":
			options["multiplier"] = 3.0
			options["royal"] = true
		"orion":
			options["multiplier"] = 4.0
			options["expanding_wild"] = true
	return options
