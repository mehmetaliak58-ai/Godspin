class_name SettingsManager
extends RefCounted

const DEFAULTS := {
	"quality": "Yüksek", "reduced_motion": false, "sound": true,
	"music": true, "fps": 60, "turbo": false
}
const QUALITIES := ["Düşük", "Orta", "Yüksek", "Ultra"]

static func normalize(raw: Variant) -> Dictionary:
	var result := DEFAULTS.duplicate(true)
	if not raw is Dictionary:
		return result
	for key in DEFAULTS:
		if not raw.has(key):
			continue
		if key == "quality":
			if raw[key] in QUALITIES:
				result[key] = raw[key]
		elif key == "fps":
			if raw[key] is int or raw[key] is float:
				result[key] = 30 if int(raw[key]) == 30 else 60
		elif raw[key] is bool:
			result[key] = raw[key]
	return result

static func apply(settings: Dictionary) -> void:
	Engine.max_fps = int(settings.get("fps", 60))

static func intensity(settings: Dictionary) -> float:
	if bool(settings.get("reduced_motion", false)):
		return 0.15
	return {"Düşük": 0.25, "Orta": 0.5, "Yüksek": 0.8, "Ultra": 1.0}.get(settings.get("quality", "Yüksek"), 0.8)
