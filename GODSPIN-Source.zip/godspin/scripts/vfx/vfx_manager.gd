class_name GodspinVFX
extends Control
## Presentation only: computed payouts and bonus activation remain owned by gameplay.
signal finished
signal phase_changed(phase: String, character_id: String)

const WIN_TIERS: Array[String] = ["GÜZEL KAZANÇ", "BÜYÜK KAZANÇ", "MEGA KAZANÇ", "DESTANSI KAZANÇ", "EFSANEVİ KAZANÇ", "TANRISAL KAZANÇ", "İLAHİ BÜYÜK ÖDÜL"]
const PALETTES := {
	"ares": Color("ffcf68"), "luna": Color("d184ff"), "vex": Color("ff4464"),
	"noctis": Color("986aff"), "kael": Color("61caff"), "seraphine": Color("ffafcf"),
	"dante": Color("efbd65"), "orion": Color("92a0ff")
}
# Individual choreography: reveal, impact, reel transformation, reward reveal.
const CHOREOGRAPHY := {
	"ares": Vector4(0.13, 0.40, 0.63, 0.84), "luna": Vector4(0.10, 0.35, 0.57, 0.82),
	"vex": Vector4(0.11, 0.33, 0.59, 0.81), "noctis": Vector4(0.17, 0.43, 0.66, 0.86),
	"kael": Vector4(0.12, 0.38, 0.61, 0.83), "seraphine": Vector4(0.14, 0.41, 0.65, 0.85),
	"dante": Vector4(0.16, 0.42, 0.64, 0.84), "orion": Vector4(0.16, 0.44, 0.69, 0.87)
}
const PHASES: Array[String] = ["anticipation", "character_reveal", "power_impact", "reel_transformation", "reward_reveal"]
var current_phase := ""
var _phase_index := -1
var _mode := ""
var _id := "ares"
var _title := ""
var _power := ""
var _amount := 0
var _tier := 0
var _time := 0.0
var _duration := 2.6
var _serial := 0
var _reduced := false
var _preview_mode := false
var _quality := 2
var _color := Color("ffcf68")
var _portrait: Texture2D
var _coin: Texture2D
var _gem: Texture2D
var _wild: Texture2D
var _joker: Texture2D
var _palace: Texture2D
var _font: Font
var _particles: Array[Dictionary] = []
var _textures: Dictionary = {}
var _shapes: Dictionary = {}
var _rng := RandomNumberGenerator.new()
var _canvas_scale := Vector2.ONE
var _canvas_offset := Vector2.ZERO
var _shake_offset := Vector2.ZERO
var _reel_rect := Rect2(24, 389, 672, 441)
var _timeline := Vector4(0.13, 0.4, 0.63, 0.84)
var _portal_layer: ColorRect
var _beam_layer: ColorRect
var _portal_material: ShaderMaterial
var _beam_material: ShaderMaterial

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	z_index = 100
	_font = load("res://assets/fonts/NotoSans-Bold.ttf") as Font if ResourceLoader.exists("res://assets/fonts/NotoSans-Bold.ttf") else ThemeDB.fallback_font
	_coin = _texture("res://assets/art/symbol_coin.png")
	_gem = _texture("res://assets/art/symbol_gem.png")
	_wild = _texture("res://assets/art/symbol_wild.png")
	_joker = _texture("res://assets/art/symbol_joker.png")
	_palace = _texture("res://assets/art/casino_palace.webp")
	_rng.seed = 894172
	# Fixed shared particle pool and immutable shape templates. No nodes/resources spawn mid-effect.
	for index in range(100):
		_particles.append({"x": _rng.randf(), "y": _rng.randf(), "speed": _rng.randf_range(0.4, 1.2), "phase": _rng.randf() * TAU, "size": _rng.randf_range(2.0, 6.0)})
	_shapes["crown"] = PackedVector2Array([Vector2(-162, 40), Vector2(-180, -45), Vector2(-98, -2), Vector2(-76, -88), Vector2(0, -15), Vector2(76, -88), Vector2(98, -2), Vector2(180, -45), Vector2(162, 40)])
	_shapes["diamond"] = PackedVector2Array([Vector2(0, -1.4), Vector2(1, 0), Vector2(0, 1.4), Vector2(-1, 0)])
	_shapes["hammer"] = PackedVector2Array([Vector2(-75, -87), Vector2(75, -87), Vector2(86, -25), Vector2(12, -7), Vector2(12, 120), Vector2(-12, 120), Vector2(-12, -7), Vector2(-86, -25)])
	_shapes["throne"] = PackedVector2Array([Vector2(-140, 212), Vector2(-155, -222), Vector2(-102, -313), Vector2(0, -364), Vector2(102, -313), Vector2(155, -222), Vector2(140, 212)])
	_shapes["table"] = PackedVector2Array([Vector2(-250, 0), Vector2(250, 0), Vector2(295, 78), Vector2(-295, 78)])
	_shapes["fracture"] = PackedVector2Array([Vector2(40, 330), Vector2(209, 432), Vector2(165, 554), Vector2(375, 613), Vector2(470, 728), Vector2(672, 762)])
	for side in [-1.0, 1.0]:
		for finger in range(5):
			var start := Vector2(360 + side * 450, 400 + finger * 82)
			var end := Vector2(360 + side * (140 + finger * 15), 535 + finger * 48)
			var mid := start.lerp(end, 0.60) + Vector2(0, -55)
			_shapes["hand_%d_%d" % [int(side), finger]] = PackedVector2Array([start, mid, end, end + Vector2(0, 15), mid + Vector2(0, 32), start + Vector2(0, 65)])
	_setup_shader_layers()
	visible = false
	set_process(false)

func set_quality(profile: String) -> void:
	_quality = {"Düşük": 0, "Orta": 1, "Yüksek": 2, "Ultra": 3, "low": 0, "medium": 1, "high": 2, "ultra": 3}.get(profile, 2)

func set_reel_rect(rect: Rect2) -> void:
	# Rect uses the same 720×1280 design coordinates as the main UI.
	if rect.size.x > 0 and rect.size.y > 0:
		_reel_rect = rect

func set_character(character: Dictionary) -> void:
	_id = str(character.get("id", "ares")).to_lower()
	_title = str(character.get("name", _id.to_upper()))
	_power = str(character.get("ultimate_name", character.get("power_name", character.get("ultimate", "TANRISAL GÜÇ"))))
	if character.get("ultimate") is Dictionary:
		_power = str(character["ultimate"].get("name", "TANRISAL GÜÇ"))
	_color = PALETTES.get(_id, Color("ffcf68"))
	var raw_color: Variant = character.get("color", null)
	if raw_color is Color:
		_color = raw_color
	elif raw_color is String:
		_color = Color.from_string(raw_color, _color)
	_timeline = CHOREOGRAPHY.get(_id, CHOREOGRAPHY["ares"])
	_load_portrait(character)

func play_ultimate(character: Dictionary, reduced: bool = false) -> void:
	await _run_ultimate(character, reduced, false)

func preview(character: Dictionary, reduced: bool = false) -> void:
	# Preview never changes balance, energy, RNG or pending bonus rounds.
	await _run_ultimate(character, reduced, true)

func _run_ultimate(character: Dictionary, reduced: bool, is_preview: bool) -> void:
	set_character(character)
	_preview_mode = is_preview
	_begin("ultimate", 0.65 if reduced else 2.6, reduced)
	var own_serial := _serial
	while _mode != "" and _serial == own_serial and is_inside_tree():
		await get_tree().process_frame

func celebrate(tier: String, amount: int, color: Color, reduced: bool = false) -> void:
	var tier_aliases := {"DEV KAZANÇ": "MEGA KAZANÇ", "TANRISAL BÜYÜK ÖDÜL": "İLAHİ BÜYÜK ÖDÜL"}
	_tier = maxi(0, WIN_TIERS.find(str(tier_aliases.get(tier, tier))))
	_title = tier
	_amount = maxi(0, amount)
	_color = color
	_begin("win", 0.55 if reduced else minf(0.85 + _tier * 0.37, 3.15), reduced)
	var own_serial := _serial
	while _mode != "" and _serial == own_serial and is_inside_tree():
		await get_tree().process_frame

func skip() -> void:
	if _mode != "":
		_finish()

func is_playing() -> bool:
	return _mode != ""

func _texture(path: String) -> Texture2D:
	if _textures.has(path):
		return _textures[path]
	if path != "" and ResourceLoader.exists(path):
		var resource := load(path) as Texture2D
		if resource != null:
			_textures[path] = resource
			return resource
	return null

func _load_portrait(character: Dictionary) -> void:
	_portrait = null
	var possible: Array[String] = [str(character.get("portrait", "")), str(character.get("portrait_path", "")), "res://assets/art/" + _id + ".webp", "res://assets/art/" + _id + ".png", "res://assets/characters/" + _id + ".png"]
	for path in possible:
		_portrait = _texture(path)
		if _portrait != null:
			return

func _begin(mode: String, duration: float, reduced: bool) -> void:
	_serial += 1
	_mode = mode
	_time = 0.0
	_duration = duration
	_reduced = reduced
	_phase_index = -1
	current_phase = ""
	visible = true
	set_process(true)
	queue_redraw()
	_update_phase(0.0)
	_update_shader_layers(0.0)

func _finish() -> void:
	_mode = ""
	_shake_offset = Vector2.ZERO
	if is_instance_valid(_portal_layer):
		_portal_layer.hide()
	if is_instance_valid(_beam_layer):
		_beam_layer.hide()
	current_phase = ""
	visible = false
	set_process(false)
	queue_redraw()
	finished.emit()

func _update_phase(p: float) -> void:
	if _mode != "ultimate":
		return
	var phase := 0
	if p >= _timeline.x: phase = 1
	if p >= _timeline.y: phase = 2
	if p >= _timeline.z: phase = 3
	if p >= _timeline.w: phase = 4
	if phase != _phase_index:
		_phase_index = phase
		current_phase = PHASES[phase]
		phase_changed.emit(current_phase, _id)

func _process(delta: float) -> void:
	_time += delta
	if _time >= _duration:
		_finish()
	else:
		_update_phase(_time / _duration)
		_update_shader_layers(_time / _duration)
		queue_redraw()

func _draw() -> void:
	if _mode == "" or size.x <= 0.0:
		return
	var p := clampf(_time / _duration, 0.0, 1.0)
	var fade := minf(p * 9.0, (1.0 - p) * 7.0)
	var fit := minf(size.x / 720.0, size.y / 1280.0)
	_canvas_scale = Vector2.ONE * fit
	_canvas_offset = (size - Vector2(720, 1280) * fit) * 0.5
	_shake_offset = Vector2.ZERO
	if _mode == "ultimate" and not _reduced and _quality > 0:
		var impact_age := _time - _duration * _timeline.y
		if impact_age >= 0.0 and impact_age < 0.32:
			var amplitude := 4.0 * exp(-impact_age * 12)
			_shake_offset = Vector2(sin(impact_age * 57), cos(impact_age * 49)) * amplitude
	_restore_canvas()
	if _mode == "ultimate":
		_draw_ultimate(p, fade)
	else:
		_draw_win(p, fade)
	draw_set_transform(Vector2.ZERO)

func _full_background(tint: Color) -> void:
	draw_set_transform(Vector2.ZERO)
	draw_rect(Rect2(Vector2.ZERO, size), tint)
	_restore_canvas()

func _restore_canvas() -> void:
	draw_set_transform(_canvas_offset + _shake_offset, 0.0, _canvas_scale)

func _local(pos: Vector2, rotation: float = 0.0, scale_value: Vector2 = Vector2.ONE) -> void:
	draw_set_transform(_canvas_offset + _shake_offset + pos * _canvas_scale, rotation, scale_value * _canvas_scale)

func _setup_shader_layers() -> void:
	# Two reusable layers integrate researched CC0 shader sources; no effect nodes spawn during play.
	var portal_path := "res://assets/vendor/godotshaders/portal.gdshader"
	var beam_path := "res://assets/vendor/godotshaders/energy_beams.gdshader"
	if ResourceLoader.exists(portal_path):
		_portal_material = ShaderMaterial.new()
		_portal_material.shader = load(portal_path) as Shader
		_portal_layer = ColorRect.new()
		_portal_layer.name = "CC0PortalLayer"
		_portal_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_portal_layer.show_behind_parent = true
		_portal_layer.material = _portal_material
		add_child(_portal_layer)
		_portal_layer.hide()
	if ResourceLoader.exists(beam_path):
		_beam_material = ShaderMaterial.new()
		_beam_material.shader = load(beam_path) as Shader
		_beam_material.set_shader_parameter("roughness", 2)
		_beam_material.set_shader_parameter("beams", 3)
		_beam_material.set_shader_parameter("speed", 0.55)
		_beam_material.set_shader_parameter("thickness", 0.010)
		_beam_material.set_shader_parameter("outline_thickness", 0.035)
		_beam_layer = ColorRect.new()
		_beam_layer.name = "CC0EnergyBeamLayer"
		_beam_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_beam_layer.show_behind_parent = true
		_beam_layer.material = _beam_material
		add_child(_beam_layer)
		_beam_layer.hide()

func _update_shader_layers(p: float) -> void:
	var enabled := not _reduced and _quality > 0 and _mode != ""
	var fit := minf(size.x / 720.0, size.y / 1280.0)
	var scale_value := Vector2.ONE * fit
	var design_offset := (size - Vector2(720, 1280) * fit) * 0.5
	var fade := minf(p * 9, (1 - p) * 7)
	if is_instance_valid(_portal_layer):
		var portal_event := (_mode == "ultimate" and _id in ["orion", "noctis", "vex"]) or (_mode == "win" and _tier >= 5)
		_portal_layer.visible = enabled and portal_event and p >= 0.28
		if _portal_layer.visible:
			var width := 490.0 if _mode == "ultimate" else 650.0
			var center := Vector2(360, 699) if _mode == "ultimate" else Vector2(360, 410)
			_portal_layer.position = design_offset + (center - Vector2.ONE * width * 0.5) * scale_value
			_portal_layer.size = Vector2.ONE * width * scale_value
			_portal_material.set_shader_parameter("portal_color", _color)
			_portal_material.set_shader_parameter("strength", fade * (0.65 if _quality == 1 else 0.88))
			_portal_material.set_shader_parameter("rotation_speed", 1.1 if _id == "vex" else 0.65)
			_portal_material.set_shader_parameter("glow_strength", 0.65)
	if is_instance_valid(_beam_layer):
		var beam_event := _mode == "ultimate" and _id in ["ares", "kael", "luna", "seraphine", "dante"]
		_beam_layer.visible = enabled and beam_event and p >= _timeline.y
		if _beam_layer.visible:
			_beam_layer.position = design_offset + _reel_rect.position * scale_value
			_beam_layer.size = _reel_rect.size * scale_value
			_beam_material.set_shader_parameter("progress", smoothstep(_timeline.y, _timeline.z, p) * fade)
			_beam_material.set_shader_parameter("color", Color(_color.lerp(Color.WHITE, 0.4), fade * 0.65))
			_beam_material.set_shader_parameter("outline_color", Color(_color, fade * 0.55))

func _draw_ultimate(p: float, fade: float) -> void:
	var reveal := smoothstep(_timeline.x, _timeline.y - 0.04, p)
	var impact := smoothstep(_timeline.y, _timeline.y + 0.09, p)
	var transform := smoothstep(_timeline.z, _timeline.w, p)
	var origin := _reel_rect.get_center()
	# Anticipation deepens first; transform restores the underlying reel view.
	var darkness := (0.50 + reveal * 0.32) * (1.0 - transform * 0.58)
	_full_background(Color(0.008, 0.004, 0.025, darkness * fade))
	_draw_stage_arch(fade * reveal * 0.55, _color)
	if not _reduced:
		_draw_character_power(p, fade * (0.42 + impact * 0.58), impact, origin)
	else:
		_ring(origin, 210, _color, 2, fade * 0.55)
	_draw_hero_entrance(p, reveal, transform, fade)
	# Foreground signature effects remain visible after the oversized portrait recedes.
	if not _reduced and p >= _timeline.y:
		match _id:
			"ares":
				_draw_particles(p, fade * impact, Color("ffdc89"), 26 + _quality * 14, true, _coin)
			"seraphine":
				_draw_particles(p, fade * impact, _color, 15 + _quality * 11, false, _gem)
			"noctis":
				_draw_fate_wheel(Vector2(360, 696), 210, p, fade * impact)
			"orion":
				_draw_black_hole(Vector2(360, 699), 126 + impact * 25, p, fade * impact)
			"vex":
				_draw_card_spiral(Vector2(360, 698), p, fade * impact, 10 + _quality * 3)
			"kael":
				_lightning(Vector2(360, 170), origin + Vector2(0, 135), 7, fade * impact * 0.9)
	if transform > 0.0:
		_draw_reel_transformation(p, transform, fade)
	# The label states the actual phase, not an unearned payout.
	var phase_text := "GÜÇ UYANIYOR"
	if p >= _timeline.z:
		phase_text = "MAKARALAR DÖNÜŞÜYOR"
	if p >= _timeline.w:
		phase_text = "GÖRSEL ÖNİZLEME TAMAMLANDI" if _preview_mode else "3 ÖZEL DÖNÜŞ HAZIR"
	_draw_text_center(_title.to_upper(), 950, 41, Color(1, 0.94, 0.78, fade))
	_draw_text_center(_power.to_upper(), 1007, 26, Color(_color, fade))
	_draw_text_center(phase_text, 1071, 21 if not _preview_mode else 18, Color(0.92, 0.90, 0.97, fade))

func _draw_hero_entrance(p: float, reveal: float, transform: float, fade: float) -> void:
	if _portrait == null:
		return
	var motion := 0.0 if _reduced else 1.0
	var hero_center := Vector2(360, 465).lerp(Vector2(360, 245), transform)
	var width := lerpf(545, 665, reveal) * lerpf(1.0, 0.47, transform)
	var offset := Vector2.ZERO
	var angle := 0.0
	match _id:
		"ares": offset.y = (1.0 - reveal) * 110 * motion
		"luna": offset.x = (1.0 - reveal) * -230 * motion
		"vex":
			offset.x = (1.0 - reveal) * 220 * motion
			angle = (1.0 - reveal) * -0.16 * motion
		"noctis": width *= 0.88 + reveal * 0.12
		"kael": offset.y = (1.0 - reveal) * -145 * motion
		"seraphine": offset.y = (1.0 - reveal) * 62 * motion
		"dante": width *= 1.08 - reveal * 0.08
		"orion":
			angle = (1.0 - reveal) * 0.10 * motion
			width *= 0.80 + reveal * 0.20
	if _reduced:
		# Reduced motion keeps the artwork fixed; only opacity and explanatory labels change.
		hero_center = Vector2(360, 430)
		width = 400
		offset = Vector2.ZERO
		angle = 0.0
		reveal = 1.0
	var center := hero_center + offset
	var alpha := fade * minf(1.0, 0.20 + reveal * 1.2) * (1.0 - transform * 0.12)
	# Luna's displaced spectral entrance is a dedicated effect, not a recoloured zoom.
	if _id == "luna" and not _reduced and reveal > 0.05 and transform < 0.7:
		var ghost_width := width * 0.96
		draw_texture_rect(_portrait, Rect2(center - Vector2.ONE * ghost_width * 0.5 + Vector2(-17, 0), Vector2.ONE * ghost_width), false, Color(_color, alpha * 0.17))
		draw_texture_rect(_portrait, Rect2(center - Vector2.ONE * ghost_width * 0.5 + Vector2(17, 0), Vector2.ONE * ghost_width), false, Color("6efff4", alpha * 0.17))
	_local(center, angle)
	var rect := Rect2(-Vector2.ONE * width * 0.5, Vector2.ONE * width)
	draw_texture_rect(_portrait, rect, false, Color(1, 1, 1, alpha))
	draw_rect(rect.grow(4), Color(_color, alpha * 0.80), false, 2, true)
	# A restrained glint at the face/mask, with no strobe or full-screen white flash.
	var eye_power := reveal * (1.0 - transform) * fade
	for side in [-1.0, 1.0]:
		var eye := Vector2(side * width * 0.060, -width * 0.185)
		draw_circle(eye, 10, Color(_color, eye_power * 0.13))
		draw_circle(eye, 3, Color(_color.lerp(Color.WHITE, 0.7), eye_power * 0.85))
		draw_line(eye - Vector2(14, 0), eye + Vector2(14, 0), Color(_color, eye_power * 0.7), 1.4, true)
	_restore_canvas()
	for side in [-1.0, 1.0]:
		var ornament := center + Vector2(side * (width * 0.5 + 5), -width * 0.5)
		_diamond(ornament, 10, _color, alpha)

func _draw_character_power(p: float, fade: float, impact: float, origin: Vector2) -> void:
	match _id:
		"ares": _ares(p, fade, impact, origin)
		"luna": _luna(p, fade, impact, origin)
		"vex": _vex(p, fade, impact, origin)
		"noctis": _noctis(p, fade, impact, origin)
		"kael": _kael(p, fade, impact, origin)
		"seraphine": _seraphine(p, fade, impact, origin)
		"dante": _dante(p, fade, impact, origin)
		"orion": _orion(p, fade, impact, origin)

func _ares(p: float, fade: float, impact: float, origin: Vector2) -> void:
	_shape_at("crown", Vector2(360, 185), Vector2.ONE * (0.85 + impact * 0.26), _color, fade)
	for i in range(7):
		var x := 54.0 + i * 102.0
		var drop := smoothstep(_timeline.y + i * 0.009, _timeline.y + 0.13 + i * 0.009, p)
		var end := lerpf(-200, _reel_rect.end.y, drop)
		_glow_line(Vector2(x, -40), Vector2(x, end), _color, 12, fade * impact * 0.8)
		if drop > 0.8:
			_ellipse(Vector2(x, _reel_rect.end.y), 52, 0, 0.26, _color, 3, fade * 0.7)
	_ring(origin, 294, Color("fff1b1"), 2.5, fade * 0.48)

func _luna(_p: float, fade: float, impact: float, origin: Vector2) -> void:
	for i in range(9):
		var y := 170.0 + i * 81.0
		var shift := sin(_time * 8 + i * 2.5) * 61 * impact
		draw_rect(Rect2(38 + shift, y, 630 - absf(shift), 3 + (i % 3) * 3), Color(_color, fade * 0.43))
	for i in range(7):
		var theta := float(i) * TAU / 7.0 - _time * 0.75
		_draw_rune(origin + Vector2.from_angle(theta) * 286, theta, 23, Color("62f7ea"), fade)
	_poly_glow(_shapes["fracture"], _color, fade * impact, false)
	_ring(origin, 255, Color("58ffd7"), 2, fade * 0.55)

func _vex(p: float, fade: float, impact: float, origin: Vector2) -> void:
	_draw_card_spiral(origin, p, fade, 12 + _quality * 3)
	for i in range(8):
		var direction := Vector2.from_angle(i * TAU / 8 + 0.4)
		var from := origin + direction * 95
		var middle := origin + direction.rotated(0.13) * 225
		var end := origin + direction * 530
		_glow_line(from, middle, _color, 2, fade * impact * 0.7)
		_glow_line(middle, end, _color, 2, fade * impact * 0.7)

func _draw_card_spiral(origin: Vector2, p: float, fade: float, count: int) -> void:
	for i in range(count):
		var item := _particles[i]
		var theta: float = item.phase + _time * 1.45
		var distance: float = 70 + (0.4 + p) * (80 + i * 12)
		var center := origin + Vector2.from_angle(theta) * distance
		_local(center, theta * 0.8)
		var rect := Rect2(-22, -34, 44, 68)
		draw_rect(rect, Color(0.19, 0.008, 0.031, fade * 0.95))
		draw_rect(rect, Color(_color, fade * 0.90), false, 2, true)
		if _joker != null:
			draw_texture_rect(_joker, Rect2(-17, -23, 34, 46), false, Color(1, 1, 1, fade))
		else:
			draw_circle(Vector2.ZERO, 5, Color("ffe6bc", fade))
		_restore_canvas()

func _noctis(p: float, fade: float, impact: float, origin: Vector2) -> void:
	_draw_fate_wheel(origin, 291, p, fade * 0.72)
	for side in [-1, 1]:
		for finger in range(5):
			var hand: PackedVector2Array = _shapes["hand_%d_%d" % [side, finger]]
			draw_colored_polygon(hand, Color(0.023, 0.005, 0.06, fade * impact))
			_poly_glow(hand, _color, fade * impact * 0.46)

func _draw_fate_wheel(center: Vector2, radius: float, p: float, fade: float) -> void:
	var rotation := _time * (4.8 - p * 3.5)
	_ring(center, radius + 8, Color("e5d1ff"), 4.5, fade)
	_ring(center, radius - 28, _color, 2, fade * 0.8)
	for i in range(12):
		var theta := i * TAU / 12 + rotation
		var next_theta := theta + TAU / 12
		draw_arc(center, radius - 10, theta, next_theta, 8, Color(_color.lerp(Color("ffe9b4"), float(i % 3) / 3), fade * 0.55), 20, true)
		_glow_line(center + Vector2.from_angle(theta) * 34, center + Vector2.from_angle(theta) * (radius - 24), _color, 1.5, fade * 0.8)
		var glyph := center + Vector2.from_angle(theta + 0.25) * (radius - 58)
		_draw_rune(glyph, theta, 15, Color("eadcff"), fade)
	draw_circle(center, 34, Color(0.035, 0.004, 0.08, fade))
	_diamond(center, 22, Color("e8d5ff"), fade)
	_glow_line(center + Vector2(0, -radius - 30), center + Vector2(-11, -radius + 12), Color("ffe9bb"), 4, fade)
	_glow_line(center + Vector2(0, -radius - 30), center + Vector2(11, -radius + 12), Color("ffe9bb"), 4, fade)

func _kael(p: float, fade: float, impact: float, origin: Vector2) -> void:
	for i in range(4):
		_lightning(Vector2(89 + i * 177, -60), Vector2(64 + i * 193, _reel_rect.end.y), i * 5.0, fade * impact)
	_shape_at("hammer", Vector2(360, 259), Vector2.ONE * 1.12, Color("dcf6ff"), fade * 0.85)
	for j in range(3):
		_ring(origin, 75 + fmod(_time * 190 + j * 97, 310), _color, 3.5, fade * impact * (0.75 - j * 0.15))
	if p > _timeline.z:
		for i in range(4):
			_lightning(Vector2(_reel_rect.position.x + 42 + i * 134, origin.y), Vector2(_reel_rect.position.x + 176 + i * 134, origin.y), i * 3.4, fade * 0.9)

func _seraphine(_p: float, fade: float, impact: float, origin: Vector2) -> void:
	for side in [-1.0, 1.0]:
		for feather in range(10):
			var angle := lerpf(-1.25, 0.45, float(feather) / 9.0)
			var root := origin + Vector2(side * 55, -95)
			var tip := root + Vector2(side * cos(angle), sin(angle)) * (195 + feather * 13) * (0.45 + impact * 0.55)
			_glow_line(root, tip, Color("ffdf9d"), 9, fade * 0.6)
			_glow_line(root + Vector2(0, 30), tip + Vector2(side * -20, 25), _color, 3, fade * 0.8)
	for i in range(10):
		var pos := origin + Vector2.from_angle(i * TAU / 10 + _time * 0.5) * 300
		_draw_token(_gem, pos, 31 + (i % 3) * 6, _color, fade)
	_ring(origin, 321, Color("ffdf99"), 2, fade * 0.8)

func _dante(_p: float, fade: float, impact: float, origin: Vector2) -> void:
	_shape_at("throne", Vector2(360, 570), Vector2.ONE * 1.15, _color, fade)
	_local(Vector2(360, 792))
	draw_colored_polygon(_shapes["table"], Color(0.12, 0.023, 0.025, fade * impact))
	_poly_glow(_shapes["table"], _color, fade * impact)
	_restore_canvas()
	for side in [-1.0, 1.0]:
		for i in range(12):
			var pos := Vector2(360 + side * (258 + sin(i * 0.36) * 25), 237 + i * 47)
			draw_arc(pos, 13, 0, TAU, 14, Color(_color, fade * impact), 3, true)
		for i in range(3):
			_draw_token(_gem, Vector2(360 + side * 278, 337 + i * 150), 49, Color("ff4761"), fade * impact)
	_shape_at("crown", Vector2(origin.x, 174), Vector2.ONE * 0.7, _color, fade)

func _orion(p: float, fade: float, impact: float, origin: Vector2) -> void:
	_draw_black_hole(origin, 195 + impact * 65, p, fade * 0.78)
	for i in range(5):
		var angle := i * TAU / 5 + _time * (0.27 + i * 0.1)
		var orbit := 263 + i * 18
		var pos := origin + Vector2(cos(angle) * orbit, sin(angle) * orbit * 0.80)
		draw_circle(pos, 14 + i * 4, Color(_color.lerp(Color("65cbff"), i * 0.15), fade))
		_ellipse(pos, 24 + i * 5, -0.3, 0.45, Color("afb7ff"), 1.4, fade * 0.75)

func _draw_black_hole(origin: Vector2, radius: float, p: float, fade: float) -> void:
	for i in range(4 + _quality):
		var disk_radius := radius * (0.90 + i * 0.12)
		_ellipse(origin, disk_radius, -0.28 + sin(_time * 0.3) * 0.08, 0.32 + i * 0.018, _color.lerp(Color("79e1ff"), i * 0.12), 5 - i * 0.45, fade * (0.80 - i * 0.06))
	var black_radius := radius * 0.39
	draw_circle(origin, black_radius + 10, Color(_color, fade * 0.10))
	draw_circle(origin, black_radius, Color(0.002, 0.001, 0.009, fade))
	_ring(origin, black_radius + 2, Color("e9d9ff"), 5, fade * 0.95)
	if p >= _timeline.z:
		var eruption := smoothstep(_timeline.z, 1.0, p)
		_ring(origin, black_radius + eruption * 470, Color("c6beff"), 5, fade * 0.65)
		for i in range(18):
			var theta := i * TAU / 18 + _time * 0.08
			_glow_line(origin + Vector2.from_angle(theta) * black_radius, origin + Vector2.from_angle(theta) * (black_radius + eruption * 520), _color, 2, fade * eruption * 0.5)

func _draw_reel_transformation(p: float, progress: float, fade: float) -> void:
	var rect := _reel_rect.grow(-5)
	var center := rect.get_center()
	var beam_y := lerpf(rect.position.y, rect.end.y, progress)
	var column_width := rect.size.x / 5
	if not _reduced:
		_glow_line(Vector2(rect.position.x, beam_y), Vector2(rect.end.x, beam_y), _color, 8, fade * 0.80)
		for wave in range(2 + _quality):
			_ellipse(center, 95 + progress * 265 + wave * 21, 0, 0.72, _color, 2, fade * (0.55 - wave * 0.10))
	draw_rect(rect, Color(_color, fade * 0.16), false, 13, true)
	draw_rect(rect.grow(5), Color(_color, fade * 0.7), false, 2, true)
	for column in range(5):
		var x := rect.position.x + column_width * (column + 0.5)
		var column_rect := Rect2(x - column_width * 0.40, rect.position.y + 8, column_width * 0.8, rect.size.y - 16)
		var token_center := Vector2(x, center.y)
		match _id:
			"ares":
				if column % 2 == 0:
					_draw_token(_coin, token_center, 78, Color.WHITE, fade * progress)
			"luna":
				if column == 1 or column == 3:
					draw_rect(column_rect, Color(_color, fade * progress * 0.18))
					_draw_token(_wild, token_center, 84, Color.WHITE, fade * progress)
			"vex":
				_draw_token(_joker, token_center + Vector2(0, 0 if _reduced else sin(_time * 4 + column) * 14), 67, Color.WHITE, fade * progress)
			"noctis":
				_draw_rune(token_center, p * TAU + column, 29, _color, fade * progress)
			"kael":
				if column % 2 == 0:
					if not _reduced:
						_lightning(Vector2(x, rect.position.y), Vector2(x, rect.end.y), column, fade * progress)
					_draw_token(_wild, token_center, 74, Color.WHITE, fade * progress)
			"seraphine": _draw_token(_gem, token_center, 73, Color.WHITE, fade * progress)
			"dante":
				if column == 2:
					_shape_at("crown", token_center, Vector2.ONE * 0.32, _color, fade * progress)
			"orion":
				if column == 2:
					draw_rect(column_rect, Color(_color, fade * progress * 0.22))
					_draw_token(_wild, token_center, 86, Color.WHITE, fade * progress)
	if _id == "ares":
		_draw_text_center("ÇARPANLAR  ×2  ·  ×3  ·  ×5", rect.end.y + 47, 23, Color(_color, fade * progress))
	elif _id == "orion":
		_draw_text_center("KOZMİK JOKER VE ÇARPAN GÜCÜ", rect.end.y + 47, 20, Color(_color, fade * progress))

func _draw_stage_arch(alpha: float, tint: Color) -> void:
	if alpha <= 0.01:
		return
	for side in [-1.0, 1.0]:
		var x: float = 360 + side * 293
		_glow_line(Vector2(x, 230), Vector2(x, 943), tint, 3.5, alpha * 0.6)
		_glow_line(Vector2(x + side * 19, 230), Vector2(x + side * 19, 943), tint, 1.5, alpha * 0.5)
		for y in [230, 870, 927]:
			_glow_line(Vector2(x - 35, y), Vector2(x + 35, y), tint, 3, alpha * 0.8)
	draw_arc(Vector2(360, 336), 300, PI, TAU, 64, Color(tint, alpha * 0.7), 3, true)
	draw_arc(Vector2(360, 336), 322, PI, TAU, 64, Color(tint, alpha * 0.3), 2, true)

func _draw_win(p: float, fade: float) -> void:
	var grand := _tier >= 5
	var intensity := float(_tier + 1) / 7.0
	var reward_center := Vector2(360, 836) if grand else Vector2(360, 620)
	if _tier >= 2:
		if _tier == 6 and _palace != null:
			draw_texture_rect(_palace, Rect2(0, 0, 720, 1280), false, Color(0.65, 0.45, 0.70, fade * 0.66))
		_full_background(Color(0.012, 0.004, 0.027, fade * (0.48 if _tier < 5 else 0.67)))
	if not _reduced:
		match _tier:
			0:
				_ellipse(reward_center, 165, 0, 0.30, _color, 2, fade * 0.55)
			1:
				_ring(reward_center, 185 + p * 43, _color, 3, fade * 0.7)
				_draw_particles(p, fade, _color, 16 + _quality * 3, true, _coin)
			2:
				_draw_radial_rays(reward_center, 22, 92 + p * 90, 260 + p * 80, fade * 0.65)
				_draw_particles(p, fade, _color, 26 + _quality * 6, true, _coin)
			3:
				_ring(reward_center, 135 + p * 270, _color, 4, fade * 0.85)
				_ring(reward_center, 145 + p * 290, Color("ffcaee"), 1.5, fade * 0.5)
				_draw_particles(p, fade, _color, 23 + _quality * 5, true, _gem)
			4:
				_draw_stage_arch(fade * 0.80, _color)
				_draw_radial_rays(reward_center, 28, 115, 450, fade * 0.55)
				_draw_particles(p, fade, _color, 34 + _quality * 8, true, _coin)
			5:
				_draw_stage_arch(fade * 0.95, _color)
				_draw_radial_rays(Vector2(360, 444), 30, 225, 565, fade * 0.6)
				_draw_particles(p, fade, _color, 44 + _quality * 10, true, _coin)
			6:
				_draw_stage_arch(fade, Color("fff0ad"))
				_draw_radial_rays(Vector2(360, 450), 36, 190, 690, fade * 0.5)
				_draw_fireworks(p, fade)
				_draw_particles(p, fade, Color("ffda78"), 55 + _quality * 11, true, _coin)
				for i in range(9):
					_draw_token(_gem, Vector2(80 + i * 71, 1080 + sin(p * TAU + i) * 45), 28 + i % 3 * 8, Color.WHITE, fade * 0.75)
	elif _tier >= 3:
		_draw_stage_arch(fade * 0.3, _color)
	_draw_victory(p, fade, intensity, grand)
	var title_y := 760.0 if grand else 556.0
	var number_y := 850.0 if grand else 634.0
	var title_size := 30 if _title.length() > 19 else (43 if grand else 36)
	_draw_text_center(_title, title_y, title_size, Color(_color, fade))
	var count_progress := smoothstep(0.0, 0.69, p)
	var counter := "+" + _format_amount(int(_amount * count_progress))
	var number_size := maxi(31, (66 if grand else 57) - maxi(0, counter.length() - 11) * 3)
	_draw_text_center(counter, number_y, number_size, Color(1, 0.96, 0.79, fade))
	_draw_text_center("SANAL ÇİP", number_y + 41, 20, Color(0.9, 0.87, 0.93, fade))
	if _tier == 6:
		_draw_text_center("İMPARATORLUĞUN EN GÖRKEMLİ ANI", 974, 18, Color("e9d3a2", fade))

func _draw_victory(p: float, fade: float, intensity: float, grand: bool) -> void:
	var center := Vector2(360, 389)
	var width := lerpf(145, 293, intensity)
	if grand:
		center = Vector2(360, 402)
		width = 548 if _tier == 5 else 614
	var offset := Vector2.ZERO
	var angle := 0.0
	var reveal := smoothstep(0.0, 0.25, p)
	var motion := 0.0 if _reduced else 1.0
	match _id:
		"ares":
			offset.y = (1.0 - reveal) * 30 * motion
			_shape_at("crown", center + Vector2(0, -width * 0.63), Vector2.ONE * width / 430, _color, fade)
		"luna":
			offset.x = sin(p * TAU) * 14 * motion
			for i in range(4):
				var theta := i * PI / 2 + _time * 0.5 * motion
				_draw_rune(center + Vector2.from_angle(theta) * width * 0.65, theta, 14, Color("62f7ea"), fade)
		"vex":
			angle = sin(p * TAU * 1.5) * 0.060 * motion
			if not _reduced:
				_draw_card_spiral(center, p * 0.35, fade * 0.80, 5 + _quality)
		"noctis":
			offset.y = sin(p * TAU) * 6 * motion
			if not _reduced:
				_draw_fate_wheel(center, width * 0.62, p, fade * 0.65)
			else:
				_ring(center, width * 0.62, _color, 2, fade * 0.5)
		"kael":
			offset.y = -sin(p * PI) * 14 * motion
			if not _reduced:
				_lightning(center + Vector2(-width * 0.62, -70), center + Vector2(-width * 0.65, 110), 1, fade * 0.8)
				_lightning(center + Vector2(width * 0.62, -70), center + Vector2(width * 0.65, 110), 4, fade * 0.8)
		"seraphine":
			offset.y = -sin(p * PI) * 8 * motion
			for side in [-1.0, 1.0]:
				for feather in range(4):
					_glow_line(center + Vector2(side * width * 0.35, 25), center + Vector2(side * (width * 0.65 + feather * 12), -35 - feather * 20), Color("ffd997"), 3, fade * 0.8)
			for i in range(3):
				_draw_token(_gem, center + Vector2(-40 + i * 40, -width * 0.64), 26, _color, fade)
		"dante":
			offset.y = (1.0 - reveal) * -15 * motion
			for side in [-1.0, 1.0]:
				for link in range(7):
					draw_arc(center + Vector2(side * width * 0.61, -width * 0.42 + link * width * 0.1), 8, 0, TAU, 12, Color(_color, fade * 0.8), 2, true)
				_diamond(center + Vector2(side * width * 0.61, -width * 0.52), 13, Color("ff5367"), fade)
		"orion":
			angle = sin(p * PI) * 0.025 * motion
			for i in range(3):
				var theta := i * TAU / 3 + _time * 0.8 * motion
				var planet := center + Vector2(cos(theta), sin(theta) * 0.7) * width * 0.68
				draw_circle(planet, 9 + i * 3, Color(_color, fade * 0.9))
				_ellipse(planet, 17 + i * 4, -0.3, 0.45, Color("78dcff"), 1.5, fade * 0.7)
	if _portrait != null:
		_local(center + offset, angle)
		var rect := Rect2(-Vector2.ONE * width * 0.5, Vector2.ONE * width)
		draw_texture_rect(_portrait, rect, false, Color(1, 1, 1, fade * 0.94))
		draw_rect(rect.grow(3), Color(_color, fade * 0.85), false, 2, true)
		_restore_canvas()

func _draw_radial_rays(center: Vector2, count: int, inner: float, outer: float, alpha: float) -> void:
	for i in range(count):
		var theta := float(i) * TAU / count + _time * 0.07
		_glow_line(center + Vector2.from_angle(theta) * inner, center + Vector2.from_angle(theta) * outer, _color, 1.5 if i % 2 == 0 else 3, alpha * (0.45 if i % 2 == 0 else 0.75))

func _draw_fireworks(p: float, fade: float) -> void:
	for burst in range(3):
		var origin := Vector2(130 + burst * 230, 190 + (burst % 2) * 46)
		var start := 0.12 + burst * 0.14
		var progress := clampf((p - start) / 0.57, 0, 1)
		if progress <= 0.0:
			continue
		var eased := 1.0 - pow(1.0 - progress, 2)
		var tint := _color.lerp(Color("e8c4ff"), burst * 0.20)
		for spark in range(12 + _quality * 6):
			var item := _particles[burst * 25 + spark]
			var theta: float = item.phase
			var distance: float = eased * (90 + item.speed * 120)
			var end := origin + Vector2.from_angle(theta) * distance + Vector2(0, progress * progress * 70)
			var trail := end - Vector2.from_angle(theta) * (12 + 19 * (1.0 - progress))
			_glow_line(trail, end, tint, 2.0, fade * (1.0 - progress) * 0.9)
			draw_circle(end, 2.3, Color(tint.lerp(Color.WHITE, 0.6), fade * (1.0 - progress)))
		_ring(origin, 12 + eased * 190, tint, 1.5, fade * (1.0 - progress) * 0.45)

func _draw_particles(p: float, fade: float, tint: Color, count: int, rain: bool, token: Texture2D = null) -> void:
	for i in range(mini(count, _particles.size())):
		var item := _particles[i]
		var pos: Vector2
		if rain:
			pos = Vector2(item.x * 720, fmod(item.y * 1280 + _time * item.speed * 515, 1390) - 70)
		else:
			var theta: float = item.phase + _time * 0.35
			pos = _reel_rect.get_center() + Vector2.from_angle(theta) * (85 + p * item.speed * 405)
		var spin: float = 0.48 + 0.52 * absf(cos(_time * 3.5 + item.phase))
		var width: float = item.size * 6.4
		if token != null:
			var token_size := Vector2(width * spin, width)
			draw_texture_rect(token, Rect2(pos - token_size * 0.5, token_size), false, Color(1, 1, 1, fade * 0.88))
		else:
			draw_circle(pos, item.size * 0.60, Color(tint, fade * 0.85))

func _draw_token(token: Texture2D, pos: Vector2, width: float, tint: Color, alpha: float) -> void:
	if token != null:
		draw_texture_rect(token, Rect2(pos - Vector2.ONE * width * 0.5, Vector2.ONE * width), false, Color(tint, alpha))
	else:
		_diamond(pos, width * 0.24, tint, alpha)

func _shape_at(shape: String, center: Vector2, shape_scale: Vector2, tint: Color, alpha: float) -> void:
	_local(center, 0.0, shape_scale)
	var points: PackedVector2Array = _shapes[shape]
	draw_colored_polygon(points, Color(tint, alpha * 0.08))
	_poly_glow(points, tint, alpha)
	_restore_canvas()

func _ring(pos: Vector2, radius: float, tint: Color, width: float, alpha: float) -> void:
	if _quality > 0:
		draw_arc(pos, radius, 0, TAU, 64, Color(tint, alpha * 0.10), width * 5, true)
	draw_arc(pos, radius, 0, TAU, 64 if _quality > 0 else 32, Color(tint, alpha), width, true)

func _ellipse(pos: Vector2, radius: float, rotation: float, flatten: float, tint: Color, width: float, alpha: float) -> void:
	_local(pos, rotation, Vector2(1, flatten))
	_ring(Vector2.ZERO, radius, tint, width, alpha)
	_restore_canvas()

func _glow_line(start: Vector2, end: Vector2, tint: Color, width: float, alpha: float) -> void:
	if _quality > 0:
		draw_line(start, end, Color(tint, alpha * 0.12), width * 4, true)
	draw_line(start, end, Color(tint, alpha), width, true)
	if _quality > 1:
		draw_line(start, end, Color(tint.lerp(Color.WHITE, 0.6), alpha * 0.70), maxf(1, width * 0.24), true)

func _poly_glow(points: PackedVector2Array, tint: Color, alpha: float, closed: bool = true) -> void:
	if _quality > 0:
		draw_polyline(points, Color(tint, alpha * 0.12), 10, true)
	draw_polyline(points, Color(tint, alpha), 2, true)
	if closed:
		_glow_line(points[points.size() - 1], points[0], tint, 2, alpha)

func _lightning(start: Vector2, end: Vector2, phase: float, alpha: float) -> void:
	var perpendicular := (end - start).normalized().orthogonal()
	var previous := start
	var steps := 8 if _quality == 0 else 12
	for step in range(1, steps + 1):
		var fraction := float(step) / steps
		# Continuous branches avoid repeated light flashes and geometry allocation.
		var offset := sin(step * 8.16 + _time * 5.0 + phase) * 37 * sin(fraction * PI)
		var next := start.lerp(end, fraction) + perpendicular * offset
		_glow_line(previous, next, Color("b2efff"), 3.5, alpha)
		previous = next

func _diamond(pos: Vector2, radius: float, tint: Color, alpha: float) -> void:
	_local(pos, 0, Vector2.ONE * radius)
	var points: PackedVector2Array = _shapes["diamond"]
	draw_colored_polygon(points, Color(tint, alpha * 0.20))
	# Compensate line width for the unit-template scale so ornament edges stay delicate.
	var stroke := 1.5 / maxf(radius, 1.0)
	if _quality > 0:
		draw_polyline(points, Color(tint, alpha * 0.12), stroke * 5, true)
	draw_polyline(points, Color(tint, alpha), stroke, true)
	draw_line(points[3], points[0], Color(tint, alpha), stroke, true)
	_restore_canvas()

func _draw_rune(pos: Vector2, angle: float, radius: float, tint: Color, alpha: float) -> void:
	var first := pos + Vector2.from_angle(angle) * radius
	var previous := first
	for i in range(1, 5):
		var next := pos + Vector2.from_angle(angle + i * PI / 2) * radius
		_glow_line(previous, next, tint, 1.5, alpha)
		previous = next
	_glow_line(first, pos - Vector2.from_angle(angle) * radius, tint, 1, alpha)

func _draw_text_center(message: String, baseline: float, font_size: int, tint: Color) -> void:
	var text_width := _font.get_string_size(message, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	var x := (720.0 - text_width) * 0.5
	draw_string(_font, Vector2(x + 2, baseline + 3), message, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color(0, 0, 0, tint.a * 0.8))
	draw_string(_font, Vector2(x, baseline), message, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, tint)

func _format_amount(amount: int) -> String:
	var digits := str(amount)
	var result := ""
	for i in range(digits.length()):
		if i > 0 and (digits.length() - i) % 3 == 0:
			result += "."
		result += digits[i]
	return result
