class_name ReelController
extends Control
## Presentation only: a prebuilt strip scrolls to the already computed result.
## Transformations reveal the engine's real changes; visual RNG never reaches math.

signal settled
signal column_stopped(column: int)

var grid: Array = []
var final_grid: Array = []
var textures: Dictionary = {}
var symbols := ["crown", "gem", "chalice", "ring", "ace", "wild", "scatter"]
var rows := 3
var spinning := false
var spin_clock := 0.0
var duration := 1.6
var active_wins: Array = []
var accent := Color("edc979")
var clock := 0.0
var reduced := false
var spin_rng := RandomNumberGenerator.new()
var normal_plate: StyleBoxFlat
var win_plate: StyleBoxFlat
var stopped_columns: Array[bool] = [false, false, false, false, false]

# Bounded presentation state; textures and plates are cached once.
var _strips: Array = []
var _landing_indices: PackedInt32Array = PackedInt32Array([0, 0, 0, 0, 0])
var _scroll_positions: PackedFloat32Array = PackedFloat32Array([0, 0, 0, 0, 0])
var _stop_times: PackedFloat32Array = PackedFloat32Array([0, 0, 0, 0, 0])
var _natural_grid: Array = []
var _pending_wins: Array = []
var _changes: Array = []
var _transforming := false
var _transform_clock := 0.0
var _transform_duration := 0.42
var _bounce_duration := 0.12
var _win_mask := PackedByteArray()
var _transform_progress := PackedFloat32Array()
var _cell_rects: Array[Rect2] = []
var _centers: Array[Vector2] = []
var _rays: Array[Vector2] = []
var _geometry_rows := 0
var _geometry_size := Vector2.ZERO
var _cached_accent := Color.TRANSPARENT
var _symbol_dimension := 96.0
var _glow_texture: Texture2D
var _spark_texture: Texture2D

# Reviewable counters. No StyleBox, texture, Node, Array or Dictionary is created in _draw.
var visual_symbol_draws := 0
var max_visual_symbol_draws := 0
var column_stop_count := 0
var transform_cell_count := 0
var spin_serial := 0
var cached_style_count := 0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true
	spin_rng.randomize()
	normal_plate = _make_plate(false)
	win_plate = _make_plate(true)
	cached_style_count = 2
	for id in symbols:
		var path: String = "res://assets/art/symbol_%s.svg" % id
		if ResourceLoader.exists("res://assets/art/symbol_%s.png" % id):
			path = "res://assets/art/symbol_%s.png" % id
		if ResourceLoader.exists(path):
			textures[id] = load(path)
	for path in ["res://assets/vfx/glow.png", "res://assets/art/fx_glow.png", "res://assets/art/particle_glow.png"]:
		if ResourceLoader.exists(path):
			_glow_texture = load(path) as Texture2D
			break
	for path in ["res://assets/vfx/spark.png", "res://assets/art/fx_spark.png", "res://assets/art/particle_spark.png"]:
		if ResourceLoader.exists(path):
			_spark_texture = load(path) as Texture2D
			break
	for index in range(8):
		_rays.append(Vector2.from_angle(float(index) * TAU / 8.0))
	resized.connect(_update_geometry)
	set_grid([])

func set_grid(value: Array) -> void:
	if value.is_empty():
		grid = []
		for column in range(5):
			var col: Array = []
			for row in range(rows):
				col.append(symbols[(column * 3 + row * 2) % 5])
			grid.append(col)
	else:
		grid = value.duplicate(true)
		rows = grid[0].size()
	_update_geometry()
	queue_redraw()

func animate_result(result: Dictionary, turbo: bool = false) -> void:
	if spinning:
		await settled
	if not result.get("grid", []) is Array or result.get("grid", []).size() != 5:
		return
	final_grid = result.grid.duplicate(true)
	rows = final_grid[0].size()
	if grid.size() != 5 or grid[0].size() != rows:
		set_grid([])
	_update_geometry()
	active_wins = []
	_pending_wins = result.get("wins", []).duplicate(true)
	_natural_grid = _reconstruct_natural(result)
	_prepare_changes()
	duration = 0.48 if turbo else 1.46
	if reduced:
		duration = 0.42 if turbo else 0.88
	_bounce_duration = 0.0 if reduced else (0.075 if turbo else 0.12)
	_transform_duration = (0.20 if turbo else 0.42) if not reduced else 0.16
	spin_clock = 0.0
	_transform_clock = 0.0
	_transforming = false
	stopped_columns = [false, false, false, false, false]
	column_stop_count = 0
	spin_serial += 1
	_prepare_strips()
	spinning = true
	await settled

func _reconstruct_natural(result: Dictionary) -> Array:
	var explicit: Variant = result.get("natural_grid", null)
	if explicit is Array and explicit.size() == 5:
		return explicit.duplicate(true)
	var natural: Array = final_grid.duplicate(true)
	var transformations: Array = result.get("transformations", [])
	# Reverse the ordered real mutations, including repeated mutations of one cell.
	for index in range(transformations.size() - 1, -1, -1):
		var change: Dictionary = transformations[index]
		var cell := _as_cell(change.get("cell", Vector2i(-1, -1)))
		if cell.x >= 0 and cell.x < 5 and cell.y >= 0 and cell.y < rows:
			natural[cell.x][cell.y] = str(change.get("from", natural[cell.x][cell.y]))
	return natural

func _prepare_changes() -> void:
	_changes.clear()
	_transform_progress.fill(-1.0)
	for column in range(5):
		for row in range(rows):
			if str(_natural_grid[column][row]) != str(final_grid[column][row]):
				_changes.append({"cell": Vector2i(column, row), "from": str(_natural_grid[column][row]), "to": str(final_grid[column][row]), "delay": column * 0.055 + row * 0.025})
	transform_cell_count = _changes.size()

func _prepare_strips() -> void:
	_strips.clear()
	for column in range(5):
		var strip: Array = []
		# Initial visible icons are the previous true result, never a sudden random swap.
		for row in range(rows):
			strip.append(str(grid[column][row]))
		var travel := 9 + column * 2
		for index in range(travel):
			strip.append(symbols[spin_rng.randi_range(0, symbols.size() - 1)])
		_landing_indices[column] = strip.size()
		for row in range(rows):
			strip.append(str(_natural_grid[column][row]))
		strip.append(symbols[spin_rng.randi_range(0, symbols.size() - 1)])
		_strips.append(strip)
		_scroll_positions[column] = 0.0
		_stop_times[column] = duration * (0.56 + column * 0.11)

func _process(delta: float) -> void:
	clock += delta
	if _geometry_rows != rows or _geometry_size != size:
		_update_geometry()
	if _cached_accent != accent and normal_plate != null:
		_cached_accent = accent
		normal_plate.border_color = Color(accent, 0.28)
		win_plate.border_color = Color(accent.lightened(0.12), 0.96)
		win_plate.shadow_color = Color(accent, 0.16)
	_update_win_mask()
	if spinning:
		spin_clock += delta
		if _transforming:
			_transform_clock += delta
			_update_transformations()
		else:
			for column in range(5):
				var progress := clampf(spin_clock / _stop_times[column], 0.0, 1.0)
				# A cubic trajectory accelerates smoothly, then decelerates to its true stop.
				var eased := progress * progress * (3.0 - 2.0 * progress)
				_scroll_positions[column] = float(_landing_indices[column]) * eased
				if progress >= 1.0 and not stopped_columns[column]:
					grid[column] = _natural_grid[column].duplicate()
					stopped_columns[column] = true
					column_stop_count += 1
					column_stopped.emit(column)
			if spin_clock >= duration + _bounce_duration:
				if _changes.is_empty():
					_finish_spin()
				else:
					_transforming = true
					_update_transformations()
	queue_redraw()

func _update_transformations() -> void:
	for change in _changes:
		var cell: Vector2i = change.cell
		var delay := float(change.delay) * _transform_duration
		var progress := clampf((_transform_clock - delay) / maxf(_transform_duration * 0.70, 0.01), 0.0, 1.0)
		_transform_progress[cell.x * rows + cell.y] = progress
		if progress >= 0.5:
			grid[cell.x][cell.y] = change.to
	if _transform_clock >= _transform_duration:
		_finish_spin()

func _finish_spin() -> void:
	grid = final_grid.duplicate(true)
	spinning = false
	_transforming = false
	_transform_progress.fill(-1.0)
	active_wins = _pending_wins
	_update_win_mask()
	settled.emit()

func _as_cell(value: Variant) -> Vector2i:
	if value is Vector2i:
		return value
	if value is Array and value.size() >= 2:
		return Vector2i(int(value[0]), int(value[1]))
	return Vector2i(-1, -1)

func _update_geometry() -> void:
	_geometry_rows = rows
	_geometry_size = size
	_cell_rects.clear()
	_centers.clear()
	_win_mask.resize(5 * rows)
	_win_mask.fill(0)
	_transform_progress.resize(5 * rows)
	_transform_progress.fill(-1.0)
	var width := size.x / 5.0
	var height := size.y / maxf(float(rows), 1)
	_symbol_dimension = minf(width - 18.0, height - (20.0 if rows == 3 else 12.0))
	for column in range(5):
		for row in range(rows):
			var rect := Rect2(Vector2(column * width + 3, row * height + 3), Vector2(width - 6, height - 6))
			_cell_rects.append(rect)
			_centers.append(rect.get_center())

func _update_win_mask() -> void:
	_win_mask.fill(0)
	for win in active_wins:
		for raw_cell in win.get("cells", []):
			var cell := _as_cell(raw_cell)
			if cell.x >= 0 and cell.x < 5 and cell.y >= 0 and cell.y < rows:
				_win_mask[cell.x * rows + cell.y] = 1

func _cell_wins(column: int, row: int) -> bool:
	var index := column * rows + row
	return index < _win_mask.size() and _win_mask[index] == 1

func _draw() -> void:
	if normal_plate == null or _cell_rects.size() != 5 * rows:
		return
	visual_symbol_draws = 0
	var column_width := size.x / 5.0
	var row_height := size.y / float(rows)
	draw_rect(Rect2(Vector2.ZERO, size), Color("080711"))
	for index in range(_cell_rects.size()):
		var rect: Rect2 = _cell_rects[index]
		var won := _win_mask[index] == 1
		draw_style_box(win_plate if won else normal_plate, rect)
		# Two bevel edges and a glass highlight give real depth without extra materials.
		draw_line(rect.position + Vector2(12, 2), rect.position + Vector2(rect.size.x - 12, 2), Color(accent, 0.34 if won else 0.14), 1.6)
		draw_line(rect.position + Vector2(7, rect.size.y - 3), rect.end - Vector2(7, 3), Color(0, 0, 0, 0.75), 2)
		draw_rect(Rect2(rect.position + Vector2(6, 6), Vector2(rect.size.x - 12, 17)), Color(1, 0.96, 0.83, 0.035))
		if won:
			_draw_glow(_centers[index], _symbol_dimension * 0.58, accent, 0.24 if reduced else 0.32 + 0.08 * sin(clock * 5.0))
	for column in range(5):
		if spinning and not _transforming and not stopped_columns[column] and not reduced:
			var position := _scroll_positions[column]
			var whole := int(floor(position))
			var fraction := position - whole
			var travel_progress := clampf(spin_clock / _stop_times[column], 0, 1)
			var speed := 6.0 * travel_progress * (1.0 - travel_progress) * float(_landing_indices[column]) / _stop_times[column]
			for visible_row in range(-1, rows + 1):
				var symbol_index := whole + visible_row
				if symbol_index < 0 or symbol_index >= _strips[column].size():
					continue
				var center := Vector2((column + 0.5) * column_width, (visible_row + 0.5 - fraction) * row_height)
				var id: String = _strips[column][symbol_index]
				if speed > 9.0:
					_draw_symbol(id, center + Vector2(0, 6), _symbol_dimension, 0.065)
				_draw_symbol(id, center, _symbol_dimension, 0.91)
		else:
			var bounce := 0.0
			if spinning and not _transforming and not reduced and _bounce_duration > 0:
				var stop_age := clampf((spin_clock - _stop_times[column]) / _bounce_duration, 0.0, 1.0)
				bounce = sin(stop_age * PI * 2.0) * exp(-stop_age * 3.5) * row_height * 0.09
			for row in range(rows):
				var index := column * rows + row
				var center: Vector2 = _centers[index] + Vector2(0, bounce)
				var transform := _transform_progress[index]
				var won := _win_mask[index] == 1
				if _transforming and transform >= 0:
					_draw_transformation(column, row, center, transform)
				else:
					var pulse := 1.0 if reduced or not won else 1.0 + 0.022 * sin(clock * 5.0)
					_draw_symbol(str(grid[column][row]), center, _symbol_dimension * pulse, 1.0)
				if won:
					_draw_winning_spark(center, index)
	# Vertical brass separators and a restrained edge shade keep scrolling strips legible.
	for column in range(1, 5):
		draw_line(Vector2(column * column_width, 3), Vector2(column * column_width, size.y - 3), Color(accent, 0.18), 1)
	draw_rect(Rect2(0, 0, size.x, 7), Color(0, 0, 0, 0.45))
	draw_rect(Rect2(0, size.y - 7, size.x, 7), Color(0, 0, 0, 0.45))
	max_visual_symbol_draws = maxi(max_visual_symbol_draws, visual_symbol_draws)

func _draw_symbol(id: String, center: Vector2, dimension: float, opacity: float) -> void:
	if textures.has(id) and opacity > 0.001:
		draw_texture_rect(textures[id], Rect2(center - Vector2.ONE * dimension * 0.5, Vector2.ONE * dimension), false, Color(1, 1, 1, opacity))
		visual_symbol_draws += 1

func _draw_transformation(column: int, row: int, center: Vector2, progress: float) -> void:
	var from: String = str(_natural_grid[column][row])
	var to: String = str(final_grid[column][row])
	if reduced:
		_draw_symbol(from, center, _symbol_dimension, 1.0 - progress)
		_draw_symbol(to, center, _symbol_dimension, progress)
		return
	var impact := sin(progress * PI)
	var power_color := Color("ffd980") if to == "crown" else accent.lightened(0.25)
	_draw_glow(center, _symbol_dimension * (0.48 + progress * 0.35), power_color, impact * 0.55)
	_draw_symbol(from, center, _symbol_dimension * (1.0 - 0.18 * impact), 1.0 - smoothstep(0.24, 0.58, progress))
	_draw_symbol(to, center, _symbol_dimension * (0.72 + 0.28 * smoothstep(0.30, 0.78, progress) + 0.08 * impact), smoothstep(0.28, 0.66, progress))
	if progress > 0.24 and progress < 0.88:
		var radius := _symbol_dimension * (0.25 + 0.42 * progress)
		draw_arc(center, radius, 0, TAU, 24, Color(power_color, impact * 0.62), 1.7, true)
		for direction in _rays:
			draw_line(center + direction * radius * 0.80, center + direction * radius * 1.05, Color(power_color, impact * 0.45), 1.4, true)

func _draw_glow(center: Vector2, radius: float, color: Color, opacity: float) -> void:
	if _glow_texture != null:
		draw_texture_rect(_glow_texture, Rect2(center - Vector2.ONE * radius, Vector2.ONE * radius * 2.0), false, Color(color, opacity))
	else:
		# Three bounded soft layers; no particle objects or random allocation per frame.
		draw_circle(center, radius, Color(color, opacity * 0.08))
		draw_circle(center, radius * 0.72, Color(color, opacity * 0.13))
		draw_circle(center, radius * 0.43, Color(color, opacity * 0.16))

func _draw_winning_spark(center: Vector2, index: int) -> void:
	var rect: Rect2 = _cell_rects[index]
	draw_rect(rect.grow(-4), Color(accent.lightened(0.22), 0.44 if reduced else 0.64), false, 1.5)
	if reduced:
		return
	var phase := fmod(clock * 0.65 + float(index) * 0.17, 1.0)
	var spark_center := center + Vector2(sin(phase * TAU + index) * _symbol_dimension * 0.38, -_symbol_dimension * 0.32)
	var strength := pow(maxf(sin(phase * PI), 0.0), 3)
	if _spark_texture != null:
		var dimension := 22.0 + strength * 13.0
		draw_texture_rect(_spark_texture, Rect2(spark_center - Vector2.ONE * dimension * 0.5, Vector2.ONE * dimension), false, Color(accent.lightened(0.4), strength * 0.8))
	else:
		for ray in range(4):
			var direction: Vector2 = _rays[ray * 2]
			draw_line(spark_center, spark_center + direction * (4.0 + strength * 9), Color(1, 0.93, 0.70, strength * 0.72), 1.4, true)

func _make_plate(won: bool) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color("30243b") if won else Color("191321")
	style.border_color = Color(accent, 0.96 if won else 0.28)
	style.set_border_width_all(2 if won else 1)
	style.set_corner_radius_all(11)
	style.shadow_color = Color(accent, 0.16) if won else Color(0, 0, 0, 0.46)
	style.shadow_size = 5 if won else 3
	style.shadow_offset = Vector2(0, 3)
	return style

func performance_snapshot() -> Dictionary:
	return {"cached_style_count": cached_style_count, "max_visual_symbol_draws": max_visual_symbol_draws, "column_stop_count": column_stop_count, "transform_cell_count": transform_cell_count, "spin_serial": spin_serial, "presentation_rng_only": true}
