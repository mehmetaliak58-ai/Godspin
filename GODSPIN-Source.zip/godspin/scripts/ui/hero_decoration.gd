class_name HeroDecoration
extends Control

var cosmetic := ""
var color := Color("e7c77d")
var reduced := false
var clock := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta: float) -> void:
	if not reduced:
		clock += delta
	if not cosmetic.is_empty():
		queue_redraw()

func _draw() -> void:
	var center := size * Vector2(0.5, 0.46)
	match cosmetic:
		"royal_frame":
			for inset in [7.0, 14.0]:
				draw_rect(Rect2(Vector2.ONE * inset, size - Vector2.ONE * inset * 2), Color(color, 0.8), false, 2)
			for x in [22.0, size.x - 22]:
				for y in [22.0, size.y - 22]:
					var pos := Vector2(x, y)
					draw_colored_polygon(PackedVector2Array([pos + Vector2(0, -7), pos + Vector2(5, 0), pos + Vector2(0, 7), pos + Vector2(-5, 0)]), color)
		"starlight_aura":
			for i in range(22):
				var angle := i * TAU / 22 + clock * 0.08
				var at := center + Vector2(cos(angle) * size.x * 0.44, sin(angle) * size.y * 0.43)
				var alpha := 0.6 if reduced else 0.5 + sin(clock * 1.3 + i) * 0.18
				draw_circle(at, 2.4, Color(color, alpha))
				draw_line(at - Vector2(0, 6), at + Vector2(0, 6), Color(color, alpha), 1)
				draw_line(at - Vector2(6, 0), at + Vector2(6, 0), Color(color, alpha), 1)
		"divine_glow":
			for i in range(5):
				draw_arc(center, size.x * 0.36 + i * 5, -PI * 0.9 + clock * 0.06, PI * 0.9 + clock * 0.06, 80, Color(color, 0.07 + (4 - i) * 0.045), 2 + i, true)
