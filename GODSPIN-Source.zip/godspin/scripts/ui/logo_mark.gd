class_name GodspinLogo
extends Control

## Vector imperial seal with a foil-lit title. The seal remains a transparent
## SVG; the title uses a real font so Turkish accents remain crisp.
@export var title_text := "GODSPIN"
@export var subtitle_text := "EMPIRE OF FORTUNE"
@export var show_crest := true
@export var animate_light := true
var _crest: Texture2D
var _font: Font
var _body: Font
var _clock := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_crest = load("res://assets/ui/logo_crest.svg")
	_font = load("res://assets/fonts/DejaVuSerif-Bold.ttf")
	_body = load("res://assets/fonts/NotoSans-Regular.ttf")
	if size == Vector2.ZERO:
		size = Vector2(656, 150)
	queue_redraw()

func _process(delta: float) -> void:
	if animate_light and is_visible_in_tree():
		_clock += delta
		queue_redraw()

func _draw() -> void:
	if _font == null or _body == null:
		return
	var available := maxf(size.x, 1)
	var fs := mini(54, int(available / 9.9))
	var text_width := _font.get_string_size(title_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var baseline := size.y * 0.61
	if show_crest and _crest:
		var crest_size := minf(size.y * 1.2, 188.0)
		draw_texture_rect(_crest, Rect2((size.x - crest_size) * 0.5, -crest_size * 0.12, crest_size, crest_size), false, Color(1, 1, 1, 0.34))
	var origin := Vector2((size.x - text_width) * 0.5, baseline)
	draw_string_outline(_font, origin + Vector2(0, 3), title_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 4, Color("100a19"))
	draw_string(_font, origin + Vector2(0, 2), title_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color("775227"))
	draw_string(_font, origin, title_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color("e8c779"))
	draw_string(_font, origin + Vector2(0, -0.65), title_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color("ffedb7"), TextServer.JUSTIFICATION_NONE)
	var subfs := mini(17, int(available / 32))
	var sub_width := _body.get_string_size(subtitle_text, HORIZONTAL_ALIGNMENT_LEFT, -1, subfs).x
	draw_string(_body, Vector2((size.x - sub_width) * 0.5, baseline + 35), subtitle_text, HORIZONTAL_ALIGNMENT_LEFT, -1, subfs, Color("bca78a"))
	var line_y := baseline + 49
	var pulse := 0.45 + 0.08 * sin(_clock * 0.75) if animate_light else 0.5
	draw_line(Vector2(size.x * 0.16, line_y), Vector2(size.x * 0.84, line_y), Color(0.79, 0.61, 0.32, pulse), 1, true)
	var mid := Vector2(size.x * 0.5, line_y)
	draw_colored_polygon(PackedVector2Array([mid + Vector2(-5, 0), mid + Vector2(0, -4), mid + Vector2(5, 0), mid + Vector2(0, 4)]), Color("e7c77d"))
