extends Control

const GOLD := Color("e7c77d")
const INK := Color("100d20")
const WHITE := Color("f5efdf")
const MUTED := Color("a49bb6")
var game: GodspinGame
var navigation := GodspinSceneManager.new()
var backdrop: GodspinBackdrop
var frame: Control
var modal_layer: Control
var modal_box: Panel
var fx: GodspinVFX
var audio: GodspinAudio
var reels: ReelController
var balance_label: Label
var energy_bar: ProgressBar
var power_button: Button
var spin_button: Button
var status_label: Label
var payout_label: Label
var bet_label: Label
var free_label: Label
var auto_button: Button
var skip_button: Button
var busy := false
var auto_left := 0
var turbo := false
var body_font: Font
var title_font: Font
var last_balance := 100000
var toast_label: Label
var toast_tween: Tween
var idle_clock := 0.0
var hero_art: TextureRect
var hero_decoration: HeroDecoration
var hero_origin := Vector2.ZERO
var meter_tween: Tween
var entrance_tween: Tween
var skin_cache: Dictionary = {}

func _ready() -> void:
	body_font = load("res://assets/fonts/NotoSans-Regular.ttf") if ResourceLoader.exists("res://assets/fonts/NotoSans-Regular.ttf") else ThemeDB.fallback_font
	title_font = load("res://assets/fonts/DejaVuSerif-Bold.ttf") if ResourceLoader.exists("res://assets/fonts/DejaVuSerif-Bold.ttf") else body_font
	game = GodspinGame.new()
	game.initialize()
	backdrop = GodspinBackdrop.new()
	add_child(backdrop)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	frame = Control.new()
	add_child(frame)
	frame.size = Vector2(720, 1280)
	frame.resized.connect(_position_frame)
	get_viewport().size_changed.connect(_position_frame)
	modal_layer = Control.new()
	add_child(modal_layer)
	modal_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	modal_layer.hide()
	fx = GodspinVFX.new()
	add_child(fx)
	fx.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fx.mouse_filter = Control.MOUSE_FILTER_STOP
	audio = GodspinAudio.new()
	add_child(audio)
	skip_button = _button(self, "ANİMASYONU GEÇ  ›", Rect2(0, 0, 300, 64), _skip_effect, "ghost")
	skip_button.z_index = 200
	skip_button.hide()
	toast_label = _label(self, "", Rect2(0, 0, 660, 74), 23, WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_label.z_index = 210
	toast_label.add_theme_stylebox_override("normal", _style(Color("241c38"), GOLD, 20, 1))
	toast_label.hide()
	_apply_settings()
	_position_frame()
	_show_lobby()
	if "--qa-smoke" in OS.get_cmdline_user_args():
		call_deferred("_qa_smoke")
	if "--qa-screenshot" in OS.get_cmdline_user_args():
		call_deferred("_qa_screenshot")

func _position_frame() -> void:
	if not is_instance_valid(frame):
		return
	frame.position = Vector2((size.x - 720) * 0.5, maxf(0, (size.y - 1280) * 0.5))
	if is_instance_valid(skip_button):
		skip_button.position = Vector2((size.x - 300) * 0.5, size.y - 100)
	if is_instance_valid(toast_label):
		toast_label.position = Vector2((size.x - 660) * 0.5, size.y - 170)
	if is_instance_valid(modal_box):
		modal_box.position = Vector2((size.x - modal_box.size.x) * 0.5, (size.y - modal_box.size.y) * 0.5)

func _process(delta: float) -> void:
	idle_clock += delta
	if is_instance_valid(hero_art) and not game.state.settings.get("reduced_motion", false):
		var light := 0.98 + 0.02 * sin(idle_clock * 1.5)
		hero_art.self_modulate = Color(light, light, light, 1)
		hero_art.position = hero_origin + Vector2(sin(idle_clock * 0.48) * 2.0, sin(idle_clock * 0.72) * 4.0)
	if is_instance_valid(power_button) and not busy:
		var pulse := 0.0 if bool(game.state.settings.get("reduced_motion", false)) else (sin(idle_clock * 2.3) + 1.0) * 0.06
		power_button.modulate = Color(1 + pulse, 1 + pulse * 0.45, 1 + pulse) if game.energy() >= 100 else Color.WHITE

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if game:
			game.save()
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if modal_layer.visible:
			_close_modal()
		elif not busy:
			_show_lobby()

func _clear_screen(screen: String) -> void:
	if meter_tween:
		meter_tween.kill()
	if entrance_tween:
		entrance_tween.kill()
	auto_left = 0
	navigation.open(screen)
	for node in frame.get_children():
		frame.remove_child(node)
		node.queue_free()
	hero_art = null
	hero_decoration = null
	backdrop.tint = Color(game.character().get("color", "e7c77d"))
	var path := "res://assets/art/casino_palace.webp" if screen == "lobby" else "res://assets/art/slot_%s.webp" % str(game.state.slot)
	if ResourceLoader.exists(path):
		backdrop.temple = load(path)

func _style(bg: Color, border: Color = Color.TRANSPARENT, radius: int = 18, width: int = 1) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_corner_radius_all(radius)
	s.set_border_width_all(width)
	s.shadow_color = Color(0, 0, 0, 0.35)
	s.shadow_size = 7
	s.shadow_offset = Vector2(0, 4)
	return s

func _panel(parent: Node, rect: Rect2, border: Color = Color(GOLD, 0.3), bg: Color = Color("141021"), radius: int = 20) -> Panel:
	var panel := Panel.new()
	parent.add_child(panel)
	panel.position = rect.position
	panel.size = rect.size
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_theme_stylebox_override("panel", _style(bg, border, radius))
	var metal_path := "res://assets/ui/metal_frame.svg"
	if rect.size.y >= 150 and rect.size.x >= 280 and ResourceLoader.exists(metal_path):
		if not skin_cache.has(metal_path):
			skin_cache[metal_path] = load(metal_path)
		var metal := NinePatchRect.new()
		panel.add_child(metal)
		metal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		metal.texture = skin_cache[metal_path]
		metal.patch_margin_left = 24
		metal.patch_margin_right = 24
		metal.patch_margin_top = 24
		metal.patch_margin_bottom = 24
		metal.draw_center = false
		metal.mouse_filter = Control.MOUSE_FILTER_IGNORE
		metal.z_index = 1
	return panel

func _label(parent: Node, text: String, rect: Rect2, font_size: int = 24, color: Color = WHITE, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, title: bool = false) -> Label:
	var label := Label.new()
	parent.add_child(label)
	label.position = rect.position
	label.size = rect.size
	label.text = text
	label.add_theme_font_override("font", title_font if title else body_font)
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.horizontal_alignment = align
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.clip_text = true
	return label

func _paragraph(parent: Node, text: String, rect: Rect2, font_size: int = 22, color: Color = MUTED) -> Label:
	var label := _label(parent, text, rect, font_size, color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	return label

func _button(parent: Node, text: String, rect: Rect2, action: Callable, kind: String = "dark") -> Button:
	var b := Button.new()
	parent.add_child(b)
	b.position = rect.position
	b.size = rect.size
	b.size.y = maxf(48.0, b.size.y)
	b.text = text
	b.add_theme_font_override("font", body_font)
	b.add_theme_font_size_override("font_size", 24)
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	var bg := Color("211a31")
	var fg := WHITE
	var edge := Color(GOLD, 0.32)
	if kind == "gold":
		bg = GOLD
		fg = Color("25192a")
		edge = Color("ffebb2")
	elif kind == "purple":
		bg = Color("583589")
		edge = Color("b58afa")
	elif kind == "ghost":
		bg = Color("171321")
		edge = Color(GOLD, 0.14)
	b.add_theme_color_override("font_color", fg)
	b.add_theme_color_override("font_hover_color", fg.lightened(0.15))
	b.add_theme_color_override("font_pressed_color", fg)
	b.add_theme_color_override("font_disabled_color", Color("706878"))
	b.add_theme_stylebox_override("normal", _style(bg, edge, 18, 1))
	b.add_theme_stylebox_override("hover", _style(bg.lightened(0.09), edge.lightened(0.15), 18, 2))
	b.add_theme_stylebox_override("pressed", _style(bg.darkened(0.15), edge, 18, 2))
	b.add_theme_stylebox_override("disabled", _style(Color("1a1722"), Color("393044"), 18, 1))
	b.add_theme_stylebox_override("focus", _style(Color.TRANSPARENT, Color(GOLD, 0.6), 18, 2))
	var skin_path := "res://assets/ui/gold_button.svg" if kind == "gold" else "res://assets/ui/dark_button.svg"
	if kind != "ghost" and ResourceLoader.exists(skin_path):
		if not skin_cache.has(skin_path):
			skin_cache[skin_path] = load(skin_path)
		for style_name in ["normal", "hover", "pressed"]:
			var skin := StyleBoxTexture.new()
			skin.texture = skin_cache[skin_path]
			skin.texture_margin_left = 24
			skin.texture_margin_right = 24
			skin.texture_margin_top = 20
			skin.texture_margin_bottom = 20
			skin.modulate_color = Color(1.12, 1.1, 1.07) if style_name == "hover" else (Color(0.83, 0.81, 0.85) if style_name == "pressed" else Color.WHITE)
			b.add_theme_stylebox_override(style_name, skin)
	b.pivot_offset = rect.size * 0.5
	b.button_down.connect(func():
		if not bool(game.state.settings.get("reduced_motion", false)):
			var press := b.create_tween()
			press.tween_property(b, "scale", Vector2.ONE * 0.965, 0.07).set_trans(Tween.TRANS_QUAD)
	)
	b.button_up.connect(func():
		if not bool(game.state.settings.get("reduced_motion", false)):
			var release := b.create_tween()
			release.tween_property(b, "scale", Vector2.ONE, 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	)
	b.pressed.connect(func():
		audio.play("click", str(game.state.character))
		action.call()
	)
	return b

func _art(parent: Node, path: String, rect: Rect2, fade: float = 1.0) -> TextureRect:
	var art := TextureRect.new()
	parent.add_child(art)
	art.position = rect.position
	art.size = rect.size
	art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	art.modulate.a = fade
	if not path.begins_with("res://"):
		path = "res://" + path
	if ResourceLoader.exists(path):
		art.texture = load(path)
	return art

func _portrait_path(character: Dictionary) -> String:
	return str(character.get("portrait", "res://assets/art/%s.webp" % character.get("id", "ares")))

func _money(value: int) -> String:
	var source := str(value)
	var output := ""
	for i in range(source.length()):
		if i > 0 and (source.length() - i) % 3 == 0:
			output += "."
		output += source[i]
	return output

func _short(value: int) -> String:
	if value >= 1000000000:
		return "%.2f Mr" % (value / 1000000000.0)
	if value >= 1000000:
		return "%.2f Mn" % (value / 1000000.0)
	return _money(value)

func _header(back: bool = false) -> void:
	if back:
		_button(frame, "‹", Rect2(30, 32, 64, 68), func():
			if not busy:
				_show_lobby(), "ghost")
	else:
		_label(frame, "G", Rect2(32, 34, 54, 60), 44, GOLD, HORIZONTAL_ALIGNMENT_CENTER, true)
	_panel(frame, Rect2(108, 32, 428, 68), Color(GOLD, 0.32), Color("171220"), 34)
	_label(frame, "◈", Rect2(126, 35, 48, 61), 32, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	balance_label = _label(frame, _short(game.state.balance), Rect2(180, 33, 260, 64), 29, WHITE)
	_label(frame, "SANAL ÇİP", Rect2(420, 40, 108, 50), 13, MUTED)
	_button(frame, "☰", Rect2(622, 32, 66, 68), _settings, "ghost")
	_button(frame, "?", Rect2(548, 32, 62, 68), _rules, "ghost")

func _show_lobby() -> void:
	_close_modal()
	_clear_screen("lobby")
	_header()
	var logo_script = load("res://scripts/ui/logo_mark.gd")
	var logo: Control = logo_script.new()
	frame.add_child(logo)
	logo.position = Vector2(32, 109)
	logo.size = Vector2(656, 126)
	logo.animate_light = not bool(game.state.settings.get("reduced_motion", false))
	logo.show_crest = false
	var card := _panel(frame, Rect2(32, 243, 656, 534), Color(GOLD, 0.55), Color("151022"), 24)
	card.clip_contents = true
	hero_art = _art(card, _portrait_path(game.character()), Rect2(0, 0, 656, 534))
	hero_origin = hero_art.position
	_apply_hero_material(hero_art)
	_decorate_hero(card)
	_hero_entrance(hero_art)
	var veil := _panel(card, Rect2(0, 376, 656, 158), Color.TRANSPARENT, Color(0.025, 0.015, 0.055, 0.88), 0)
	_label(veil, "SEÇİLİ TANRISAL KAHRAMAN", Rect2(24, 8, 600, 28), 15, GOLD)
	_label(veil, str(game.character().get("name", "ARES")), Rect2(24, 40, 590, 54), 33, WHITE, HORIZONTAL_ALIGNMENT_LEFT, true)
	_label(veil, str(game.character().get("title", "Altınların İmparatoru")), Rect2(24, 96, 440, 36), 21, MUTED)
	_button(card, "DEĞİŞTİR  ›", Rect2(451, 477, 176, 42), _characters, "ghost").add_theme_font_size_override("font_size", 17)
	_label(frame, "SEVİYE %d  ·  %s" % [game.level(), _hall_name()], Rect2(36, 790, 650, 34), 18, GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	_button(frame, "SALONA GİR  ›", Rect2(32, 847, 656, 90), _slots, "gold").add_theme_font_size_override("font_size", 30)
	_button(frame, "Kahramanlar", Rect2(32, 958, 316, 76), _characters)
	_button(frame, "Görevler ve ödüller", Rect2(372, 958, 316, 76), _quests)
	_button(frame, "Kozmetik koleksiyonu", Rect2(32, 1052, 316, 76), _cosmetics)
	_button(frame, "Profil ve başarımlar", Rect2(372, 1052, 316, 76), _profile)
	_label(frame, "Yalnızca sanal çip • Çevrimdışı • Gerçek para yok", Rect2(20, 1178, 680, 36), 18, MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	audio.ambience(str(game.state.slot))
	_transition_in()

func _hall_name() -> String:
	if game.level() >= 10:
		return "KOZMİK SARAY"
	if game.level() >= 5:
		return "KRALİYET SALONU"
	return "ALTIN SALON"

func _show_slot() -> void:
	_close_modal()
	_clear_screen("slot")
	_header(true)
	var ch: Dictionary = game.character()
	var color := Color(ch.get("color", "e7c77d"))
	var hero := _panel(frame, Rect2(32, 125, 656, 159), Color(color, 0.55), Color("191225"), 20)
	hero.clip_contents = true
	hero_art = _art(hero, _portrait_path(ch), Rect2(472, -25, 184, 220), 0.9)
	hero_origin = hero_art.position
	_apply_hero_material(hero_art)
	_decorate_hero(hero)
	_label(hero, str(ch.get("name", "ARES")), Rect2(22, 13, 444, 40), 27, WHITE, HORIZONTAL_ALIGNMENT_LEFT, true)
	_label(hero, "KAHRAMAN SV. %d  ·  %s" % [game.character_level(str(ch.id)), str(ch.get("ultimate", "Tanrısal güç"))], Rect2(22, 57, 439, 29), 14, color)
	energy_bar = ProgressBar.new()
	hero.add_child(energy_bar)
	energy_bar.position = Vector2(22, 102)
	energy_bar.size = Vector2(355, 16)
	energy_bar.show_percentage = false
	energy_bar.add_theme_stylebox_override("background", _style(Color("080710"), Color.TRANSPARENT, 8, 0))
	energy_bar.add_theme_stylebox_override("fill", _style(color, color.lightened(0.2), 8, 0))
	_label(hero, "TANRISAL GÜÇ", Rect2(22, 126, 335, 20), 12, MUTED)
	_button(hero, "›", Rect2(393, 100, 53, 44), _characters, "ghost")
	var config: Dictionary = game.selected_config()
	_label(frame, str(config.get("title", "ALTIN İMPARATORLUĞU")), Rect2(34, 298, 505, 46), 26, GOLD, HORIZONTAL_ALIGNMENT_LEFT, true)
	_button(frame, "KURALLAR", Rect2(547, 302, 141, 40), _paytable, "ghost").add_theme_font_size_override("font_size", 15)
	_label(frame, "%d×%d MAKARA  /  %s" % [5, int(config.get("rows", 3)), str(config.get("subtitle", "Tanrısal servetin kapısı"))], Rect2(36, 345, 650, 26), 14, MUTED)
	var slot_panel := _panel(frame, Rect2(24, 389, 672, 441), GOLD, Color("231832"), 22)
	slot_panel.add_theme_stylebox_override("panel", _style(Color("21152a"), Color("b48a45"), 22, 3))
	reels = ReelController.new()
	slot_panel.add_child(reels)
	reels.position = Vector2(12, 12)
	reels.size = Vector2(648, 417)
	reels.rows = int(config.get("rows", 3))
	reels.accent = color
	reels.reduced = bool(game.state.settings.get("reduced_motion", false))
	reels.set_grid([])
	reels.column_stopped.connect(func(_column: int): audio.play("stop", str(game.state.character)))
	fx.set_reel_rect(Rect2(24, 389, 672, 441))
	status_label = _label(frame, "Servetin bir dokunuş uzağında.", Rect2(30, 850, 660, 34), 20, MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_label.size.y = 48
	status_label.add_theme_font_size_override("font_size", 18)
	payout_label = _label(frame, "ÇEVİR VE YÜKSEL", Rect2(30, 890, 660, 64), 35, GOLD, HORIZONTAL_ALIGNMENT_CENTER, true)
	free_label = _label(frame, "", Rect2(30, 955, 660, 24), 16, Color("c5a3f0"), HORIZONTAL_ALIGNMENT_CENTER)
	_panel(frame, Rect2(32, 997, 656, 71), Color(GOLD, 0.17), Color("14101e"), 20)
	_button(frame, "−", Rect2(42, 1005, 62, 55), func(): _change_bet(-1), "ghost")
	_label(frame, "BAHİS", Rect2(119, 1000, 104, 58), 17, MUTED)
	bet_label = _label(frame, _money(game.bet()), Rect2(216, 1001, 275, 60), 29, WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	_button(frame, "+", Rect2(532, 1005, 62, 55), func(): _change_bet(1), "ghost")
	_button(frame, "≡", Rect2(612, 1005, 62, 55), _history, "ghost")
	spin_button = _button(frame, "ÇEVİR", Rect2(32, 1091, 420, 99), _spin, "gold")
	spin_button.add_theme_font_size_override("font_size", 33)
	power_button = _button(frame, "GÜÇ  ·  %d%%" % int(game.energy()), Rect2(474, 1091, 214, 99), _ultimate, "purple")
	power_button.add_theme_font_size_override("font_size", 21)
	auto_button = _button(frame, "OTOMATİK  ○", Rect2(32, 1210, 239, 47), _toggle_auto, "ghost")
	auto_button.add_theme_font_size_override("font_size", 17)
	_button(frame, "TURBO  %s" % ("●" if turbo else "○"), Rect2(294, 1210, 204, 47), _toggle_turbo, "ghost").add_theme_font_size_override("font_size", 17)
	_button(frame, "SALONLAR", Rect2(521, 1210, 167, 47), func():
		if not busy:
			_slots(), "ghost").add_theme_font_size_override("font_size", 17)
	_refresh_slot()
	audio.ambience(str(game.state.slot))
	_transition_in()

func _refresh_slot() -> void:
	if navigation.current != "slot":
		return
	balance_label.text = _short(int(game.state.balance))
	bet_label.text = _money(game.bet())
	if meter_tween:
		meter_tween.kill()
	if bool(game.state.settings.get("reduced_motion", false)):
		energy_bar.value = game.energy()
	else:
		meter_tween = create_tween()
		meter_tween.tween_property(energy_bar, "value", float(game.energy()), 0.38).set_trans(Tween.TRANS_SINE)
	power_button.text = "GÜÇ HAZIR" if game.energy() >= 100 else "GÜÇ  ·  %d%%" % int(game.energy())
	power_button.disabled = busy or game.energy() < 100 or int(game.state.get("bonus_remaining", 0)) > 0
	spin_button.disabled = busy
	spin_button.text = "DÖNÜYOR…" if busy else ("ÜCRETSİZ ÇEVİR" if int(game.state.free_spins) > 0 or int(game.state.get("bonus_remaining", 0)) > 0 else "ÇEVİR")
	if int(game.state.get("bonus_remaining", 0)) > 0:
		free_label.text = "TANRISAL BONUS  ·  %d ÖZEL DÖNÜŞ" % int(game.state.bonus_remaining)
	elif int(game.state.free_spins) > 0:
		free_label.text = "%d ÜCRETSİZ DÖNÜŞ HAZIR" % int(game.state.free_spins)
	else:
		free_label.text = "Tüm sonuçlar rastgele hesaplanır. Tüm çipler sanaldır."
	auto_button.text = "DURDUR  ■  %d" % auto_left if auto_left > 0 else "OTOMATİK  ○"

func _change_bet(delta: int) -> void:
	if busy:
		return
	if int(game.state.get("bonus_remaining", 0)) > 0 or int(game.state.free_spins) > 0:
		_toast("Bonus dönüşlerinde bahis sabittir.")
		return
	game.change_bet(delta)
	_refresh_slot()

func _spin() -> void:
	if busy or navigation.current != "slot" or modal_layer.visible:
		return
	if not game.can_spin():
		auto_left = 0
		_rescue()
		return
	var before: int = game.state.balance
	var old_energy: float = game.energy()
	var result: Dictionary = game.spin()
	if result.is_empty() or not bool(result.get("ok", false)):
		_toast(str(result.get("error", "Dönüş başlatılamadı.")))
		return
	busy = true
	_refresh_slot()
	balance_label.text = _short(before - int(result.get("charge", 0)))
	payout_label.text = "KADER DÖNÜYOR"
	status_label.text = ""
	audio.play("spin", str(game.state.character))
	await reels.animate_result(result, turbo)
	for stage in result.get("cascades", []):
		status_label.text = "ZİNCİR KAZANÇ  ·  ×%s  ·  +%s" % [str(stage.get("multiplier", 1)), _money(int(stage.get("payout", 0)))]
		payout_label.text = "MÜCEVHERLER YENİLENİYOR"
		await get_tree().create_timer(0.22 if turbo else 0.45).timeout
		reels.set_grid(stage.grid)
		reels.active_wins = stage.get("wins", [])
		audio.play("win", str(game.state.character))
	if result.has("final_grid") and not result.get("cascades", []).is_empty():
		await get_tree().create_timer(0.2 if turbo else 0.45).timeout
		reels.set_grid(result.final_grid)
		reels.active_wins = []
	var payout: int = int(result.payout)
	status_label.text = str(result.get("bonus_text", ""))
	if not str(result.get("passive_text", "")).is_empty():
		status_label.text += ("\n" if not status_label.text.is_empty() else "") + str(result.passive_text)
	if status_label.text.is_empty():
		status_label.text = "%d kazanan çizgi" % result.get("wins", []).size() if payout > 0 else "Güç birikiyor. Bir sonraki dönüş hazır."
	payout_label.text = "+ " + _money(payout) if payout > 0 else "YENİ BİR ŞANS"
	if payout > 0:
		fx.set_character(game.character())
		audio.play("jackpot" if float(payout) / game.bet() >= 250 else "win", str(game.state.character))
		var count_from: int = int(game.state.balance) - payout
		var tween := create_tween()
		tween.tween_method(func(value: float): balance_label.text = _short(int(value)), float(count_from), float(game.state.balance), 0.42)
		var tier: String = str(result.get("tier", "GÜZEL KAZANÇ"))
		if float(payout) / maxf(game.bet(), 1) >= 5:
			skip_button.show()
			await fx.celebrate(tier, payout, Color(game.character().get("color", "e7c77d")), bool(game.state.settings.get("reduced_motion", false)))
			skip_button.hide()
		else:
			await get_tree().create_timer(0.45 if turbo else 0.6).timeout
	if old_energy < 100 and game.energy() >= 100:
		audio.play("ready", str(game.state.character))
	busy = false
	_refresh_slot()
	if int(result.get("progress_reward", 0)) > 0:
		_toast("Seviye %d! +%s ilerleme ödülü" % [int(result.get("level_after", game.level())), _money(int(result.progress_reward))])
	if auto_left > 0:
		auto_left -= 1
		_refresh_slot()
		await get_tree().create_timer(0.22 if turbo else 0.65).timeout
		if auto_left > 0 and not modal_layer.visible:
			_auto_spin.call_deferred()

func _ultimate() -> void:
	if busy or game.energy() < 100:
		return
	auto_left = 0
	var power: Dictionary = game.activate_ultimate()
	if power.has("error"):
		_toast(str(power.error))
		return
	busy = true
	_refresh_slot()
	audio.play("ultimate", str(game.state.character))
	skip_button.show()
	await fx.play_ultimate(game.character(), bool(game.state.settings.get("reduced_motion", false)))
	skip_button.hide()
	busy = false
	_refresh_slot()
	status_label.text = "Güç etkin. Özel bonus dönüşlerini başlat!"
	payout_label.text = "TANRISAL BONUS"
	audio.play("bonus", str(game.state.character))

func _skip_effect() -> void:
	fx.skip()
	skip_button.hide()

func _toggle_auto() -> void:
	if auto_left > 0:
		auto_left = 0
	else:
		auto_left = 25
		if not busy:
			_auto_spin.call_deferred()
	_refresh_slot()

func _auto_spin() -> void:
	if auto_left > 0:
		_spin()

func _toggle_turbo() -> void:
	turbo = not turbo
	for b in frame.get_children():
		if b is Button and b.text.begins_with("TURBO"):
			b.text = "TURBO  %s" % ("●" if turbo else "○")

func _open_modal(title: String, subtitle: String = "", height: int = 1060) -> Control:
	auto_left = 0
	for n in modal_layer.get_children():
		modal_layer.remove_child(n)
		n.queue_free()
	var shade := ColorRect.new()
	modal_layer.add_child(shade)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.015, 0.008, 0.04, 0.9)
	modal_box = _panel(modal_layer, Rect2(0, 0, 656, height), Color(GOLD, 0.52), Color("100d1d"), 25)
	modal_box.mouse_filter = Control.MOUSE_FILTER_STOP
	_label(modal_box, title, Rect2(28, 28, 527, 49), 28, GOLD, HORIZONTAL_ALIGNMENT_LEFT, true)
	_button(modal_box, "×", Rect2(572, 25, 57, 57), _close_modal, "ghost")
	_paragraph(modal_box, subtitle, Rect2(28, 88, 590, 56), 17)
	var scroll := ScrollContainer.new()
	modal_box.add_child(scroll)
	scroll.position = Vector2(22, 154)
	scroll.size = Vector2(612, height - 178)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var content := Control.new()
	scroll.add_child(content)
	content.custom_minimum_size = Vector2(598, 1)
	modal_layer.show()
	_position_frame()
	_refresh_slot()
	return content

func _close_modal() -> void:
	if not is_instance_valid(modal_layer):
		return
	modal_layer.hide()
	if navigation.current == "slot":
		_refresh_slot()

func _characters() -> void:
	if busy:
		return
	var content := _open_modal("TANRISAL KAHRAMANLAR", "Her kahramanın pasifi ve gücü farklıdır. İlerleyerek hepsini aç.")
	var i := 0
	for ch in game.characters:
		var id: String = str(ch.id)
		var unlocked: bool = game.character_unlocked(id)
		var x := (i % 2) * 303.0
		var y := (i / 2) * 359.0
		var color := Color(ch.get("color", "e7c77d"))
		var panel := _panel(content, Rect2(x, y, 290, 344), color if id == str(game.state.character) else Color(color, 0.35), Color("1b152a"))
		panel.clip_contents = true
		_art(panel, _portrait_path(ch), Rect2(0, 0, 290, 213), 1.0 if unlocked else 0.4)
		_label(panel, str(ch.get("name", id)), Rect2(15, 214, 260, 36), 24, WHITE, HORIZONTAL_ALIGNMENT_LEFT, true)
		_label(panel, "SV. %d  ·  %s" % [game.character_level(id), str(ch.get("rarity", "Efsanevi")).to_upper()], Rect2(16, 252, 260, 23), 13, color)
		_button(panel, "SEÇİLİ" if id == str(game.state.character) else ("İNCELE VE SEÇ" if unlocked else "SV. %d'DE AÇILIR" % int(ch.get("unlock_level", 1))), Rect2(12, 287, 266, 44), func(): _character_detail(id), "purple" if id == str(game.state.character) else "dark").add_theme_font_size_override("font_size", 16)
		i += 1
	content.custom_minimum_size.y = 4 * 359

func _character_detail(id: String) -> void:
	var ch: Dictionary = {}
	for item in game.characters:
		if str(item.id) == id:
			ch = item
	var content := _open_modal(str(ch.get("name", id)).to_upper(), str(ch.get("title", "")))
	var panel := _panel(content, Rect2(0, 0, 592, 320), Color(ch.get("color", "e7c77d")))
	panel.clip_contents = true
	_art(panel, _portrait_path(ch), Rect2(0, 0, 592, 320))
	_button(panel, "GÜCÜ ÖNİZLE  ✦", Rect2(312, 253, 260, 50), func(): _preview_ultimate(id), "purple").add_theme_font_size_override("font_size", 18)
	_paragraph(content, str(ch.get("lore", ch.get("story", ""))), Rect2(5, 340, 580, 82), 21, WHITE)
	_label(content, "PASİF GÜÇ", Rect2(5, 440, 580, 30), 16, GOLD)
	_paragraph(content, str(ch.get("passive_description", ch.get("passive", ""))), Rect2(5, 480, 580, 88), 20)
	_label(content, str(ch.get("ultimate", "TANRISAL GÜÇ")).to_upper(), Rect2(5, 585, 580, 38), 20, GOLD)
	_paragraph(content, str(ch.get("power", "")), Rect2(5, 633, 580, 138), 20)
	var unlocked: bool = game.character_unlocked(id)
	var select := _button(content, "KAHRAMANI SEÇ" if unlocked else "SEVİYE %d GEREKLİ" % int(ch.get("unlock_level", 1)), Rect2(0, 786, 590, 76), func(): _select_hero(id), "gold")
	select.disabled = not unlocked
	content.custom_minimum_size.y = 875

func _slots() -> void:
	if busy:
		return
	var content := _open_modal("SERVET SALONLARI", "Altı makine, altı farklı bonus kuralı. Seviye atlayarak yeni salonları aç.")
	var slot_colors := ["e7c77d", "ba81ff", "73cfff", "f17180", "f39ac3", "8787f9"]
	var art_chars := ["ares", "luna", "kael", "vex", "seraphine", "orion"]
	for i in range(game.slot_ids.size()):
		var id: String = str(game.slot_ids[i])
		var config: Dictionary = game.engine.load_config(id)
		var unlocked: bool = game.slot_unlocked(id)
		var p := _panel(content, Rect2(0, i * 186, 592, 170), Color(Color(slot_colors[i]), 0.6), Color("191327"))
		p.clip_contents = true
		_art(p, "res://assets/art/slot_%s.webp" % id, Rect2(0, 0, 144, 170), 0.8 if unlocked else 0.3)
		_label(p, str(config.get("title", id)).to_upper(), Rect2(165, 12, 400, 42), 22, Color(slot_colors[i]), HORIZONTAL_ALIGNMENT_LEFT, true)
		_label(p, "5×%d  ·  %s" % [int(config.get("rows", 3)), str(config.get("mechanic_name", _mechanic_name(id)))], Rect2(166, 61, 402, 32), 16, MUTED)
		var button := _button(p, "OYNA  ›" if unlocked else "SV. %d'DE AÇILIR" % int(config.get("unlock_level", 1)), Rect2(165, 108, 405, 48), func(): _select_machine(id), "gold" if unlocked else "ghost")
		button.add_theme_font_size_override("font_size", 19)
		button.disabled = not unlocked
	content.custom_minimum_size.y = game.slot_ids.size() * 186

func _mechanic_name(id: String) -> String:
	return {"golden_empire": "Ücretsiz dönüşler", "neon_chaos": "Zincir jokerler", "gods_of_thunder": "Yıldırım jokerleri", "joker_madness": "Kader çarkı", "empress_treasure": "Zincir kazançlar", "cosmic_infinity": "Genişleyen joker"}.get(id, "Bonus dönüşleri")

func _quests() -> void:
	if busy:
		return
	var content := _open_modal("GÖREVLER VE ÖDÜLLER", "Görevler her gün UTC tarihinde yenilenir. Ödüller yalnızca sanal çiptir.")
	_build_claims(content, game.quests(), false)

func _build_claims(content: Control, items: Array, achievement: bool) -> void:
	for i in range(items.size()):
		var item: Dictionary = items[i]
		var p := _panel(content, Rect2(0, i * 192, 592, 176))
		_label(p, str(item.title), Rect2(18, 12, 550, 37), 23, WHITE)
		_paragraph(p, str(item.description), Rect2(18, 54, 540, 45), 17)
		_label(p, "%d / %d  ·  +%s ÇİP" % [mini(int(item.progress), int(item.target)), int(item.target), _money(int(item.reward))], Rect2(18, 107, 359, 44), 17, GOLD)
		var id: String = str(item.id)
		var b := _button(p, "ALINDI" if item.claimed else ("TOPLA" if item.ready else "DEVAM ET"), Rect2(410, 108, 161, 45), func():
			var reward: int = game.claim_achievement(id) if achievement else game.claim_quest(id)
			if reward > 0:
				audio.play("bonus", str(game.state.character))
				_toast("+%s sanal çip toplandı." % _money(reward))
				_update_balance()
				if achievement:
					_profile()
				else:
					_quests(), "gold" if item.ready else "ghost")
		b.add_theme_font_size_override("font_size", 17)
		b.disabled = bool(item.claimed) or not bool(item.ready)
	content.custom_minimum_size.y = items.size() * 192

func _profile() -> void:
	if busy:
		return
	var content := _open_modal("İMPARATORLUK PROFİLİ", "Seviye %d  ·  %s  ·  %s XP\n%d dönüş  ·  %d tanrısal güç" % [game.level(), _hall_name(), _money(int(game.state.xp)), int(game.state.spins), int(game.state.ultimate_count)])
	_build_claims(content, game.achievements(), true)

func _cosmetics() -> void:
	if busy:
		return
	var content := _open_modal("KOZMETİK KOLEKSİYONU", "Yalnızca oyun içinde kazanılan sanal çipler kullanılır. Güç ve olasılık değişmez.")
	var items: Array = game.cosmetics()
	for i in range(items.size()):
		var item: Dictionary = items[i]
		var id: String = str(item.id)
		var p := _panel(content, Rect2(0, i * 177, 592, 161), Color(item.get("color", "e7c77d")))
		_label(p, str(item.get("name", item.get("title", id))), Rect2(22, 16, 540, 42), 25, WHITE)
		_paragraph(p, str(item.get("description", "Özel aura ve çerçeve.")), Rect2(22, 65, 535, 33), 17)
		var owned := bool(item.get("owned", false))
		var equipped := bool(item.get("equipped", false))
		var price: int = int(item.get("price", item.get("cost", 0)))
		_button(p, "KUŞANILDI" if equipped else ("KUŞAN" if owned else "%s ÇİP" % _money(price)), Rect2(22, 108, 548, 40), func():
			if game.equip_cosmetic(id) if owned else game.purchase_cosmetic(id):
				_toast("Kozmetik kuşanıldı.")
				_apply_settings()
				_update_balance()
				_cosmetics()
			else:
				_toast("Bu kozmetik için yeterli çip veya seviye yok."), "gold" if owned else "dark").add_theme_font_size_override("font_size", 17)
	content.custom_minimum_size.y = items.size() * 177

func _settings() -> void:
	if busy:
		return
	var content := _open_modal("AYARLAR", "Tercihler cihazda saklanır. Azaltılmış efektler parlama ve hareketi sadeleştirir.", 990)
	_label(content, "GRAFİK KALİTESİ", Rect2(0, 0, 588, 37), 17, GOLD)
	var levels := ["Düşük", "Orta", "Yüksek", "Ultra"]
	for i in range(4):
		var level_name: String = levels[i]
		_button(content, level_name, Rect2((i % 2) * 301, 53 + (i / 2) * 72, 285, 58), func():
			game.set_setting("quality", level_name)
			_apply_settings()
			_settings(), "gold" if game.state.settings.quality == level_name else "dark").add_theme_font_size_override("font_size", 20)
	var toggles := [{"key":"sound", "name":"Ses efektleri"}, {"key":"music", "name":"Ortam müziği"}, {"key":"reduced_motion", "name":"Azaltılmış efekt ve hareket"}]
	for i in range(toggles.size()):
		var key: String = toggles[i].key
		var on := bool(game.state.settings.get(key, true))
		_button(content, "%s   %s" % [str(toggles[i].name), "● AÇIK" if on else "○ KAPALI"], Rect2(0, 240 + i * 85, 586, 68), func():
			game.set_setting(key, not on)
			_apply_settings()
			_settings()).add_theme_font_size_override("font_size", 20)
	_button(content, "%d FPS  ·  DEĞİŞTİR" % int(game.state.settings.get("fps", 60)), Rect2(0, 517, 586, 62), func():
		game.set_setting("fps", 30 if int(game.state.settings.get("fps", 60)) == 60 else 60)
		_apply_settings()
		_settings())
	_button(content, "ÜCRETSİZ TOPARLANMA", Rect2(0, 609, 586, 66), _rescue, "gold")
	_paragraph(content, "Bakiyen 10.000 çipin altındaysa 25.000 ücretsiz çip alabilirsin. Ödeme, reklam ve bekleme süresi yok.\n\nKayıt otomatik yapılır. İnternet bağlantısı gerekmez.", Rect2(0, 696, 586, 130), 18)
	content.custom_minimum_size.y = 835

func _apply_settings() -> void:
	var settings: Dictionary = game.state.settings
	Engine.max_fps = int(settings.get("fps", 60))
	backdrop.reduced = bool(settings.get("reduced_motion", false))
	backdrop.quality = str(settings.get("quality", "Yüksek"))
	fx.set_quality(str(settings.get("quality", "Yüksek")))
	audio.configure(settings)
	if is_instance_valid(reels):
		reels.reduced = bool(settings.get("reduced_motion", false))
	if is_instance_valid(hero_art):
		_apply_hero_material(hero_art)
	var equipped: String = str(game.state.get("active_cosmetic", ""))
	for item in game.cosmetics():
		if bool(item.get("equipped", false)) or str(item.id) == equipped:
			backdrop.tint = Color(item.get("color", game.character().get("color", "e7c77d")))
	if is_instance_valid(hero_decoration):
		hero_decoration.cosmetic = equipped
		hero_decoration.reduced = bool(settings.get("reduced_motion", false))
		hero_decoration.color = backdrop.tint

func _select_hero(id: String) -> void:
	if game.select_character(id):
		audio.play("ready", id)
		if navigation.current == "slot":
			_show_slot()
		else:
			_show_lobby()
	else:
		_toast("Önce ücretsiz ve tanrısal bonus dönüşlerini tamamla.")

func _preview_ultimate(id: String) -> void:
	if busy:
		return
	var ch: Dictionary = game.character_manager.find(id)
	busy = true
	_refresh_slot()
	skip_button.show()
	audio.play("ultimate", id)
	await fx.preview(ch, bool(game.state.settings.get("reduced_motion", false)))
	fx.set_character(game.character())
	skip_button.hide()
	busy = false
	_refresh_slot()

func _transition_in() -> void:
	frame.modulate.a = 1
	if bool(game.state.settings.get("reduced_motion", false)):
		return
	frame.modulate.a = 0.3
	entrance_tween = create_tween()
	entrance_tween.tween_property(frame, "modulate:a", 1.0, 0.28).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

func _select_machine(id: String) -> void:
	if id == str(game.state.slot) or game.select_slot(id):
		_show_slot()
	else:
		_toast("Önce mevcut salondaki ücretsiz dönüşlerini tamamla.")

func _decorate_hero(parent: Control) -> void:
	hero_decoration = HeroDecoration.new()
	parent.add_child(hero_decoration)
	hero_decoration.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hero_decoration.cosmetic = str(game.state.get("active_cosmetic", ""))
	hero_decoration.color = Color(game.character().get("color", "e7c77d"))
	hero_decoration.reduced = bool(game.state.settings.get("reduced_motion", false))

func _hero_entrance(art: Control) -> void:
	if bool(game.state.settings.get("reduced_motion", false)):
		return
	art.modulate.a = 0
	var tween := create_tween()
	tween.tween_property(art, "modulate:a", 1.0, 0.48).set_trans(Tween.TRANS_SINE)

func _apply_hero_material(art: TextureRect) -> void:
	if game.state.settings.quality == "Düşük" or not ResourceLoader.exists("res://shaders/aura.gdshader"):
		art.material = null
		return
	var material := ShaderMaterial.new()
	material.shader = load("res://shaders/aura.gdshader")
	material.set_shader_parameter("aura_color", Color(game.character().get("color", "e7c77d")))
	material.set_shader_parameter("strength", 0.13)
	material.set_shader_parameter("motion_amount", 0.0 if bool(game.state.settings.get("reduced_motion", false)) else 0.6)
	art.material = material

func _rescue() -> void:
	var amount: int = game.rescue()
	_toast("+%s ücretsiz sanal çip. Yeniden başlayabilirsin!" % _money(amount) if amount > 0 else "Toparlanma, bakiye 10.000 çipin altındayken açılır.")
	_update_balance()

func _update_balance() -> void:
	if is_instance_valid(balance_label):
		balance_label.text = _short(int(game.state.balance))
	_refresh_slot()

func _rules() -> void:
	if busy:
		return
	var content := _open_modal("GODSPIN'E HOŞ GELDİN", "Fantastik arcade eğlencesi. Tüm kahramanlar yetişkindir.", 950)
	_paragraph(content, "1. Kahramanını ve salonunu seç.\n\n2. Bahsini ayarla ve ÇEVİR'e dokun. Kazanan çizgiler soldan sağa en az üç aynı sembolden oluşur. Jokerler (Wild) normal sembollerin yerine geçer.\n\n3. Her dönüşte tanrısal güç dolar. GÜÇ HAZIR'a dokun; sinematikten sonra üç özel dönüşü başlat.\n\n4. Görevler ve başarımlarla garantili ilerleme ödülleri topla. Yeni salonları ve kahramanları seviye atlayarak aç.\n\n5. Otomatik mod en fazla 25 dönüş oynar; DURDUR'a dokunarak sonlandır. Turbo animasyonu hızlandırır.\n\nTüm sonuçlar ağırlıklı rastgele üretimle hesaplanır. Güçler ve bonuslar kurallarda açıklanır. Her makinenin ödeme tablosuna KURALLAR'dan ulaşabilirsin.\n\nGerçek para, ödeme, nakit çekme, satın alınan çip ve gerçek ödül yoktur.", Rect2(5, 0, 582, 930), 22, WHITE)
	content.custom_minimum_size.y = 1000

func _paytable() -> void:
	if busy:
		return
	var config: Dictionary = game.selected_config()
	var content := _open_modal("ÖDEME VE BONUS KURALLARI", str(config.get("title", "")))
	var description = PaytableManager.describe(config)
	var text: String = str(description)
	if description is Array:
		text = "\n\n".join(description)
	var l := _paragraph(content, text, Rect2(5, 0, 575, 1900), 20, WHITE)
	l.size.y = maxf(1200, l.get_minimum_size().y + 20)
	content.custom_minimum_size.y = l.size.y

func _history() -> void:
	if busy:
		return
	var content := _open_modal("DÖNÜŞ GEÇMİŞİ", "Son 30 dönüş. Gösterilen kazançlar gerçek hesaplanan sonuçlardır.")
	var history: Array = game.state.get("history", [])
	if history.is_empty():
		_label(content, "Henüz dönüş yok. Servet yolculuğunu başlat.", Rect2(0, 30, 585, 60), 20, MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	for i in range(history.size()):
		var entry: Dictionary = history[history.size() - 1 - i]
		var p := _panel(content, Rect2(0, i * 105, 590, 92))
		var history_config: Dictionary = game.engine.load_config(str(entry.get("slot", "golden_empire")))
		_label(p, "%s  ·  %s" % [str(history_config.get("title", "")), "ÜCRETSİZ" if entry.get("free", false) else "NORMAL"], Rect2(16, 9, 548, 27), 15, MUTED)
		_label(p, "Bahis %s  /  Kazanç +%s" % [_money(int(entry.get("bet", 0))), _money(int(entry.get("payout", 0)))], Rect2(16, 40, 548, 39), 22, GOLD)
	content.custom_minimum_size.y = maxf(110, history.size() * 105)

func _toast(text: String) -> void:
	toast_label.text = text
	toast_label.show()
	toast_label.modulate.a = 1
	if toast_tween:
		toast_tween.kill()
	toast_tween = create_tween()
	toast_tween.tween_interval(2.5)
	toast_tween.tween_property(toast_label, "modulate:a", 0.0, 0.4)
	toast_tween.tween_callback(toast_label.hide)

func _qa_screenshot() -> void:
	if bool(game.state.settings.get("reduced_motion", false)) == false:
		game.state.settings.reduced_motion = true
	_show_lobby()
	await get_tree().process_frame
	await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png("res://dist/lobby.png")
	_show_slot()
	await get_tree().process_frame
	await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png("res://dist/slot.png")
	audio.stop_all()
	await get_tree().create_timer(0.1).timeout
	get_tree().quit()

func _qa_smoke() -> void:
	game.initialize(false)
	game.set_seed(7081)
	game.state.settings.reduced_motion = true
	_show_lobby()
	assert(frame.get_child_count() > 10)
	_characters()
	assert(modal_layer.visible)
	_character_detail("luna")
	var before_preview: Dictionary = game.state.duplicate(true)
	await _preview_ultimate("luna")
	assert(game.state == before_preview)
	game.select_character("luna")
	_slots()
	game.select_slot("golden_empire")
	_show_slot()
	turbo = true
	await _spin()
	assert(int(game.state.spins) >= 1)
	assert(not busy and not reels.spinning)
	assert(reels.grid == reels.final_grid)
	assert(payout_label.text != "ÇEVİR VE YÜKSEL")
	game.state.energy["luna"] = 100
	await _ultimate()
	assert(int(game.state.bonus_remaining) > 0)
	await _spin()
	_quests()
	_profile()
	_cosmetics()
	_settings()
	_rules()
	_close_modal()
	_show_slot()
	_paytable()
	_history()
	_close_modal()
	for profile in ["Düşük", "Orta", "Yüksek", "Ultra"]:
		game.set_setting("quality", profile)
		_apply_settings()
	game.save()
	print("UI_SMOKE_PASS: lobi, kahraman, salon, spin, güç, bonus, görev, profil, kozmetik, ayarlar, kurallar, geçmiş")
	audio.stop_all()
	await get_tree().create_timer(0.1).timeout
	await get_tree().process_frame
	await get_tree().process_frame
	get_tree().quit()
