class_name GodspinBackdrop
extends Control

var clock := 0.0
var tint := Color("c99d52")
var reduced := false
var quality := "Yüksek"
var stars: Array[Vector3] = []
var temple: Texture2D
var ambient_glow: Texture2D
const LIGHT_POSITIONS := [Vector2(0.08, 0.28), Vector2(0.9, 0.56), Vector2(0.5, 0.08)]

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var rng := RandomNumberGenerator.new()
	rng.seed = 4189
	for i in range(50):
		stars.append(Vector3(rng.randf(), rng.randf(), rng.randf_range(0.4, 1.7)))
	if ResourceLoader.exists("res://assets/art/temple_bg.svg"):
		temple = load("res://assets/art/temple_bg.svg")
	if ResourceLoader.exists("res://assets/art/casino_palace.webp"):
		temple = load("res://assets/art/casino_palace.webp")
	var gradient := Gradient.new()
	gradient.colors = PackedColorArray([Color(1, 1, 1, 0.72), Color(1, 1, 1, 0)])
	var glow := GradientTexture2D.new()
	glow.gradient = gradient
	glow.width = 128
	glow.height = 128
	glow.fill = GradientTexture2D.FILL_RADIAL
	glow.fill_from = Vector2(0.5, 0.5)
	glow.fill_to = Vector2(1.0, 0.5)
	ambient_glow = glow

func _process(delta: float) -> void:
	if not reduced:
		clock += delta
	queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color("080712"))
	if temple:
		var drift := Vector2.ZERO if reduced else Vector2(sin(clock * 0.16) * 6, cos(clock * 0.13) * 8)
		draw_texture_rect(temple, Rect2(Vector2(-12, -12) + drift, size + Vector2(24, 24)), false, Color(0.8, 0.7, 0.85, 0.45))
	var center := Vector2(size.x * 0.5, size.y * 0.37)
	if quality != "Düşük" and ambient_glow:
		for i in range(3):
			var offset := Vector2(sin(clock * 0.21 + i) * 15, cos(clock * 0.18 + i) * 23) if not reduced else Vector2.ZERO
			var scale_size := Vector2(280, 430) if i < 2 else Vector2(520, 220)
			draw_texture_rect(ambient_glow, Rect2(LIGHT_POSITIONS[i] * size + offset - scale_size * 0.5, scale_size), false, Color(tint, 0.17))
	for i in range(8, 0, -1):
		var radius := size.x * (0.32 + i * 0.065)
		draw_circle(center, radius, Color(tint.r * 0.16, tint.g * 0.12, tint.b * 0.23, 0.018 * (9 - i)))
	for side in [-1, 1]:
		var x: float = size.x * 0.5 + side * size.x * 0.46
		draw_line(Vector2(x, 0), Vector2(x, size.y), Color(tint, 0.09), 2)
		draw_line(Vector2(x + side * 15, 0), Vector2(x + side * 15, size.y), Color(tint, 0.04), 8)
	if quality != "Düşük":
		for i in range(stars.size()):
			var star := stars[i]
			var at := Vector2(star.x * size.x, fposmod(star.y * size.y - clock * 8 * star.z, size.y))
			var opacity: float = 0.14 + 0.16 * sin(clock * star.z + i)
			draw_circle(at, star.z, Color(tint, opacity))
			if i % 9 == 0:
				draw_line(at - Vector2(4, 0), at + Vector2(4, 0), Color(tint, opacity), 1)
				draw_line(at - Vector2(0, 4), at + Vector2(0, 4), Color(tint, opacity), 1)
	for y in [size.y * 0.13, size.y * 0.78]:
		draw_line(Vector2(20, y), Vector2(size.x - 20, y), Color(tint, 0.065), 1)
