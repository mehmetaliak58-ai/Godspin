extends SceneTree
const Reels = preload("res://scripts/ui/reel_controller.gd")
const MathEngine = preload("res://scripts/core/slot_engine.gd")
var checks := 0
var failures := 0
var stop_order: Array = []

func _init() -> void:
	call_deferred("run")

func check(ok: bool, description: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error(description)

func run() -> void:
	Engine.max_fps = 60
	var surface := Control.new()
	surface.size = Vector2(720, 1280)
	root.add_child(surface)
	var reel = Reels.new()
	reel.size = Vector2(648, 417)
	surface.add_child(reel)
	reel.column_stopped.connect(func(column: int): stop_order.append(column))
	var engine = MathEngine.new()
	var config: Dictionary = engine.load_config("golden_empire")
	engine.set_seed(815)
	var baseline: Dictionary = engine.spin(config, 500)
	var original := baseline.duplicate(true)
	var started := Time.get_ticks_msec()
	await reel.animate_result(baseline)
	var elapsed := Time.get_ticks_msec() - started
	check(elapsed >= 1450 and elapsed <= 1900, "Normal motion should settle around1.58sec")
	check(reel.grid == baseline.grid and reel.final_grid == baseline.grid, "Normal stop exactly matches computed result")
	check(baseline == original, "Rendering must never mutate spin result or payouts")
	check(stop_order == [0, 1, 2, 3, 4], "Each column stops once in order")
	check(not reel.spinning and reel.active_wins == baseline.wins, "Await settles after result and wins become visible")
	stop_order.clear()
	started = Time.get_ticks_msec()
	await reel.animate_result(baseline, true)
	elapsed = Time.get_ticks_msec() - started
	check(elapsed >= 480 and elapsed <= 800, "Turbo motion should settle around0.55sec")
	check(stop_order.size() == 5 and reel.column_stop_count == 5, "Turbo stopping callback count")
	engine.set_seed(7621)
	var natural: Dictionary = engine.spin(config, 500)
	engine.set_seed(7621)
	var changed: Dictionary = engine.spin(config, 500, {"character": "luna", "wild_reels": 2})
	original = changed.duplicate(true)
	started = Time.get_ticks_msec()
	await reel.animate_result(changed, true)
	elapsed = Time.get_ticks_msec() - started
	check(reel._natural_grid == natural.grid, "True natural grid reconstruction reverses engine mutations")
	check(reel.transform_cell_count > 0, "Real Wild conversion is staged, not only recolored")
	check(reel.grid == changed.grid and reel.final_grid == changed.grid, "Transformation completes before settled")
	check(changed == original, "Wild presentation cannot alter engine result")
	check(elapsed >= 650 and elapsed <= 1200, "Turbo with real transformation adds bounded reveal interval")
	reel.reduced = true
	started = Time.get_ticks_msec()
	await reel.animate_result(changed, true)
	elapsed = Time.get_ticks_msec() - started
	check(reel.grid == changed.grid and elapsed <= 900, "Reduced motion preserves math and keeps interaction quick")
	var tall: Dictionary = engine.spin(engine.load_config("gods_of_thunder"), 500, {"character": "kael", "wild_cells": 5})
	await reel.animate_result(tall, true)
	check(reel.rows == 4 and reel.grid[0].size() == 4, "Four-row machines reuse same lifecycle")
	check(reel.performance_snapshot().cached_style_count == 2, "Draw styles are cached, never recreated per frame")
	check(reel.performance_snapshot().max_visual_symbol_draws <= 90, "Draw work is bounded to visible strips")
	print("REEL_VISUAL_TEST_RESULT ", JSON.stringify({"checks": checks, "failures": failures, "last_snapshot": reel.performance_snapshot()}))
	quit(0 if failures == 0 else 1)
