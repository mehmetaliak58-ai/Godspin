extends SceneTree
var phases: Array = []
var draw_count := 0
func _initialize() -> void:
	call_deferred("run")
func run() -> void:
	var canvas := Control.new()
	canvas.size = Vector2(720, 1600)
	root.add_child(canvas)
	var fx = load("res://scripts/vfx/vfx_manager.gd").new()
	canvas.add_child(fx)
	fx.phase_changed.connect(func(phase: String, _id: String): phases.append(phase))
	fx.draw.connect(func(): draw_count += 1)
	var chars: Array = JSON.parse_string(FileAccess.get_file_as_string("res://data/characters.json"))
	for ch in chars:
		phases.clear()
		fx.play_ultimate(ch, false)
		fx._duration = 0.45
		await fx.finished
		assert(phases == ["anticipation", "character_reveal", "power_impact", "reel_transformation", "reward_reveal"], str(ch.id) + " phases " + str(phases))
		assert(fx._canvas_scale == Vector2.ONE)
		assert(fx._canvas_offset == Vector2(0, 160))
		assert(not fx._portal_layer.visible and not fx._beam_layer.visible)
		fx.set_quality("Düşük")
		fx.preview(ch, false)
		fx._duration = 0.12
		await process_frame
		assert(not fx._portal_layer.visible and not fx._beam_layer.visible)
		fx.skip()
		await process_frame
		assert(not fx.is_playing())
		fx.set_quality("Ultra")
		fx.preview(ch, true)
		fx._duration = 0.12
		await process_frame
		assert(not fx._portal_layer.visible and not fx._beam_layer.visible)
		fx.skip()
		await process_frame
	for tier in fx.WIN_TIERS:
		fx.celebrate(tier, 1700021123, Color.GOLD)
		fx._duration = 0.18
		await fx.finished
	assert(fx._amount == 1700021123)
	assert(fx._particles.size() == 100)
	assert(fx.get_child_count() == 2)
	assert(fx._textures.size() <= 13)
	fx.preview(chars[0])
	fx.preview(chars[1])
	fx.skip()
	await process_frame
	await process_frame
	assert(not fx.is_playing())
	print("VFX_UPGRADE_PASS: 8 five-phase ultimates, all8 previews low/reduced, 7 true win tiers, replacement+skip, centered720x1600, fixed100 particles/2 shader nodes; draws=", draw_count)
	canvas.queue_free()
	await process_frame
	await process_frame
	quit()
