extends SceneTree
## Run: godot --headless --path . --script res://tests/test_meta.gd

var failures: Array[String] = []
var checks := 0
var test_dir := "/tmp"

func _init() -> void:
	var configured := OS.get_environment("GODSPIN_TEST_DIR")
	if not configured.is_empty():
		test_dir = configured
	DirAccess.make_dir_recursive_absolute(test_dir)
	call_deferred("run")

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures.append(message)
		push_error(message)

func fresh(suffix: String) -> GodspinGame:
	var game := GodspinGame.new()
	game.saves.path = test_dir.path_join("godspin-meta-%s.json" % suffix)
	game.initialize(false)
	game.set_seed(8152026)
	return game

func run() -> void:
	var game := fresh("main")
	check(game.characters.size() == 8, "8 veri odaklı karakter bulunmalı.")
	check(game.slot_ids.size() == 6, "6 salon bulunmalı.")
	check(game.state.balance == 100000, "Başlangıç bakiyesi 100.000 olmalı.")
	check(game.bet() == 500, "Başlangıç bahsi 500 olmalı.")
	check(game.character_unlocked("ares") and game.character_unlocked("luna"), "Ares ve Luna başlangıçta açık olmalı.")
	check(not game.select_character("orion"), "Kilitli karakter seçilememeli.")
	check(not game.select_character("unknown"), "Bilinmeyen karakter seçilememeli.")
	check(not game.select_slot("cosmic_infinity"), "Kilitli salon seçilememeli.")
	var first := game.spin()
	check(bool(first.get("ok", false)), "İlk gerçek dönüş hesaplanmalı.")
	check(int(game.state.balance) == 100000 - int(first.charge) + int(first.payout), "Bakiye hesaplanan kazanç ve ücretle tam eşleşmeli.")
	check(game.energy() >= 60, "Ares enerjisi normal dönüşle dolmalı.")
	check(game.state.spins == 1 and game.state.xp == 10, "Dönüş ve XP kaydedilmeli.")
	check(game.claim_achievement("first_spin") == 5000, "İlk dönüş başarımı doğru ödül vermeli.")
	check(game.claim_achievement("first_spin") == 0, "Başarım iki kez alınamamalı.")
	check(game.claim_quest("daily_spins") == 0, "Eksik görev ödül vermemeli.")
	game.state.energy.ares = 100
	var balance_before := int(game.state.balance)
	var power := game.activate_ultimate()
	check(bool(power.ok) and int(game.state.bonus_remaining) == 3, "Ultimate 3 gerçek güç dönüşü açmalı.")
	check(game.energy() == 0, "Ultimate enerjiyi tüketmeli.")
	check(not game.select_character("luna") and not game.select_slot("neon_chaos"), "Güç turu sırasında karakter/salon sabit kalmalı.")
	check(game.change_bet(2) == 500, "Güç bahsi aktivasyonda sabitlenmeli.")
	check(not bool(game.activate_ultimate().ok), "Aktif güç yeniden açılmamalı.")
	var powers_paid := 0
	for expected_multiplier in [2.0, 3.0, 5.0]:
		var special := game.spin()
		check(bool(special.ok) and int(special.charge) == 0 and bool(special.is_bonus), "Güç dönüşü ücret almamalı.")
		check(float(special.multiplier) == expected_multiplier, "Ares yükselen ×2/3/5 çarpanı uygulamalı.")
		powers_paid += int(special.payout)
	check(int(game.state.balance) == balance_before + powers_paid, "Güç bakiyesi yalnızca gerçek ödemeleri eklemeli.")
	check(game.energy() == 0 and game.state.bonus_remaining == 0, "Güç turları enerji üretmemeli ve tamamlanmalı.")
	check(game.claim_quest("daily_power") == 20000, "Güç görevi alınabilmeli.")
	check(game.claim_quest("daily_power") == 0, "Günlük görev iki kez alınamamalı.")
	game.state.xp = 720
	for hero in game.characters:
		game.state.free_spins = 0
		var id := str(hero.id)
		check(game.select_character(id), "Yüksek seviyede %s seçilebilmeli." % id)
		game.state.energy[id] = 100
		check(bool(game.activate_ultimate().ok), "%s Ultimate açılmalı." % id)
		for index in range(3):
			var special := game.spin()
			check(bool(special.ok) and int(special.charge) == 0, "%s güç dönüşü gerçek ücretsiz sonuç üretmeli." % id)
			check(int(special.payout) >= 0, "%s gücü negatif ödeme üretmemeli." % id)
		check(game.state.bonus_remaining == 0, "%s gücü 3 turda bitmeli." % id)
	game.state.free_spins = 0
	game.select_character("seraphine")
	game.state.daily.spins = 10
	check(game.claim_quest("daily_spins") == 12500, "Seraphine görev ödülünü %25 artırmalı.")
	check(game.energy() >= 10, "Görev ödülü 10 Ultimate enerjisi de vermeli.")
	game.state.free_spins = 3
	game.state.free_bet = 500
	game.state.free_slot = "golden_empire"
	check(game.change_bet(4) == 500 and not game.select_slot("neon_chaos") and not game.select_character("ares"), "Ücretsiz dönüşler karakter/salon/bahsi kilitlemeli.")
	game.state.free_spins = 0
	game.state.xp = 119
	var before_level := int(game.state.balance)
	var level_result := game.spin()
	check(level_result.progress_reward == 6250 and level_result.level_after == 2, "Seraphine seviye 2 ödülünü 5.000 yerine 6.250 vermeli.")
	check(int(game.state.balance) == before_level - int(level_result.charge) + int(level_result.payout) + int(level_result.progress_reward), "Seviye ödülü çizgi kazancından ayrı ve doğru eklenmeli.")
	game.state.balance = 0
	game.state.free_spins = 0
	check(not game.can_spin(), "Sıfır bakiyede ücretli dönüş yapılmamalı.")
	check(not bool(game.spin().ok), "Sıfır bakiyede dönüş reddedilmeli.")
	check(game.rescue() == 25000 and game.state.balance == 25000, "Toparlanma bekleme/ödeme olmadan 25.000 çip vermeli.")
	check(game.rescue() == 0, "Yeterli bakiye varken toparlanma alınamamalı.")
	check(game.purchase_cosmetic("royal_frame"), "Sanal çiple kozmetik alınabilmeli.")
	var cosmetic_balance := int(game.state.balance)
	check(game.purchase_cosmetic("royal_frame") and int(game.state.balance) == cosmetic_balance, "Sahip olunan kozmetik çip alınmadan kuşanılmalı.")
	check(game.equip_cosmetic("royal_frame"), "Sahip olunan kozmetik kuşanılabilmeli.")
	check(bool(game.cosmetics()[0].owned) and bool(game.cosmetics()[0].equipped), "Kozmetik UI sahiplik/kuşanma durumunu göstermeli.")
	game.set_setting("quality", "Düşük")
	game.set_setting("reduced_motion", true)
	game.set_setting("fps", 30)
	check(Engine.max_fps == 30 and SettingsManager.intensity(game.state.settings) == 0.15, "30 FPS ve azaltılmış hareket uygulanmalı.")
	game.set_setting("quality", "INVALID")
	check(game.state.settings.quality in SettingsManager.QUALITIES, "Geçersiz kalite kaydedilmemeli.")
	check(game.save(), "Atomik kayıt başarılı olmalı.")
	var restored := fresh("main")
	restored.initialize(true)
	check(restored.state.balance == game.state.balance and restored.state.spins == game.state.spins, "Kapanış/açılış bakiyeyi ve ilerlemeyi korumalı.")
	check(restored.state.active_cosmetic == "royal_frame" and restored.state.settings.fps == 30, "Kozmetik ve ayarlar korunmalı.")
	game.save()
	var damaged := FileAccess.open(game.saves.path, FileAccess.WRITE)
	damaged.store_string("{bozuk kayıt")
	damaged.close()
	var recovered := game.saves.load_state()
	check(game.saves.recovered and recovered.balance == game.state.balance, "Bozuk ana kayıtta son geçerli yedek geri alınmalı.")
	var validated := SaveManager.validate({"version": 1, "balance": -500, "energy": {"ares": 999999}, "settings": {"sound": "yes", "fps": 120}, "free_spins": -2, "character": "fake", "history": "bad"})
	check(validated.balance == 0 and validated.energy.ares == 100 and validated.free_spins == 0 and validated.character == "ares", "Kayıt aralıkları ve kimlikleri doğrulanmalı.")
	check(validated.history is Array and validated.settings.sound is bool and validated.settings.fps == 60, "Bozuk alt yapılar güvenli varsayılanlara dönmeli.")
	var malformed_settings := SettingsManager.normalize({"fps": {"invalid": 30}, "quality": ["Ultra"], "music": 1})
	check(malformed_settings.fps == 60 and malformed_settings.quality == "Yüksek" and malformed_settings.music == true, "Türü bozuk ayarlar hatasız varsayılana dönmeli.")
	var resumed := fresh("resume")
	resumed.state.xp = 720
	resumed.select_character("luna")
	resumed.select_slot("neon_chaos")
	resumed.change_bet(1)
	resumed.state.energy.luna = 100
	resumed.activate_ultimate()
	resumed.spin()
	check(resumed.state.bonus_remaining == 2, "Kısmi güç turu iki dönüş bırakmalı.")
	var reopened := fresh("resume")
	reopened.initialize(true)
	check(reopened.state.bonus_remaining == 2 and reopened.state.bonus_index == 1 and reopened.bet() == 1000 and reopened.state.character == "luna" and reopened.state.slot == "neon_chaos", "Kısmi Ultimate yeniden açılışta aynı karakter/salon/bahis/turla sürmeli.")
	reopened.state.bonus_remaining = 0
	reopened.state.free_spins = 2
	reopened.state.free_bet = 1000
	reopened.state.free_slot = "neon_chaos"
	reopened.save()
	var free_reopened := fresh("resume")
	free_reopened.initialize(true)
	check(free_reopened.state.free_spins == 2 and free_reopened.bet() == 1000 and not free_reopened.select_character("ares") and not free_reopened.select_slot("golden_empire"), "Kayıttan açılan ücretsiz dönüşler bahis/salon/karakter kilidini korumalı.")
	var migrated := SaveManager.validate({"version": 1, "balance": 1000, "xp": 720, "bet_index": 2, "free_spins": 3, "slot": "neon_chaos"})
	check(migrated.free_bet == 1000 and migrated.free_slot == "neon_chaos", "Eski sürüm-1 ücretsiz dönüşler orijinal bahis/salona taşınmalı.")
	var left := fresh("seed-left")
	var right := fresh("seed-right")
	for index in range(25):
		var a := left.spin()
		var b := right.spin()
		check(a.grid == b.grid and a.payout == b.payout and left.state.balance == right.state.balance, "Sabit seed tam oyun sonuçlarını tekrarlamalı.")
	var simulation := fresh("simulation")
	simulation.state.xp = 720
	var simulated := 0
	for slot_id in simulation.slot_ids:
		simulation.state.free_spins = 0
		simulation.select_slot(str(slot_id))
		for index in range(200):
			if not simulation.can_spin():
				simulation.rescue()
			var before := int(simulation.state.balance)
			var result := simulation.spin()
			check(bool(result.ok) and int(simulation.state.balance) == before - int(result.charge) + int(result.payout) + int(result.progress_reward), "Simülasyon %s bakiyesi gerçeği korumalı." % slot_id)
			check(int(simulation.state.balance) >= 0 and int(simulation.state.free_spins) >= 0 and simulation.state.history.size() <= 30, "Simülasyon sayaçları güvenli aralıkta kalmalı.")
			simulated += 1
	print("META TESTS: %s checks, %s simulated spins, %s failures" % [checks, simulated, failures.size()])
	for message in failures:
		print("FAIL: " + message)
	for suffix in ["main", "resume", "seed-left", "seed-right", "simulation"]:
		for extension in ["", ".bak", ".tmp"]:
			DirAccess.remove_absolute(test_dir.path_join("godspin-meta-%s.json%s" % [suffix, extension]))
	quit(0 if failures.is_empty() else 1)
