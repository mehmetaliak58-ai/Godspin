extends SceneTree
## Run: godot --headless --path . --script res://tests/test_slot_engine.gd

const EngineScript = preload("res://scripts/core/slot_engine.gd")
const PaytableScript = preload("res://scripts/core/paytable_manager.gd")
var checks := 0
var failed := 0
var summaries: Array = []

func _init() -> void:
	call_deferred("_run")

func _check(condition: bool, text: String) -> void:
	checks += 1
	if not condition:
		failed += 1
		push_error("FAIL: " + text)

func _grid(rows: Array) -> Array:
	var result: Array = [[], [], [], [], []]
	for row in rows:
		for column in range(5):
			result[column].append(row[column])
	return result

func _run() -> void:
	var engine = EngineScript.new()
	var config: Dictionary = engine.load_config("golden_empire")
	_check(not config.is_empty(), "Altın salon config yüklenmeli")
	_check(engine.load_config("../../secret").is_empty(), "Sadece kayıtlı salon kimlikleri okunmalı")
	_check(engine.spin({}, 100).payout == 0, "Hatalı config ödül vermemeli")
	_check(engine.spin(config, -100).payout == 0, "Negatif bahis reddedilmeli")
	_check(engine.spin(config, 0).error != "", "Sıfır bahis reddedilmeli")
	var fixture := config.duplicate(true)
	fixture.paylines = [[0, 0, 0, 0, 0]]
	var neutral := ["gem", "ring", "ace", "chalice", "gem"]
	var grid := _grid([["crown", "crown", "crown", "ace", "gem"], neutral, neutral])
	var result: Dictionary = engine.evaluate(grid, fixture, 100)
	_check(result.payout == 2000, "3 Taç tam olarak çizgi bahsinin 20 katını ödemeli")
	_check(result.wins.size() == 1 and result.wins[0].count == 3, "Soldan başlayan üçlü çizgi")
	_check(result.wins[0].cells == [Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0)], "Kazanan hücreler doğru olmalı")
	grid[0][0] = "wild"
	_check(engine.evaluate(grid, fixture, 100).payout == 2000, "Baştaki Joker yerine geçmeli")
	grid = _grid([["gem", "crown", "crown", "crown", "crown"], neutral, neutral])
	_check(engine.evaluate(grid, fixture, 100).payout == 0, "Ortadan başlayan eşleşme ödemez")
	grid = _grid([["wild", "wild", "wild", "wild", "wild"], neutral, neutral])
	_check(engine.evaluate(grid, fixture, 100).payout == 25000, "Tam Joker satırı en yüksek geçerli ödemeyi seçmeli")
	grid = _grid([["wild", "wild", "wild", "crown", "crown"], neutral, neutral])
	_check(engine.evaluate(grid, fixture, 100).payout == 20000, "3 Joker + 2 Taç: 5 Taç ödemesi daha yüksek")
	_check(engine.evaluate(grid, fixture, 100, 3).payout == 60000, "Çarpan gerçek ödemeye uygulanmalı")
	grid = _grid([neutral, ["scatter", "scatter", "scatter", "ring", "ace"], neutral])
	result = engine.evaluate(grid, fixture, 100)
	_check(result.payout == 200 and result.free_spins == 5, "3 Bonus = 2×bahis +5 ücretsiz")
	_check(result.scatter_count == 3 and result.wins[0].line == -1, "Bonus çizgilerden bağımsız")
	grid[3][1] = "scatter"
	grid[4][1] = "scatter"
	result = engine.evaluate(grid, fixture, 100)
	_check(result.payout == 2500 and result.free_spins == 10, "5 Bonus =25×bahis +10 ücretsiz")
	grid[0][2] = "scatter"
	_check(engine.evaluate(grid, fixture, 100).payout == 2500, "5+ Bonus aynı üst dilimde öder")
	_check(engine.evaluate([[]], fixture, 100).error != "", "Hatalı grid reddedilmeli")
	var bad := config.duplicate(true)
	bad.weights.crown = -2
	_check(engine.spin(bad, 100).error != "", "Negatif sembol ağırlığı reddedilmeli")
	bad = config.duplicate(true)
	bad.paylines[0][0] = 99
	_check(engine.spin(bad, 100).error != "", "Çizgi sınırları doğrulanmalı")
	_check(EngineScript.win_tier(500, 100) == "BÜYÜK KAZANÇ", "Büyük kazanç gerçek 5× ile başlar")
	_check(EngineScript.win_tier(100000, 100) == "TANRISAL BÜYÜK ÖDÜL", "Büyük ödül etiketi gerçek 1000× ile başlar")

	for id in EngineScript.SLOT_IDS:
		var salon: Dictionary = engine.load_config(id)
		_check(not salon.is_empty(), "%s config yüklenmeli" % id)
		_check(PaytableScript.describe(salon).contains("olasılık"), "%s kuralları gerçek olasılıkları göstermeli" % id)
		var a = EngineScript.new()
		var b = EngineScript.new()
		a.set_seed(39107)
		b.set_seed(39107)
		for index in range(40):
			_check(a.spin(salon, 1000) == b.spin(salon, 1000), "%s seed tekrar üretilebilir (%s)" % [id, index])

	# Force every symbol to crown: makes cascade and jackpot deterministic.
	var crown_only := config.duplicate(true)
	for symbol in EngineScript.SYMBOLS:
		crown_only.weights[symbol] = 100 if symbol == "crown" else 0
	var normal: Dictionary = engine.spin(crown_only, 900)
	_check(normal.payout == 180000, "9 çizgide toplam 200× gerçek ödeme")
	var cascade: Dictionary = engine.load_config("empress_treasure")
	cascade.weights = crown_only.weights.duplicate(true)
	var cascade_result: Dictionary = engine.spin(cascade, 1200)
	_check(cascade_result.cascades.size() == 4, "4 düşüş sınırı sonsuz döngüyü önlemeli")
	_check(cascade_result.payout == 3600000, "Cascade 1+2+3+4+5 toplam çarpanı =15")
	var cosmic: Dictionary = engine.load_config("cosmic_infinity")
	cosmic.weights = crown_only.weights.duplicate(true)
	cosmic.mechanic.multipliers = {"1": 100}
	var cosmic_result: Dictionary = engine.spin(cosmic, 900)
	_check(cosmic_result.payout == 1080000 and cosmic_result.bonus_data.get("jackpot", false), "Doğal 5 Taç gerçek ek1000× jackpot")
	var thunder: Dictionary = engine.load_config("gods_of_thunder")
	thunder.weights = crown_only.weights.duplicate(true)
	var thunder_result: Dictionary = engine.spin(thunder, 1200, {"thunder_ready": true})
	_check(thunder_result.transformations.size() == 2 and thunder_result.free_spins == 1, "Yıldırım sayacı iki farklı Joker yaratmalı")
	var cosmic_counter: Dictionary = engine.spin(cosmic, 900, {"cosmic_ready": true})
	_check(cosmic_counter.transformations.size() == 3 and cosmic_counter.multiplier == 2, "Kozmik sayaç gerçek Joker makarası ve ×2 üretmeli")

	for character in ["ares", "luna", "vex", "noctis", "kael", "seraphine", "dante", "orion"]:
		engine.set_seed(2371)
		var power: Dictionary = engine.spin(config, 1000, {"character": character})
		_check(power.bonus_text != "", "%s gücü gerçek bonus açıklaması üretmeli" % character)
		_check(power.payout >= 0 and power.multiplier >= 1, "%s geçerli ulti ödülü" % character)
		_check(PaytableScript.ultimate_rules(character) != "", "%s açıklanmış ulti kuralı" % character)
		if character in ["luna", "kael", "orion"]:
			_check(not power.transformations.is_empty(), "%s gerçek sembol değiştirir" % character)

	# 100,002 independent paid spins across the six configurations.
	for id in EngineScript.SLOT_IDS:
		var salon: Dictionary = engine.load_config(id)
		engine.set_seed(552180 + EngineScript.SLOT_IDS.find(id))
		var spent := 0
		var won := 0
		var bonuses := 0
		var free_awards := 0
		var jackpot_count := 0
		for index in range(16667):
			var spin_result: Dictionary = engine.spin(salon, 1000)
			spent += 1000
			won += int(spin_result.payout)
			free_awards += int(spin_result.free_spins)
			if spin_result.bonus_triggered:
				bonuses += 1
			if spin_result.bonus_data.get("jackpot", false):
				jackpot_count += 1
			var line_total := 0
			for win in spin_result.wins:
				line_total += int(win.payout)
			var cascade_total := 0
			for stage in spin_result.cascades:
				cascade_total += int(stage.payout)
			_check(spin_result.payout >= 0, "%s negatif ödül yok" % id)
			_check(spin_result.base_payout == line_total, "%s gerçek çizgi/bonus toplamı" % id)
			_check(spin_result.payout == line_total + spin_result.bonus_payout + cascade_total, "%s toplam ödül muhasebesi" % id)
			_check(spin_result.grid.size() == 5 and spin_result.grid[0].size() == int(salon.rows), "%s makara ölçüsü" % id)
			_check(spin_result.free_spins >= 0, "%s ücretsiz dönüş hatası yok" % id)
			_check(spin_result.tier == EngineScript.win_tier(spin_result.payout, 1000), "%s etiketi gerçek miktara göre" % id)
		summaries.append({"slot": id, "spins": 16667, "paid": spent, "won": won, "sample_base_return": float(won) / float(spent), "bonuses": bonuses, "free_spins_awarded": free_awards, "jackpots": jackpot_count})
		print("SIMULATION ", JSON.stringify(summaries[-1]))
	print("SLOT_ENGINE_TEST_RESULT ", JSON.stringify({"checks": checks, "failed": failed, "simulated_spins": 100002, "samples": summaries}))
	quit(1 if failed > 0 else 0)
