extends SceneTree
## Logical touch targets and responsive control geometry; deliberately excludes cropped art.
## Run with isolated userdata: godot --headless --path . --script res://tests/test_ui_layout.gd

const DIMENSIONS := [Vector2i(360, 640), Vector2i(393, 852), Vector2i(412, 915), Vector2i(720, 1280), Vector2i(1080, 1920), Vector2i(768, 1024)]
var checks := 0
var failures: Array[String] = []
var main: Control

func _init() -> void:
	call_deferred("run")

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures.append(message)
		push_error(message)

func buttons_in(node: Node) -> Array[Button]:
	var result: Array[Button] = []
	if node is Button:
		result.append(node)
	for child in node.get_children():
		result.append_array(buttons_in(child))
	return result

func button_name(button: Button) -> String:
	return button.text.replace("\n", " ")

func min_touch_targets(node: Node, context: String) -> void:
	for button in buttons_in(node):
		check(button.size.x >= 44.0 and button.size.y >= 44.0, "%s: '%s' touch target %s is smaller than 44 logical pixels" % [context, button_name(button), button.size])

func bounds(rect: Rect2, container: Rect2) -> bool:
	return container.grow(0.75).encloses(rect)

func screen_controls(context: String) -> void:
	var viewport := Rect2(Vector2.ZERO, main.size)
	var frame: Control = main.get("frame")
	check(bounds(frame.get_global_rect(), viewport), "%s: logical 720×1280 frame must fit expanded viewport %s" % [context, main.size])
	var visible: Array[Button] = []
	for button in buttons_in(frame):
		if button.is_visible_in_tree():
			visible.append(button)
			check(bounds(button.get_global_rect(), viewport), "%s: '%s' control must stay inside visible viewport" % [context, button_name(button)])
	min_touch_targets(frame, context)
	# Every simultaneously visible main-screen target must have a distinct hit area.
	for index in range(visible.size()):
		for next in range(index + 1, visible.size()):
			var overlap := visible[index].get_global_rect().intersection(visible[next].get_global_rect())
			check(overlap.size.x <= 0.75 or overlap.size.y <= 0.75, "%s: '%s' and '%s' touch targets overlap" % [context, button_name(visible[index]), button_name(visible[next])])

func modal_controls(context: String) -> void:
	var layer: Control = main.get("modal_layer")
	var box: Control = main.get("modal_box")
	check(layer.visible and is_instance_valid(box), "%s: modal must open" % context)
	if not is_instance_valid(box):
		return
	check(bounds(box.get_global_rect(), Rect2(Vector2.ZERO, main.size)), "%s: modal panel must fit viewport" % context)
	min_touch_targets(layer, context)
	# Scrollable rows can lie outside the viewport, so only the close button is bounded here.
	for button in buttons_in(box):
		if button.text == "×":
			check(bounds(button.get_global_rect(), box.get_global_rect()), "%s: modal close control must stay inside panel" % context)

func settle() -> void:
	await process_frame
	await process_frame

func run() -> void:
	root.content_scale_size = Vector2i(720, 1280)
	root.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	root.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_EXPAND
	root.size = Vector2i(720, 1280)
	var scene: PackedScene = load("res://scenes/main.tscn")
	check(scene != null, "Main scene must load")
	if scene == null:
		quit(1)
		return
	main = scene.instantiate()
	root.add_child(main)
	await settle()
	var ready_main := main.get("game") != null and main.get("fx") != null and main.get("audio") != null
	check(ready_main, "Main UI dependencies must finish initialization")
	if not ready_main:
		quit(1)
		return
	var game: GodspinGame = main.get("game")
	game.initialize(false)
	game.state.xp = 720
	game.state.settings.sound = false
	game.state.settings.music = false
	var test_dir := OS.get_environment("GODSPIN_TEST_DIR")
	if test_dir.is_empty():
		test_dir = "/tmp/godspin-ui-layout"
	DirAccess.make_dir_recursive_absolute(test_dir)
	game.saves.path = test_dir.path_join("layout-save.json")
	main.call("_apply_settings")
	for dimensions in DIMENSIONS:
		root.size = dimensions
		await settle()
		main.call("_position_frame")
		main.call("_show_lobby")
		await settle()
		screen_controls("%s lobby" % dimensions)
		main.call("_show_slot")
		await settle()
		screen_controls("%s slot" % dimensions)
		var spin: Button = main.get("spin_button")
		var power: Button = main.get("power_button")
		check(spin.size.y >= 88 and power.size.y >= 88, "%s: primary spin/power controls must remain large" % dimensions)
		check(spin.position.y > 900 and power.position.y > 900, "%s: primary controls must stay in lower thumb region" % dimensions)
		var before_balance := int(game.state.balance)
		var before_spins := int(game.state.spins)
		# A press feedback event must not compute a spin before the action is released.
		spin.button_down.emit()
		await settle()
		check(int(game.state.balance) == before_balance and int(game.state.spins) == before_spins, "%s: button-down feedback must not mutate game result" % dimensions)
		spin.button_up.emit()
		await create_timer(0.2).timeout
		check(spin.scale.x >= 0.95 and spin.scale.y >= 0.95, "%s: spin button must recover from press feedback" % dimensions)
		for method in ["_characters", "_slots", "_quests", "_profile", "_cosmetics", "_settings", "_rules", "_paytable", "_history"]:
			main.call(method)
			await settle()
			modal_controls("%s %s" % [dimensions, method])
			main.call("_close_modal")
		main.call("_character_detail", "luna")
		await settle()
		modal_controls("%s character detail" % dimensions)
		main.call("_close_modal")
	# Preview is presentation only: all eight powers must leave both persisted state and RNG untouched.
	game.state.settings.reduced_motion = false
	main.call("_apply_settings")
	check(main.has_method("_preview_ultimate"), "Character power preview must be implemented")
	if main.has_method("_preview_ultimate"):
		for character in game.characters:
			var before_state := JSON.stringify(game.state)
			var before_engine_rng := game.engine.rng.state
			var before_meta_rng := game.rng.state
			await main.call("_preview_ultimate", str(character.id))
			check(JSON.stringify(game.state) == before_state, "%s: visual preview must not change balance, energy, bonus, save state or selection" % str(character.id))
			check(game.engine.rng.state == before_engine_rng and game.rng.state == before_meta_rng, "%s: visual preview must not consume gameplay RNG" % str(character.id))
			var effects: Node = main.get("fx")
			check(not bool(main.get("busy")) and not bool(effects.call("is_playing")), "%s: visual preview must finish and release controls" % str(character.id))
			check(str(effects.get("_id")) == str(game.state.character), "%s: preview must restore selected hero for subsequent win effects" % str(character.id))
	print("UI_LAYOUT_RESULT: %s checks, %s viewport sizes, %s failures" % [checks, DIMENSIONS.size(), failures.size()])
	for failure in failures:
		print("FAIL: " + failure)
	var audio: Node = main.get("audio")
	audio.call("stop_all")
	await create_timer(0.1).timeout
	root.remove_child(main)
	main.queue_free()
	await settle()
	for extension in ["", ".bak", ".tmp"]:
		DirAccess.remove_absolute(test_dir.path_join("layout-save.json") + extension)
	quit(0 if failures.is_empty() else 1)
