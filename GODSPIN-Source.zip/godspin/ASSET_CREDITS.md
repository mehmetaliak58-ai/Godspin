# GODSPIN varlık kaynakları ve lisanslar

Araştırma tarihi: 8 Ekim 2026. Bu kayıt, oyunda gerçekten bulunan dosyalar ile yalnızca incelenen kaynakları ayırır. Mevcut özgün karakter ve salon sanatları korunmuştur.

## Projeye alınmış internet kaynaklı shader kodu

| Dosya | Kaynak ve yazar | Lisans | Değişiklik / kullanım durumu |
| --- | --- | --- | --- |
| `assets/vendor/godotshaders/energy_beams.gdshader` | [Energy Beams](https://godotshaders.com/shader/energy-beams/), **pend00** | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) | Tam kod tarayıcı üzerinden alınarak yerel dosyaya yazıldı. Godot 4 `source_color` ipuçları, zaman sınırı ve sıfır ilerleme için güvenli kenar aralığı eklendi. Orijinal `energy_beams_original.txt` yanında saklanır. Çalışma zamanına bağlanma, VFX entegrasyonunun parçasıdır. |
| `assets/vendor/godotshaders/portal.gdshader` | [Portals](https://godotshaders.com/shader/portals/), **rt048699** | CC0 1.0 | Tam kod tarayıcı üzerinden alınarak yerel dosyaya yazıldı. Additive blend, güç kontrolü, sınırlı zaman ve doğru sıralı smoothstep kenarları eklendi. Orijinal `portals_original.txt` yanında saklanır. Çalışma zamanına bağlanma, VFX entegrasyonunun parçasıdır. |

İlgili kaynak sayfalarındaki CC0 izni shader kodunu kapsar. Sayfalardaki ekran görüntüleri, videolar veya bunların gösterdiği başka varlıklar bu projeye alınmamıştır. İki shader artık `GodspinVFX` içinde gerçek `ShaderMaterial` katmanlarına bağlanmıştır: portal Orion / Noctis / Vex ve güçlü kutlamalarda; ışın Ares / Luna / Kael / Seraphine / Dante güçlerinde kullanılır. Düşük ve azaltılmış efekt profilleri iki katmanı gizler. Kaynak yükleme ve çalışma akışları test edilmiştir; gerçek GPU görüntüsünün kalitesi ayrı doğrulama bekler.

## Seçilen Kenney paketleri

Aşağıdaki paketlerin lisansı yazarın resmi sitesinde ve kendi OpenGameArt gönderisinde ayrı ayrı doğrulanmıştır. Yazar **Kenney**; lisans **CC0 1.0 Universal**. Atıf zorunlu değildir; burada korunur. Bu bölüm, dosya indirme ve kullanım durumu doğrulanınca güncellenir.

| Paket | Birincil kaynak / doğrudan indirme | Hedef kullanım | Durum |
| --- | --- | --- | --- |
| Fantasy UI Borders | [Kenney](https://kenney.nl/assets/fantasy-ui-borders), [yazarın OGA gönderisi](https://opengameart.org/content/fantasy-ui-borders), [ZIP](https://opengameart.org/sites/default/files/kenney_fantasy-ui-borders.zip) | Dokuz dilimli altın karakter kartı, salon / makara çerçevesi | Lisans ve gerçek ZIP adresi doğrulandı; henüz yerel indirme bu kayıt tarafından doğrulanmadı. |
| Particle Pack | [Kenney](https://kenney.nl/assets/particle-pack), [yazarın OGA gönderisi](https://opengameart.org/content/particle-pack-80-sprites), [ZIP](https://opengameart.org/sites/default/files/kenney_particlePack.zip) | Yıldız, ışık halkası, duman, flare; sınırlı sayıda additive VFX dokusu | Lisans ve ZIP adresi doğrulandı; henüz yerel indirme bu kayıt tarafından doğrulanmadı. |
| Casino Audio | [Kenney](https://kenney.nl/assets/casino-audio), [yazarın OGA gönderisi](https://opengameart.org/content/54-casino-sound-effects-cards-dice-chips), [ZIP](https://opengameart.org/sites/default/files/kenney_casino-audio.zip) | Gerçek çip ve kart foley sesleri | Lisans ve ZIP adresi doğrulandı; henüz yerel indirme bu kayıt tarafından doğrulanmadı. |
| UI Audio | [Kenney](https://kenney.nl/assets/ui-audio), [yazarın OGA gönderisi](https://opengameart.org/content/51-ui-sound-effects-buttons-switches-and-clicks), [ZIP](https://opengameart.org/sites/default/files/UI_SFX_Set.zip) | Temiz fiziksel dokunma / anahtar sesleri | Lisans ve ZIP adresi doğrulandı; henüz yerel indirme bu kayıt tarafından doğrulanmadı. |

Paket sürümleri farklı kaynaklarda değişebilir: resmi Casino Audio sayfası 50 dosya, OGA gönderisi 54 ses; resmi UI Audio sayfası 50 dosya, eski OGA UI paketi 51 ses belirtir. Entegrasyon için dosya adları ve iç lisans, indirilen gerçek arşiv üzerinden doğrulanmalıdır. Tüm paketleri projeye eklemek yerine sanat yönüne uyan birkaç doku ve ses seçilir.

## İncelenmiş, oyuna eklenmemiş kaynaklar

| Kaynak | Doğrulanan lisans / yazar | Seçim kararı |
| --- | --- | --- |
| [UI Pack RPG Expansion](https://kenney.nl/assets/ui-pack-rpg-expansion) | CC0; Kenney | Fantasy UI Borders ile tutarlı küçük bir alt küme yeterli olduğundan ikinci genel panel seti henüz seçilmedi. |
| [UI Pack](https://kenney.nl/assets/ui-pack) | CC0; Kenney | Düz genel arayüz elemanları, mevcut fantasy sanatına göre öncelikli değil. |
| [Impact Sounds](https://kenney.nl/assets/impact-sounds) | CC0; Kenney | Ultimate foley için değerlendirildi; mevcut özgün bas / impact sentezi korunabilir. |
| [Customizable Health/Energy Bar](https://godotshaders.com/shader/customizable-health-energy-bar-2d-canvas-not-a-progress-bar/) | CC0; trainerx7979 / Jon Berg | CRT / osiloskop dili GODSPIN'in lüks fantasy arayüzüne uymadığı için alınmadı. |
| [Glow for 2D Demo](https://godotengine.org/asset-library/asset/2715) | MIT; Godot Engine | Resmi uygulama referansı. Mobil Compatibility renderer için ağır HDR glow bağımlılığına geçilmedi; demo kodu indirilmedi. |
| [Thunder.wav](https://freesound.org/people/Xythe/sounds/37299/) | CC0; Xythe | Doğal gök gürültüsü adayı. İndirilmedi; ses dosyası projeye alınmış gibi gösterilmez. |
| [Thunder, Kraków](https://freesound.org/people/vonz/sounds/188767/) | CC0; vonz | Kısa 3,669 saniyelik gök gürültüsü adayı. İndirilmedi. |
| [Fantasy Minimal Pixel Art GUI](https://etahoshi.itch.io/minimal-fantasy-gui-by-eta) | CC0; etahoshi / ETA | Pixel stili mevcut yarı gerçekçi sanatla uyuşmadığı için alınmadı. |

## Korunan özgün GODSPIN varlıkları

- **Karakter portreleri, slot sembolleri ve salon arka planları:** OpenAI görsel üretim aracıyla bu proje için üretilen özgün raster çizimler. Bunlar Kenney veya başka bir asset paketinden indirilmiş sanatlar değildir. Dosya listesi, üretim çıktıları ve sınırlamalar: `assets/ART_NOTES.md`.
- **Sentezlenmiş ambiyans, impact, ultimate ve fanfar sesleri:** `assets/audio/generate_audio.py` üzerinden, harici ses örneği kullanılmadan üretilmiştir. Proje katkıcıları, 2026; mevcut `assets/audio/LICENSE.txt` kapsamında CC0 1.0. Seslendirme veya kaydedilmiş karakter repliği içermez.
- **Özgün vektör sembolleri, Godot çizimleri ve VFX altyapısı:** GODSPIN proje kodu. İnternetten indirildiği iddia edilmez; dış shader uyarlamaları yukarıdaki ayrı kayıtta belirtilir.
- **Metal arayüz çerçevesi, altın / koyu buton ve logo arması:** `assets/ui/*.svg`, bu yükseltmede özgün vektör olarak çizilmiştir. Kenney paketinden indirilmiş dosyalar değildir. Godot rasterizasyonu ile doğrulanmıştır.

## Yazı tipleri

| Dosya | Yazar / lisans | Kaynak ve lisans belgesi |
| --- | --- | --- |
| `assets/fonts/NotoSans-Regular.ttf`, `NotoSans-Bold.ttf` | Google; SIL Open Font License 1.1 | Önceki projede işletim sistemindeki Noto font paketinden kopyalanmıştır. [Resmi Noto](https://github.com/notofonts/noto-fonts); yerel lisans `assets/fonts/LICENSE-Noto-OFL.txt`. |
| `assets/fonts/DejaVuSerif-Bold.ttf` | Bitstream / DejaVu; Bitstream Vera lisansı, DejaVu değişiklikleri public domain | Önceki projede işletim sistemindeki DejaVu font paketinden kopyalanmıştır. [Resmi DejaVu](https://dejavu-fonts.github.io/); yerel lisans `assets/fonts/LICENSE-DejaVu.txt`. |

Lisans metinleri kullanılan işletim sistemi font paketlerinin copyright belgelerinden korunmuştur. Font dosyaları değiştirilmemiştir.
