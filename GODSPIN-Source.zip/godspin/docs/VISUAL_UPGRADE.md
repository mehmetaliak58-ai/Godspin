# Görsel yenileme çalışma kaydı

Görsel yenileme, mevcut slot matematiğini ve kayıt akışını koruyarak arayüzün malzeme hissini, hareketini ve karakter gücü sunumunu geliştirir. Yenileme öncesi proje kopyası `dist/backups/GODSPIN-before-visual-upgrade.zip` içinde korunur.

Bu kayıt **kaynak kod denetimine** dayanır. Bu aşamada başarılı bir masaüstü ekran görüntüsü yakalama ve fiziksel telefon görsel değerlendirmesi tamamlanmış değildir. Aşağıdaki beş alanın seçimi, ekran görüntüsüne bakılarak verilmiş bir sanat kalitesi hükmü değildir; kodda görülen teknik sınırlamaları ve bunlara karşı yapılan geliştirmeleri açıklar.

## Kaynak denetiminden seçilen beş alan

| Alan | Yenileme öncesi kodda görülen sınırlama | Görsel geliştirme yönü |
|---|---|---|
| 1. Düğme ve panel malzemesi | `_style()` çoğunlukla düz `StyleBoxFlat` renk, kenar ve gölge kullanır. `_button()` baskıyı renk değişimiyle verir; açık bir basma/bırakma Tween'i yoktur. Bazı ikinci plandaki dokunma hedefleri 40–42 mantıksal piksel yüksekliktedir. | Metal yüzey vurguları, vektörel kenar/ışık katmanları, basma/bırakma Tween'i, ana düğmeye nefes hareketi ve en az 44 mantıksal piksel hedef. |
| 2. Marka ve sahne derinliği | Lobi logosu iki metin etiketiyle oluşur. Arka plan tek sahne görseli üzerinde hafif kayma, çizgiler ve yıldızlardan oluşur; farklı derinlikte ayrı mimari katmanların hareketi sınırlıdır. | Özel logo sunumu, kontrollü parallax, ışık ve atmosfer katmanları; okunabilir ana oyun alanını koruyan bir sahne kompozisyonu. |
| 3. Karakterin sürekli varlığı | Portre tek illüstrasyon, giriş hareketi ve hafif parlaklık değişimiyle sunulur. Hazır güç düğmesinin ışığı vardır; seçim ekranında ayrı etkileşimli güç önizlemesi ve kademeli sayaç hareketi sınırlıdır. | Portre/auranın birbirinden ayrı hareketi, karakter gücü önizlemesi, enerji göstergesi Tween'i ve durumlara bağlı tepki. Bunlar illüstrasyon üstünde çalışır; rigli 3D karakter iddiası taşımaz. |
| 4. Makara hareketi ve duruşu | Önceki `ReelController`, dönerken hücre sembollerini yaklaşık 16 Hz'de değiştirir ve sinüsle yer değiştirir. Sürekli bir sembol şeridi ve makara bazında yumuşak duruş/bounce hissi sınırlıdır. | Kaydırılan ve maskelenen sembol akışı, farklı sütun duruş zamanları, kısa duruş bounce'u ve hesaplanan dönüşümlerin görünür olması. Nihai grid ve ödemeler motorun önceden hesapladığı sonuçtur. |
| 5. Gücün sahnelenmesi ve dokusu | Sekiz ayrı prosedürel etki vardır; ortak çizim akışında tek zaman parametresi, portrenin yakınlaşması ve ortak impact halkaları kullanılır. Beş aşamanın görsel ayrımı ve doku katmanlarının derinliği artırılabilir. | Beklenti → karakter → güç darbesi → makara dönüşümü → ödül aşamalarının ayrılması, efekt dokuları ve sekiz karakter için ayrı koreografi. Aynı genel efektin yalnızca renk değiştirilmesi hedeflenmez. |

## Kaynakta uygulanmış geliştirmeler

- `assets/ui/` altında özgün metal çerçeve, altın/koyu düğme ve arma SVG dosyaları; dokuz dilimli düğme yüzeyi ve `logo_mark.gd` ile gerçek yazı tipli metal logo sunumu.
- Düğme basma/bırakma Tween'i, en az 48 mantıksal piksel düğme yüksekliği, ekran giriş geçişi ve güç enerjisi için 0,38 saniyelik Tween. Azaltılmış hareket seçeneği bu hareketleri sadeleştirir.
- Karakter detayında **Gücü Önizle**. Önizleme güç tüketmez, bonus açmaz ve kazanç üretmez. Bittiğinde seçili kahraman kazanç efektlerine geri yüklenir.
- Makara tarafında kesintisiz dikey akış, yavaşlama, sütun başına duruş/bounce ve gerçek hesaplanan Joker/Taç dönüşümlerinin gösterimi. Matematik dosyaları bu sunum için değiştirilmez.
- VFX tarafında beş açık aşama, sekiz ayrı koreografi zaman çizelgesi, önceden yüklenen para/mücevher/Joker dokuları ve sınırlı parçacık/şekil havuzu. CC0 portal/ışın shader katmanları kaynakta çalışma zamanı VFX'ine bağlanmıştır; Düşük/azaltılmış efekt modlarında sadeleştirme uygulanır.

Arka plan katmanlarının ve genel kompozisyonun geliştirilmesi bu yenilemenin devam eden parçasıdır. Yukarıdaki liste kaynakta uygulanmış davranışları kaydeder; henüz yakalanmamış ekran görüntülerinin görünümünü onaylamaz.

## Korunan davranış

RNG, sembol ağırlıkları, ödeme çizgileri, bonus olasılıkları, gerçek çip muhasebesi, karakter pasifleri, seviye/görev ödülleri ve kayıt biçimi bu çalışmanın değişiklik alanı değildir. Animasyonu atlamak, hızlandırmak veya düşük kaliteye almak hesaplanan sonucu değiştirmemelidir.

Ücretsiz ve Ultimate dönüşlerinin sabit bahis/salon/karakter davranışı korunur. Üç turluk güç, turbo, otomatik dönüş, ücretsiz toparlanma ve çevrimdışı kayıt çalışmaya devam etmelidir. Yeni görsel özellikler, çalışmayan dekoratif menüler olarak eklenmez.

## Araştırma ve varlık durumu

İnternet kaynak araştırması yapılmaktadır. Kenney'nin CC0 oyun kaynakları araştırma adayları arasındadır; bir sayfanın veya lisans bilgisinin erişilebilir olması, ilgili ikili varlık paketinin indirilmiş ve oyuna eklenmiş olduğu anlamına gelmez. Paket indirme bu aşamada tamamlanmış sayılmaz.

İki gerçek CC0 shader kaynak metni projeye kaydedilmiştir: pend00'nun **Energy Beams** kodu `assets/vendor/godotshaders/energy_beams.gdshader`, rt048699'un **Portals** kodu `assets/vendor/godotshaders/portal.gdshader`. Godot 4 uyarlamaları ve orijinal metinleri birlikte tutulur. Bunlar gerçek alınmış kod dosyalarıdır; Kenney dokularının indirilmiş olması anlamına gelmez. Kaynak sayfaları, lisans ve çalışma zamanı entegrasyon durumu [ASSET_CREDITS.md](../ASSET_CREDITS.md) içinde kayıtlıdır.

Kullanılmayan bir araştırma kaynağı oyunda kullanılmış gibi listelenmez. Önceki özgün karakter/salon/sembol kaynakları korunur; bunların üretim kayıtları [ART_NOTES.md](../assets/ART_NOTES.md) ve [ASSETS.md](ASSETS.md) içinde bulunur.

## Doğrulama

Mevcut matematik ve kayıt testleri: motor için 600.319 kontrol/100.002 dönüş, meta için 2.553 kontrol/1.200 dönüş ve başarılı UI akış testi. Bunlar yenileme öncesi doğrulama temelidir; yenilemenin tamamını yeniden çalıştırmadan yeni sürümün test sonucu olarak sunulmamalıdır.

Yeni bağımsız yerleşim/önizleme testi yenileme sırasında çalıştırıldı: **1.427 kontrol, 6 pencere boyutu, 8 normal hareketli güç önizlemesi, 0 hata**. Test ilk çalıştırmada önizlenen kahramanın sonraki kazanç efektinde seçili kalması hatasını yakaladı; önizleme bitiminde seçili kahramanın FX'e geri yüklenmesiyle bütün sekiz kontrol geçti. Bu sonuç geometrinin ve akışın doğrulamasıdır; shader'ların gerçek GPU görüntüsü, telefon FPS'si veya sanat kalitesi ölçümü değildir.

`tests/test_ui_layout.gd` görsel yorum yerine ölçülebilir arayüz koşulları ekler:

- 360×640, 393×852, 412×915, 720×1280, 1080×1920 ve 768×1024 pencere boyutlarında genişleyen 720×1280 tasarım alanı.
- Lobi ve slot ekranındaki dokunma hedeflerinin görünür ekran içinde kalması ve birbirleriyle çakışmaması.
- Ana ekran ve kaydırılabilir menülerde düğmelerin en az 44 mantıksal piksel hedefe sahip olması.
- Ana Çevir/Güç kontrollerinin büyük ve alt erişim bölgesinde kalması.
- Düğmeye basma geri bildiriminin sonucu erkenden hesaplamaması; bırakılınca ölçeğin geri dönmesi.
- Menü kapanış kontrolünün panel içinde bulunması. İllüstrasyonların bilinçli kırpılması ve kaydırılabilir satırların ekran dışında oluşu hata olarak sayılmaz.
- Sekiz güç önizlemesinin tamamlanması, kontrolü bırakması ve kayıt durumu/enerji/bakiye/bonus/seçim ile oyun RNG'sini değiştirmemesi; sonrasında kazanç efektlerinin seçili kahramana dönmesi.

Örnek çalıştırma, diğer testlerde olduğu gibi ayrı kullanıcı-verisi dizinleriyle yapılmalıdır:

```bash
GODSPIN_TEST_DIR=/tmp/godspin-layout/saves \
XDG_DATA_HOME=/tmp/godspin-layout/data \
XDG_CONFIG_HOME=/tmp/godspin-layout/config \
XDG_CACHE_HOME=/tmp/godspin-layout/cache \
godot --headless --path . --script res://tests/test_ui_layout.gd
```

Başarılı ölçü testleri gerçek telefonlarda görsel kalite, fiziksel dokunma boyutu, güvenli alan, FPS, sıcaklık veya fotosensitivite değerlendirmesi yerine geçmez. Mantıksal 44 piksel hedef, cihazdaki fiziksel milimetre ölçümü değildir.

## Bekleyen doğrulama ve teslim

Geliştirme sonrası motor, meta, UI, makara, VFX ve yeni yerleşim testleri birlikte yeniden çalıştırılmış ve `GODSPIN_QA_PASS` alınmıştır. Arka plan için yumuşak altın/mor ışık katmanları, düşük frekanslı parallax ve karakter idle hareketi de eklenmiştir. Başarılı ekran yakalama gerçekleşirse görüntü ve inceleme sonucu ayrıca kaydedilecektir. Masaüstü yakalama, fiziksel Android testi olarak sunulmayacaktır. Yeniden üretilebilir ekran yakalama denemesi ve mevcut X11 soket kısıtı [VISUAL_QA.md](VISUAL_QA.md) içinde açıklanır.

Android export ortamı için gerekli izin/erişim ve yeni APK üretimi bu aşamada tamamlanmış değildir. Yeni APK'nın varlığı, imzası ve paket doğrulaması ancak gerçek çıktı üretildikten sonra [ANDROID.md](ANDROID.md) içinde güncellenir. Üretilemeyen bir APK için dosya veya indirme bağlantısı uydurulmaz.
