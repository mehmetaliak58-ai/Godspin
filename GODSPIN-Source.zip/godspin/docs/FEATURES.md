# Tamamlanan özellikler ve teslim sınırları

Bu sürüm çalışan, Türkçe ve çevrimdışı bir Godot oyunudur. Aşağıdaki durumlar uygulanmış kod ve var olan kaynaklara dayanır. Görsel sanat yönü ve efektler oluşturulmuştur; ticari ölçekte premium kalite, gerçek cihaz performansı ve uzun süreli oyuncu deneyimi ayrıca değerlendirilmelidir.

## Çalışan oyun ve içerik

| Alan | Uygulanan davranış |
|---|---|
| Açılış ve lobi | Seçili kahraman, hareketli 2.5D saray, çip bakiyesi, seviye, salon seçimi ve çalışan koleksiyon/görev/profil/ayar kontrolleri. |
| Slot motoru | Sonuç animasyondan önce hesaplanır. Ağırlıklı RNG, ödeme çizgileri, Joker ikamesi, Bonus ödemeleri, ücretsiz dönüşler ve gerçek ödeme toplamı. |
| Altı salon | Altın İmparatorluğu 5×3, Neon Kaosu 5×3, Yıldırım Tanrıları 5×4, Joker Çılgınlığı 5×3, İmparatoriçenin Hazinesi 5×4, Kozmik Sonsuzluk 5×3. Ayrı JSON matematiği ve gerçek mekanik farkları. |
| Kontroller | Tek dokunuşla dönüş, bahis −/+, 25 dönüşlük durdurulabilir otomatik seri, turbo, güç ve animasyon atlama. |
| Kazançlar | Hesaplanan tutarı gösteren sayaç, kazanan çizgiler, çarpan ve bonus açıklamaları; yedi gerçek ödeme/bahis eşiğine bağlı kutlama seviyesi. |
| Kayıt | Sürüm 1 yerel JSON, tür/aralık doğrulaması, geçici dosya üzerinden yazım, geçerli yedek ve bozuk kayıtta kurtarma. |
| Ekonomi | 100.000 başlangıç çipi; gerçek ücret/ödül muhasebesi, görevler, başarımlar, seviye ödülleri ve ücretsiz toparlanma. |
| Kurallar ve geçmiş | Oyun içinde ödeme tablosu, Bonus ve güç kuralları; son 30 dönüşün gerçek bahis/ödül kaydı. |
| Gizlilik ve erişim | Tek oyunculu ve çevrimdışı. Hesap, ağ servisi, gerçek para, satın alınabilir kumar kredisi, reklam veya nakit çekim içermez. |

## Karakterler

Sekiz karakterin portresi, Türkçe hikâyesi, renk kimliği, pasifi, kayıtlı enerjisi, karakter XP'si, seçimi ve üç turluk gerçek güç mekaniği bulunur. Yüzler yetişkin fantastik karakterler olarak üretilmiştir.

| Karakter | Açılış seviyesi | Pasif | Gerçek güç mekaniği |
|---|---:|---|---|
| Ares | 1 | Her 8 normal dönüşte ücretsiz dönüş. | Üç ücretsiz turda ×2 / ×3 / ×5. |
| Luna | 1 | Normal dönüş başına 14 enerji. | Her güç turunda iki Joker makarası. |
| Vex | 2 | Bonuslu/dönüşümlü sonuçlarda %25 ek sanal çip. | Ağırlıklı, yüksek varyanslı ×1 / ×2 / ×4 / ×8 / ×15. |
| Noctis | 3 | Her 12 normal dönüşte 3× bahis değerinde otomatik sandık. | Her güç turunda gerçek çip, ücretsiz dönüş veya Joker ödüllü kader çarkı. |
| Kael | 4 | Yıldırım salonunun sayacı iki kat hızlı dolar. | Beş uygun hücreyi Joker yapan yıldırım turları. |
| Seraphine | 5 | Görev, başarım ve seviye çip ödülleri %25 artar. | ×3 ve görünen mücevher başına ek çip. |
| Dante | 6 | Her dönüşte 13 XP ve 15 VIP puanı. | Asları Taç'a dönüştürür; ×3 uygular. |
| Orion | 7 | Kozmik salon sayacı iki kat hızlı dolar. | Joker makarası ve ağırlıklı kozmik çarpan; temel ×4. |

Normal dönüşte varsayılan 10 enerji, Luna'da 14; 10× ve üzeri sonuçta ek 5 enerji verilir. Görev ödülü 10 enerji verir. Güç dönüşleri enerji üretmez. Aktivasyon enerji tüketir ve üç ücretsiz güç dönüşü açar. Ücretsiz ve güç dönüşlerinde bahis, karakter ve salon kilitlenir; kayıt yeniden açıldığında da aynı kurallarla sürer. Kesin güç olasılıkları [SLOT_MATH.md](SLOT_MATH.md) içindedir.

## İlerleme ve meta oyun

- Genel seviye `1 + floor(XP / 120)`, karakter seviyesi `1 + floor(karakter XP / 90)` olarak hesaplanır. Normalde her dönüş 10 XP, Dante ile 13 XP verir.
- Salonlar sırasıyla 1–6. seviyelerde açılır. Genel seviye arttığında `2.500 × yeni seviye` çip verilir; Seraphine'in ödül çarpanı uygulanır. Bu ödül slot ödeme etiketiyle karıştırılmaz.
- Üç günlük görev, yerel UTC gününe göre yenilenir; yedi kalıcı başarım vardır. Ödüller tekrar alınamaz.
- Altın Salon 1+, Kraliyet Salonu 5+, Kozmik Saray 10+ seviye unvanları uygulanmıştır. Bunlar ortak lobideki ilerleme statüleridir; ayrı gezilebilir dünyalar veya ayrı VIP oda sahneleri değildir.
- Bahis basamakları seviyeye göre açılır. Çip biriktirerek milyon ve üzeri tutarlara ilerlemek mümkün olsa da rastgele büyük kazanç garanti edilmez.
- Bakiye 10.000 çipin altındaysa 25.000 ücretsiz toparlanma çipi alınır. Bekleme süresi, reklam ve ödeme yoktur.
- İmparatorluk Çerçevesi, Yıldız Tozu Aurası ve Tanrısal Işıltı sanal çiple alınabilir veya ilgili başarımlardan kazanılabilir. Sahip olunan kozmetik tekrar ücret alınmadan kuşanılır.

## Görsel ve ses uygulaması

Sekiz ayrı portre, altı salon illüstrasyonu, dikey saray, saydam semboller ve atlaslar kaynak projede bulunur. Üretim kayıtları [ART_NOTES.md](../assets/ART_NOTES.md) dosyasındadır. Portrelerin idle, giriş ve zafer hareketleri Tween/katman dönüşümleri ve prosedürel VFX kullanır; resmin içindeki eklemler ayrı animasyonlu değildir.

Güç efektleri yalnızca aynı animasyonun renk değiştirilmiş sürümleri değildir: Ares'in altın yağmuru, Luna'nın kırılmaları, Vex'in kartları, Noctis'in kader çarkı, Kael'in yıldırım zinciri, Seraphine'in kanat/ışık halkaları, Dante'nin kraliyet yüzeyi ve Orion'un kozmik çöküşü ayrı efekt çizim akışlarına sahiptir. Sinematik sunum, büyük portre, enerji halkaları ve gerçek makara dönüşümüyle bağlanır; yaklaşık 2,6 saniyelik sunum atlanabilir.

Kazanç kutlamaları gerçek ödeme oranına göre yoğunlaşır. Sınırlı boyutlu prosedürel parçacık havuzu, önceden yüklenen sembol dokuları ve tekrar kullanılan ses oynatıcıları kullanılır. Kaynak atlasları korunur; mevcut makaralar kesilmiş sembol dosyalarını yükler. Grafik profilleri VFX parçacık sayısını, arka plan ayrıntılarını ve aura shader'ını değiştirir. Azaltılmış hareket modunda güçlü parlama/sarsıntı yerine kısa, sade sunum kullanılır. 30/60 FPS sınırı uygulanır; telefon FPS'si ölçülmüş değildir.

Altı salon ambiyansı, dönüş başlangıcı/duruşu, kazanç, bonus, jackpot, karaktere özel hazır/güç sesleri özgün olarak sentezlenmiştir. Sesler çevrimdışı WAV kaynaklarıdır. Gerçek insan seslendirmesi, kahkaha kaydı, dudak senkronizasyonu veya stüdyo orkestra kaydı yapılmamıştır.

## Kalan sınırlar ve yayın öncesi işler

| Konu | Durum |
|---|---|
| Tam karakter skinleri | Kozmetikler çalışan aura ve çerçevelerdir. Yeni kostüm/yüz varyasyonları ve tam skin koleksiyonu yoktur. |
| İskelet ve 3D sinematik | Rigli karakterler, elle hazırlanmış eklem animasyonları, ayrı taht/el/çekiç poz çekimleri veya 3D kamera sahneleri yoktur. |
| Sanat kalitesi onayı | Dosyalar ve efektler oluşturuldu. Fiziksel telefon ekranında görsel değerlendirme bu belge hazırlanırken tamamlanmış değildir. |
| Mobil performans | 60 FPS hedeflenir; farklı Android GPU/CPU'larında profil, ısınma, bellek ve pil testleri yapılmış değildir. |
| Android doğrulaması | Güncel export, imza, paket ve cihaz/emülatör test sonucu [ANDROID.md](ANDROID.md) içinde tutulur. Masaüstü testleri Android testi sayılmaz. |
| Ekran/erişilebilirlik QA | Dikey ölçeklenebilir UI ve azaltılmış efektler var. Çok sayıda fiziksel telefon, güvenli alan, metin ölçekleme ve erişilebilirlik denetimi tamamlanmış değildir. |
| Ses kalite güvencesi | Sentezlenmiş sesler var; telefon hoparlöründe mix, gecikme ve tüm cihazların ses sürücüleri doğrulanmış değildir. |
| Uzun vadeli denge | Seed testleri ve büyük simülasyon yapıldı. Uzun süreli oyuncu testi, bütün karakter/salon kombinasyonlarının istatistiksel ekonomi dengelemesi ve ticari canlı operasyon yoktur. |
| Üretim yayını | Test APK'sı debug imzalıdır. Kullanıcı yayın anahtarı, mağaza işlemleri ve üretim sürümü QA ayrıca gereklidir. |

Kullanıcıya gerçek olmayan bir kazanç gösterilmez; sahte jackpot, gizli kayıp serisi veya zorunlu harcama mekaniği uygulanmamıştır. Açıklanan oyun içi olasılıklar ve gerçek hesap sonuçları incelenebilir durumdadır.
