# Slot motoru test raporu

Motor: Godot **4.6.3.stable.official.7d41c59c4**. Test: `tests/test_slot_engine.gd`. Çalıştırma tarihi: 8 Ekim 2026.

**600.319 kontrol, 100.002 simülasyon dönüşü, 0 hata.** Her salon için 16.667 bağımsız ücretli dönüş çalıştırılmıştır. Temel simülasyon bahsi 1.000 sanal çiptir. Her salonda farklı, sabit bir test seed'i kullanılmıştır; iki ayrı motor örneğiyle seed tekrarlanabilirliği ayrıca doğrulanmıştır.

Bu bir gerçek para oyunu değildir. Aşağıdaki getiriler, yalnızca belirtilen sabit seed'lerle elde edilen **örnek temel ücretli dönüş ödeme / bahis oranlarıdır**. Sertifikalı RTP, uzun vadeli kesin beklenti, kazanma olasılığı veya kazanç garantisi değildir. Kazanılan ücretsiz dönüşlerin sonraki ödülleri, kayıtlı bonus sayaçları, karakter güçleri/pasifleri, görevler, başarımlar ve seviye ödülleri bu temel simülasyona dahil değildir. Sanal servet büyümesine yönelik bazı salonların örnek getirisi %100'ün üzerindedir.

| Salon | Ücretli dönüş | Toplam bahis | Gerçek toplam ödeme | Örnek getiri | Verilen ücretsiz dönüş |
|---|---:|---:|---:|---:|---:|
| Altın İmparatorluğu | 16.667 | 16.667.000 | 12.797.705 | %76,7847 | 298 |
| Neon Kaosu | 16.667 | 16.667.000 | 19.384.645 | %116,3055 | 286 |
| Yıldırım Tanrıları | 16.667 | 16.667.000 | 13.639.023 | %81,8325 | 1.686 |
| Joker Çılgınlığı | 16.667 | 16.667.000 | 14.356.403 | %86,1367 | 530 |
| İmparatoriçenin Hazinesi | 16.667 | 16.667.000 | 29.238.644 | %175,4284 | 521 |
| Kozmik Sonsuzluk | 16.667 | 16.667.000 | 17.585.845 | %105,5130 | 200 |

## Bağımsız doğrulamalar

- Altı salonun JSON yapılandırmasının yüklenmesi; bilinmeyen kimlik ve dosya yolunun reddedilmesi.
- Sıfır/negatif bahis, yanlış grid, negatif ağırlık ve sınır dışı ödeme çizgisinin reddedilmesi.
- Bilinen Taç, tam Joker ve Joker ikamesi ödeme örneklerinin kesin tutarları.
- Soldan başlamayan kombinasyonun ödememesi ve en yüksek Joker ikamesinin seçilmesi.
- 3 / 4 / 5+ Bonus, ücretsiz dönüş ve toplam bahis temelli ödeme.
- Gerçek ödeme çarpanları ve gerçek ödül / bahis oranına bağlı kazanç etiketleri.
- Her salon için iki ayrı motorun 40 ardışık seed eşitliği kontrolü.
- Tam Taç fixture'ında 9 çizginin kesin 200× toplam ödemesi.
- Empress fixture'ında düşüşlerin 4'te durması ve toplam `1+2+3+4+5=15` çarpan muhasebesi.
- Cosmic fixture'ında doğal 5 Taç koşulu ve ek 1000× gerçek büyük ödül.
- Yıldırım sayacının gerçek 2 farklı Joker ve ücretsiz dönüş üretmesi.
- Kozmik sayacın gerçek Joker makarası ve 2× çarpan üretmesi.
- Sekiz karakterin hesaplanan gerçek etkileri ve Türkçe kural açıklamaları.
- Her simülasyon dönüşünde pozitif/negatif tutar güvenliği, gerçek kazanan çizgi toplamı, bonus ve cascade toplam muhasebesi, 5 sütunlu doğru makara boyutu, geçerli ücretsiz dönüş sayısı ve doğru kazanç etiketi.

Doğal kozmik büyük ödül, bu 100.002 temel dönüş örneğinde görülmemiştir. Bu durum hata olarak değerlendirilmemiştir; nadir koşul ayrı, deterministik bir fixture ile doğrulanmıştır. Aynı çıktı örneği, doğal büyük ödül olasılığını istatistiksel olarak doğrulamak için yeterli değildir.

Motor testi Android cihaz testi değildir. Dokunmatik hissi, GPU performansı, gerçek cihazdaki FPS, ses gecikmesi ve görsel kaliteyi ölçmez. Ayrı meta ve arayüz testleri `tools/run_tests.sh` tarafından çalıştırılır ve kendi çıktılarını üretir.

Son birleşik `tools/run_tests.sh` çalışması çıkış kodu 0 ile tamamlandı: motor 600.319 kontrol / 100.002 dönüş / 0 başarısızlık; meta 2.553 kontrol / 1.200 dönüş / 0 başarısızlık; `UI_SMOKE_PASS`. Arayüz testi gerçek makara animasyonunun tamamlandığını, gösterilen ve hesaplanan makara dizilerinin eşleşmesini, güç animasyonu ve bonus akışını da kontrol etti. Son loglar `dist/qa/engine.log`, `meta.log` ve `ui.log` dosyalarındadır. Headless arayüz kontrolü bir cihaz FPS veya görsel kalite ölçümü değildir.

Editor import aşamasında yönetilen test ortamı yerel TCP dinleme soketini engellediği için `ERR_CANT_CREATE` çıktısı oluştu. Import tamamlandı; offline motor, meta ve arayüz testlerinde betik hatası oluşmadı. Bu ortam çıktısı `dist/qa/import.log` dosyasında açıkça korunmuştur.

## Yeniden üretme

Proje kökünde `bash tools/run_tests.sh` çalıştırın. Godot bulunamazsa `GODOT_BIN=/tam/yol/godot bash tools/run_tests.sh` kullanılabilir. Betik her test için ayrı geçici kullanıcı verisi ve kayıt dizini oluşturur; kişisel oyun kaydını kullanmaz. Son loglar `dist/qa/` altında saklanır. Yalnızca motor testi için:

```bash
mkdir -p /tmp/godspin-engine/data /tmp/godspin-engine/config /tmp/godspin-engine/cache
XDG_DATA_HOME=/tmp/godspin-engine/data \
XDG_CONFIG_HOME=/tmp/godspin-engine/config \
XDG_CACHE_HOME=/tmp/godspin-engine/cache \
godot --headless --path . --script res://tests/test_slot_engine.gd
```
