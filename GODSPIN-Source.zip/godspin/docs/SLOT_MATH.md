# GODSPIN salon matematiği

Bu oyun yalnızca sanal çip kullanır. Gerçek para, satın alınabilir kumar kredisi, nakit çekim veya gerçek para ödülü yoktur. Oyun, uzun vadeli sanal servet büyümesi için tasarlanmıştır; bazı salonlarda örnek sanal çip getirisi bahis tutarını aşabilir.

## Hesaplama ve gösterim

`SlotEngine`, Godot `RandomNumberGenerator` ile ağırlıklı ve birbirinden bağımsız hücre çekilişleri yapar. `set_seed()` aynı yapılandırma ve çağrı sırasıyla sonucu yeniden üretir. RNG'nin animasyon RNG'sinden ayrı olması, görsel efektlerin sonucu değiştirmesini önler.

Sonuç önce tamamen hesaplanır, sonra `ReelController` tarafından gösterilir. Makara dizisi `grid[sütun][satır]` biçimindedir: 5 sütun, salona göre 3 veya 4 satır. `payout` gerçek toplam ödemedir; cascade salonunda bütün düşüş aşamalarını içerir. Oyun yöneticisi karakter pasiflerini ayrıca ekler ve bakiyeye gerçekten eklenebilen tutarı gösterir. Seviye ödülleri, slot kazancı dışında ayrı ilerleme ödülleridir.

## Semboller ve temel olasılıklar

Bütün salonların ayrı JSON dosyaları bulunur. Ortak temel sembol ağırlıkları toplam 100'dür; her hücredeki temel olasılık doğrudan ağırlıktır. Ulti, zincir ve genişleme etkileri çekilişten sonra belirtilen kurallarla sembolleri değiştirebilir.

| Kimlik | Türkçe ad | Ağırlık / temel olasılık | 3 sembol | 4 sembol | 5 sembol |
|---|---|---:|---:|---:|---:|
| `crown` | Taç | 8 / %8 | 20× | 75× | 200× |
| `gem` | Mücevher | 14 / %14 | 12× | 40× | 100× |
| `chalice` | Kadeh | 18 / %18 | 8× | 25× | 75× |
| `ring` | Yüzük | 24 / %24 | 5× | 15× | 40× |
| `ace` | As | 30 / %30 | 3× | 8× | 20× |
| `wild` | Joker | 4 / %4 | 25× | 100× | 250× |
| `scatter` | Bonus | 2 / %2 | ayrı kural | ayrı kural | ayrı kural |

Tablodaki sembol çarpanları **çizgi bahsine** uygulanır. Toplam sanal bahis bütün etkin çizgilere eşit bölünür. Kazançlar soldan sağa, ilk sütundan başlayarak en az 3 bitişik eşleşmeyle hesaplanır. Her çizgi yalnızca en yüksek geçerli eşleşmesini öder; her çizginin sonucu aşağı yuvarlanır. Joker, Bonus dışında her ödeme sembolünün yerine geçer. Baştaki Jokerler için bütün geçerli semboller denenir; en yüksek ödeme seçilir. Aynı hücre birden fazla ayrı çizgide kazanabilir.

3 satırlı salonlarda 9, 4 satırlı salonlarda 12 yatay ve zikzak ödeme çizgisi vardır. Kesin satır indeksleri her salonun JSON dosyasındaki `paylines` alanındadır.

Bonuslar çizgilerden bağımsızdır. İlk sonuçta herhangi bir yerde 3 / 4 / 5+ Bonus, toplam bahsin 2× / 10× / 25× kadarı ve 5 / 7 / 10 ücretsiz dönüş verir. Geçerli dönüş çarpanı Bonus çip ödemesine de uygulanır. Ücretsiz dönüş sayısı çarpanla büyümez. Jokerler Bonus yerine geçmez; güçler var olan Bonusları korur.

## Altı ayrı salon

| JSON / salon | Boyut | Özel mekanik |
|---|---|---|
| `data/slots/golden_empire.json` / Altın İmparatorluğu | 5×3 | Klasik ödeme, Joker, Bonus ve ücretsiz dönüş. |
| `data/slots/neon_chaos.json` / Neon Kaosu | 5×3 | Her doğal Joker, sağındaki Joker ve Bonus olmayan hücreyi %25 olasılıkla Joker yapar. En az bir yeni Joker oluşursa bu dönüşün temel ödemeleri 2× olur. Yeni oluşan Jokerler yeniden zincir başlatmaz. |
| `data/slots/gods_of_thunder.json` / Yıldırım Tanrıları | 5×4 | En az 2 Bonus veya dolu yıldırım sayacı, farklı 2 hücreyi Joker yapar ve 1 ek ücretsiz dönüş verir. 3+ Bonus klasik ödülünü ayrıca verir. Sayaç 10'da dolar; normal dönüş +1, Kael +2 ilerler. |
| `data/slots/joker_madness.json` / Joker Çılgınlığı | 5×3 | En az 2 Bonus, bir ağırlıklı ödül çarkını tetikler. Çarkın çip ödülü çizgi kazancına eklenir; çip ödülü dönüş çarpanından etkilenmez. Joker ödülü gerçek ödeme hesabına uygulanır. |
| `data/slots/empress_treasure.json` / İmparatoriçenin Hazinesi | 5×4 | Kazanan çizgi hücreleri çıkarılır; kalanlar aşağı iner ve üstten yeni ağırlıklı hücreler gelir. İlk dönüş 1×; en çok 4 sonraki düşüşte 2× / 3× / 4× / 5×. Ulti çarpanı bu çarpanla çarpılır. Bonus, düşüş aşamalarında yeniden ödemez ve ücretsiz dönüş başlatmaz. |
| `data/slots/cosmic_infinity.json` / Kozmik Sonsuzluk | 5×3 | Her doğal Joker %20 olasılıkla makarasını genişletir; doğal genişleme bir dönüşte en çok 1 makara. Bağımsız dönüş çarpanı: 1× %81,5; 2× %15; 3× %3; 5× %0,5. Kozmik sayaç 12'de ek Joker makarası ve 2× verir; normal dönüş +1, Orion +2. |

Kozmik büyük ödül, **ilk doğal çekilişte orta satırdaki beş hücrenin tamamı Taç** olduğunda ek 1000× toplam bahis öder. Joker ikamesi ve sonradan dönüştürülen Taçlar bu koşulu karşılamaz. Temel ağırlıklarda bu beş doğal Tacın olasılığı `0,08⁵ = 0,0000032768`, yani `%0,00032768`'dir. Bu, bütün sonuçların veya toplam kazanç seviyelerinin büyük ödül olasılığı değildir.

## Ödül çarkı

Joker salonunun çarkı ve Noctis'in her güç dönüşünde kullanılan kader çarkı aynı dağılımı kullanır. Ayrı iki tetikleme aynı dönüşte gerçekleşirse sonuçlar ayrı hesaplanır ve açıkça toplanır.

| Ödül | Olasılık |
|---|---:|
| 2× toplam bahis değerinde sanal çip | %40 |
| 5× toplam bahis değerinde sanal çip | %25 |
| 2 ücretsiz dönüş | %20 |
| 3 farklı Joker hücresi | %12 |
| 20× toplam bahis değerinde sanal çip | %3 |

## Oyun içindeki sekiz güç

Her aktivasyon 3 ücretsiz güç dönüşü açar, enerji tüketir ve aktivasyon bahsini sabitler. Aynı slotun temel özel mekanikleri de çalışır. Güç dönüşleri enerji üretmez. Güç sırasında karakter ve salon değiştirilemez. Olağan ücretsiz dönüşler de ödülü kazanan bahis ve salona bağlı kalır.

| Karakter | Her güç dönüşündeki gerçek mekanik |
|---|---|
| Ares | Sırasıyla 2× / 3× / 5× temel ödeme çarpanı. |
| Luna | Farklı, rastgele seçilmiş 2 makara Joker olur; Bonuslar korunur. |
| Vex | Bağımsız kaos çarpanı: 1× %45, 2× %30, 4× %15, 8× %8, 15× %2. |
| Noctis | Yukarıdaki dağılımla bir kader çarkı; çip/ücretsiz dönüş/Joker ödülü gerçekten uygulanır. |
| Kael | Farklı 5 uygun hücre Joker olur; Bonuslar korunur. Uygun hücre sayısı daha azsa mevcut hücreler kullanılır. |
| Seraphine | 3× temel ödeme; ilk görünen sonuçtaki her Mücevher ek 0,25× toplam bahis öder. Cascade ile sonradan doğan mücevherler ayrıca toplanmaz. |
| Dante | Bütün Aslar Taç olur; 3× temel ödeme. Doğal kozmik büyük ödül koşulunu bu dönüşüm tetiklemez. |
| Orion | Rastgele bir Joker makarası; temel 4× üzerine bağımsız 2× %65 / 3× %25 / 5× %9 / 10× %1. |

Güçler normal kazancı garanti etmez. Çizgi/Bonus ödemeleri salon ve güç çarpanlarını birlikte kullanır; çark, mücevher ve kozmik büyük ödül gibi ayrıca tanımlanmış doğrudan ödüller bu çarpanlarla yeniden çarpılmaz.

## Kazanç etiketleri

Etiketler gerçekten bakiyeye eklenen slot ve pasif ödülün toplam sanal bahse oranına göre belirlenir; seviye/görev ödülleri bu etikete eklenmez.

| Etiket | En düşük gerçek ödül / bahis oranı |
|---|---:|
| Güzel Kazanç | Pozitif ödeme |
| Büyük Kazanç | 5× |
| Dev Kazanç | 20× |
| Destansı Kazanç | 50× |
| Efsanevi Kazanç | 100× |
| Tanrısal Kazanç | 250× |
| Tanrısal Büyük Ödül | 1000× |

`PaytableManager.describe()` ödeme ve Bonus açıklamasını gerçek JSON alanlarından üretir. RNG çekilişleri, bakiye işlemleri ve görsel efektler birbirinden ayrıdır. İnceleme ve simülasyon sonuçları `ENGINE_TEST_REPORT.md` dosyasında bulunur.
