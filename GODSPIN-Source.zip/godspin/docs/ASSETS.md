# Görsel ve yazı tipi kaynakları

## Özgün vektör çizimleri

`assets/art/symbol_*.svg`, `app_icon.svg` ve `temple_bg.svg` bu proje için oluşturulmuş özgün SVG çizimleridir. Semboller metalik altın çerçeveler, ışık vurguları, işlenmiş mücevher yüzeyleri ve çizim katmanlarıyla hazırlanmıştır. SVG dosyalarında dış kaynak, filtre veya yazı tipi bağımlılığı yoktur; Godot SVG içe aktarıcısıyla kullanılabilir.

Semboller: taç, akuamarin mücevher, kadeh, yakut yüzük, mor as kartı, prizmatik Wild arması, güneş gözü Scatter. `temple_bg.svg` düşük maliyetli 2.5D tapınak mimarisi arka planıdır.

## Yazı tipleri

- `DejaVuSerif-Bold.ttf`: başlıklar; DejaVu / Bitstream Vera lisansları. Lisans ve telif metni: `docs/licenses/DejaVu-copyright.txt`.
- `NotoSans-Regular.ttf` ve `NotoSans-Bold.ttf`: Türkçe arayüz metinleri. SIL Open Font License 1.1. Lisans ve telif metni: `docs/licenses/Noto-copyright.txt`.

Yazı tipleri geliştirme ortamında kurulu özgün paketlerden kopyalanmıştır; Türkçe karakterleri destekler.

## Özgün arayüz metalleri

`assets/ui/metal_frame.svg` (256×256, ortası şeffaf) paneller için 24 piksel dokuz dilim marjıyla tasarlanmıştır. `gold_button.svg` ve `dark_button.svg` (256×96) 20 piksel dokuz dilim marjı kullanır. Parlatılmış altın yüzey, çift oyma kenar, köşe yüzeyleri ve koyu metal iç bevel katmanları özgün SVG çizimleriyle oluşturulmuştur. `logo_crest.svg` (240×240) güneş ve taç motifli imparatorluk armasıdır.

`GodspinLogo` kontrolü (`scripts/ui/logo_mark.gd`) armanın üzerinde gerçek yazı tipiyle gölgeli ve altın vurgulu logo başlığını çizer; metin resme gömülmez. Dört SVG Godot 4.6.3 `Image.load_svg_from_string` ile başarıyla rasterize edilmiş ve görüntüleri incelenmiştir. Bu asset incelemesi tam oyun ekranı görsel testi anlamına gelmez.
