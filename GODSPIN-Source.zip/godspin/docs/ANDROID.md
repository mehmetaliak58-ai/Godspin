# Android debug APK üretimi

Gerçek hedef dosya `dist/GODSPIN-EmpireOfFortune.apk`; başarılı doğrulamanın ardından aynı APK `dist/GODSPIN.apk` adına da kopyalanır. Paket adı `com.godspin.empireoffortune`, oyun dikey ve offline çalışır. Build betiği indirme yapmaz; eksik araç varsa hata kodu 2 ile durur ve sahte APK oluşturmaz.

## Bu oturumdaki gerçek durum

APK **oluşturulamadı**. Godot 4.6.3 ve Java 21 kurulu, Android SDK ve Android export template eksik. Kullanıcı ağ erişimini ve SDK lisansını onayladı; buna rağmen işletim ortamının ağ izin kuyruğu komutları başlatmadı. Varsayılan sandbox komutunun kesin hatası `curl: (7) Failed to connect to proxy port 8080`; ek ağ izni komutları yürütülmeden bekledi ve yeni kullanıcı mesajlarıyla iptal edildi. Bu durum bir GitHub, Google veya Godot indirme sunucusu hatası olarak raporlanmaz; dosya transferi başlamadı. Güvenlik katmanını, proxyyi veya TLS doğrulamasını aşan bir çözüm kullanılmadı.

`dist/qa/android-preflight.log` eksik dosyaları kaydeder. APK imzası, manifesti ve Android cihaz açılışı doğrulanmış değildir. Kaynak proje ve build altyapısı hazırdır. Kullanıcının SDK lisans kabulü 2026-10-08 tarihli açık talimata dayanır; bootstrap bu kabulü yalnızca `GODSPIN_ACCEPT_ANDROID_SDK_LICENSE=1` ayarıyla kullanır.

## Hazır GitHub Actions alternatifi

`.github/workflows/android.yml` yalnızca yerel dosya olarak oluşturuldu; GitHub'a gönderilmedi ve hiçbir uzak build çalıştırılmadı. Projeyi kendi GitHub deponuzun köküne koyduğunuzda Actions → **Build GODSPIN Android debug APK** → **Run workflow** ile manuel başlatılabilir. İlk başarılı çalışmada **GODSPIN-Android-debug** artifact'i iki APK adını ve indirilen araçların doğrulama kayıtlarını içerir. Şu an mevcut bir artifact veya indirme bağlantısı yoktur.

Workflow yalnızca birinci taraf `actions/checkout@v4` ve `actions/upload-artifact@v4`, resmi Google SDK araçları ve resmi Godot arşivinin yönlendirdiği Godot deposunu kullanır. Godot editörü ve template dosyaları yayımlanan SHA-512 listesiyle, Android CLI arşivi resmi SHA-256 değeriyle karşılaştırılır. Rastgele üçüncü taraf kurulum betiği kullanılmaz. Workflow, burada açıkça kabul edilmiş SDK lisansını kullanır; farklı bir kullanıcı lisansı kabul etmeden workflow'u çalıştırmamalıdır.

## Gerekli araçlar

- Godot **4.6.3 stable** Linux editörü.
- Aynı sürümün resmi Android export template dosyası `android_debug.apk`.
- OpenJDK 17 veya 21; bu ortamda `/usr/lib/jvm/java-21-openjdk-amd64` kullanılır.
- Android SDK `platform-tools`, `platforms;android-35`, `build-tools;35.0.1`.
- Python 3, `unzip` ve `sha256sum`.

Bu oturumda Godot ve Java mevcut; Android SDK ve export template ilk kontrolde yoktu. Kullanıcı Android SDK lisansını açıkça kabul etti. Ağ komutunun işletim ortamı izni tamamlanmadan indirme gerçekleşmiş sayılmaz. Gerçek build ve APK doğrulama sonucu ayrıca test raporunda yer almalıdır.

Tek komutla araçları kurmak için, açık SDK lisans kabulü sonrasında:

```bash
GODSPIN_ACCEPT_ANDROID_SDK_LICENSE=1 bash tools/bootstrap_android.sh
```

Bootstrap resmi Godot arşivinin yönlendirdiği depodan template paketini alır, yayımlanan SHA-512 ile karşılaştırır. Android CLI tools 15859902 paketini Google'dan alır ve resmi sayfanın SHA-256 değeri `4e4c464f145a7512b57d088ac6c278c03c9eea610886b35a5e0804e74eedf583` ile doğrular. Tüm lisanslar SDK'da saklanır; provenance ve hash dosyaları `/workspace/toolchain/downloads` içinde tutulur. Kısmi indirme tekrar çağrıldığında kaldığı yerden sürer; bağlantı ve aktarım zaman aşımı sınırlıdır. Sertifika doğrulaması korunur.

## Workspace içinde SDK kurulumu

Araçları yalnızca `/workspace/toolchain` içine kurabilirsiniz. İndirirken mevcut `HTTP_PROXY`, `HTTPS_PROXY` ve CA ayarlarını koruyun; TLS doğrulamasını kapatmayın.

Android command-line tools ZIP dosyasını Google'ın resmi Android Studio indirme sayfasından alın: <https://developer.android.com/studio#command-line-tools-only>. ZIP içindeki `cmdline-tools` klasörünü `/workspace/toolchain/android-sdk/cmdline-tools/latest` konumuna yerleştirin. Sonra:

```bash
export ANDROID_SDK_ROOT=/workspace/toolchain/android-sdk
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
export ANDROID_USER_HOME=/workspace/toolchain/android-user
mkdir -p "$ANDROID_USER_HOME"
"$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$ANDROID_SDK_ROOT" --licenses
"$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" --sdk_root="$ANDROID_SDK_ROOT" \
  'platform-tools' 'platforms;android-35' 'build-tools;35.0.1'
```

SDK lisansları kurulum sırasında gösterilir ve kabul edilmelidir. SDK manager proxy üzerinden bağlanamıyorsa Java proxy parametrelerini veya sdkmanager'ın `--proxy=http --proxy_host=proxy --proxy_port=8080` seçeneklerini kullanın; proxyyi devre dışı bırakmayın.

## Godot Android template kurulumu

Godot 4.6.3 export templates paketini resmi sürüm arşivinden alın. Resmi sayfanın template bağlantısı aşağıdaki Godot depolama adresine yönlendirir. SourceForge Godot'a bağlı değildir ve bu kurulumda kullanılmaz. Kaynaklar:

- <https://godotengine.org/download/archive/4.6.3-stable/>
- <https://godot-releases.nbg1.your-objectstorage.com/4.6.3-stable/Godot_v4.6.3-stable_export_templates.tpz>

İndirilen `Godot_v4.6.3-stable_export_templates.tpz` dosyası ZIP biçimindedir. Bootstrap SHA-512 kontrolünden sonra Android debug ve release template dosyalarını çıkarır. Elle çıkarma örneği:

```bash
mkdir -p /workspace/toolchain/xdg-data/godot/export_templates/4.6.3.stable
unzip -p /workspace/toolchain/downloads/Godot_v4.6.3-stable_export_templates.tpz \
  templates/android_debug.apk \
  > /workspace/toolchain/xdg-data/godot/export_templates/4.6.3.stable/android_debug.apk
unzip -p /workspace/toolchain/downloads/Godot_v4.6.3-stable_export_templates.tpz \
  templates/android_release.apk \
  > /workspace/toolchain/xdg-data/godot/export_templates/4.6.3.stable/android_release.apk
```

## Build ve doğrulama

```bash
cd /workspace/godspin
bash tools/build_android.sh
```

Alternatif yollar ortam değişkenleriyle seçilebilir: `GODOT_BIN`, `GODSPIN_TOOLCHAIN_ROOT`, `ANDROID_SDK_ROOT`, `JAVA_HOME`, `GODOT_TEMPLATE_DIR`, `GODSPIN_APK_PATH`. Betik Godot editor ayarlarını workspace içindeki ayrı XDG dizinlerine yazar, debug anahtarı üretir, proje importunu ve native APK exportunu çalıştırır. Gradle veya Android build template gerekmez. `apksigner` ile imzayı, `aapt` ile paket adı, açılış etkinliği, dikey yön ve ağ izinlerini; Python ZIP ve arm64 kitaplığını doğrular.

Verifier ayrıca gerçek proje payload'unu zorunlu tutar; yalnızca Godot template dosyasını oyun olarak kabul etmez. Standart native export'ta ana oyun sahnesini, sekiz karakter JSON kaydını, altı slotun 5×3/5×4 boyutlarını ve ödeme/ağırlık tablolarını okuyarak kontrol eder; texture içeriklerini sayar. Farklı bir export tek PCK kullanırsa yalnızca PCK başlığı kontrol edilir ve paket içi JSON'un doğrudan okunmadığı açıkça yazılır.

## Telefona kurulum

`dist/GODSPIN.apk` dosyasını Android telefona aktarın. Dosyaya dokunup telefonun ilgili dosya uygulaması için sunduğu bilinmeyen kaynaklardan yükleme iznini açın ve kurulumu tamamlayın. Oyun internet gerektirmez. ADB ile:

```bash
/workspace/toolchain/android-sdk/platform-tools/adb install -r dist/GODSPIN.apk
/workspace/toolchain/android-sdk/platform-tools/adb shell monkey -p com.godspin.empireoffortune 1
```

SDK emulator veya fiziksel cihaz bulunmazsa cihaz testi yapılmış olarak raporlanmaz. Debug APK test içindir; Play Store yayını için kullanıcının özel release keystore'u ve yayın ayarları gerekir. Release anahtarı projeye veya kaynak ZIP'ine eklenmemelidir.
