# GODSPIN test raporu

Tarih: **8 Ekim 2026**. Godot: **4.6.3.stable.official.7d41c59c4**. Bu belge çalıştırılmış motor, meta ve arayüz akış testlerinin kapsamını ve sınırlarını kaydeder.

## Sonuçlar

| Test | Sonuç | Kapsam |
|---|---|---|
| Bağımsız slot motoru | **600.319 kontrol; 100.002 simüle dönüş; 0 hata** | Altı salon, kesin ödeme fixture'ları, Bonus/Joker/çarpan/cascade, karakter güçleri ve sabit seed. |
| Meta sistemleri | **2.553 kontrol; 1.200 simüle dönüş; 0 hata** | Gerçek bakiye, enerji, XP, seviye ödülleri, kilitler, görev/başarım, kozmetik, ayarlar, kurtarma ve kayıt. |
| Arayüz akışı | **UI_SMOKE_PASS** | Lobi, karakter detay/seçim, salon, gerçek makara animasyonu, güç sinematiği, bonus dönüşü, bütün menüler, kurallar, geçmiş ve dört grafik profilinin uygulanması. |
| Android APK | Ayrı rapor | Export, imza ve paket kontrolünün güncel sonucu [ANDROID.md](ANDROID.md) içindedir. |
| Fiziksel cihaz/emülatör | Bu belge hazırlanırken doğrulanmış sonuç yok | Android raporunda ayrıca belirtilir; masaüstü headless testleri cihaz testi değildir. |
| Görsel inceleme | Bu belge hazırlanırken fiziksel görsel onay tamamlanmış değildir | Akış testlerinin başarılı olması premium sanat kalitesini veya telefon okunabilirliğini otomatik olarak kanıtlamaz. |

Motor simülasyonu her salon için 16.667 ücretli dönüş, toplam 100.002 dönüş kullanmıştır. Meta simülasyonu altı salon için 200'er gerçek oyun yöneticisi dönüşü içerir. İki simülasyon farklı katmanları doğrular; sayaçları tek bir aynı test gibi birleştirmiyoruz.

## Motor doğrulamaları

- Ağırlıklı gerçek RNG, sabit seed ile iki ayrı motorun aynı sonuçları üretmesi.
- Pozitif bahis, geçerli salon, doğru 5×3/5×4 makara, ağırlıklar ve ödeme çizgileri.
- İlk sütundan başlayan eşleşme, en yüksek Joker ikamesi ve kesin bilinen ödeme tutarları.
- Bonusların bağımsız çip/ücretsiz dönüş ödülü; güçler tarafından Bonusların korunması.
- Altı salonun ayrı mekanikleri; cascade ara aşamalarının toplamla eşleşmesi.
- Sekiz güç ve doğal kozmik büyük ödül koşulunun deterministik fixture'larla gerçek etkileri.
- Gerçek ödül/bahis oranı ile kazanç etiketlerinin tutarlılığı.
- Yıldırım ve kozmik ilerleme sayaçlarının gerçek Joker/ücretsiz dönüş/çarpan etkisi.

Ayrıntılı sonuçlar ve örnek getiri tablosu [ENGINE_TEST_REPORT.md](ENGINE_TEST_REPORT.md) içindedir. Örnek getiri, sertifikalı RTP veya uzun vadeli kazanç garantisi değildir. Doğal kozmik büyük ödül simülasyonda görülmemiş, ayrı fixture ile doğrulanmıştır; bu örnek nadir olayın olasılığını istatistiksel olarak doğrulamaz.

## Meta ve kayıt doğrulamaları

- Başlangıçta 100.000 çip, 500 bahis, açık Ares/Luna; kilitli ve bilinmeyen seçimlerin reddi.
- Her dönüşte `bakiye_sonra = bakiye_önce − ücret + gerçek_ödeme + ayrı_seviye_ödülü`.
- Normal enerji/XP kazanımı, enerji tüketimi ve Ares'in gerçek ×2/×3/×5 ücretsiz güç turları.
- Sekiz karakterin aktivasyonu, gerçek üç güç sonucu ve negatif ödeme/ücret güvenliği.
- Seraphine görev ve seviye ödül çarpanı; görevden 10 güç enerjisi.
- Günlük ve kalıcı ödüllerin iki kez alınamaması; tamamlanmayan görevin ödül vermemesi.
- Sıfır bakiyede ücretli dönüşün reddi; ücretsiz 25.000 çip toparlanma.
- Kozmetik satın alma, aynı ürünü ücret almadan kuşanma ve UI sahiplik/kuşanma alanları.
- Kalite, 30 FPS, azaltılmış hareket ve türü bozuk ayarların güvenli doğrulanması.
- Atomik kayıt, yeniden açılışta bakiye/ilerleme/ayar/kozmetik korunması.
- Bozuk ana dosyadan geçerli yedek geri yüklenmesi; geçersiz tür, kimlik ve sayı aralıklarının kurtarılması.
- Kısmi Ultimate yeniden açıldığında karakter, salon, bahis ve kalan turun korunması.
- Ücretsiz dönüşte bahis/salon/karakter kilidinin kayıt yüklenirken de sürmesi.
- Eski sürüm-1 kayıtlarının ücretsiz dönüş için sabit bahis ve salon alanlarına taşınması.
- Sabit seed ile iki tam oyun yöneticisinin eşit sonuçları ve altı salonda 1.200 dönüş boyunca gerçek muhasebe/sayaç/geçmiş sınırları.

Kayıt güvenliği, yerel dosyaya karşı doğrulama ve kurtarma anlamındadır. Bulut yedekleme, cihazlar arası senkronizasyon veya hileyi engelleyen sunucu sistemi değildir.

## Arayüz akışı

`--qa-smoke` başlangıç lobisini açar; karakter, salon, görev, profil, kozmetik, ayarlar, kurallar, ödeme tablosu ve geçmiş arayüzlerini çalıştırır. Gerçek bir dönüşün makara animasyonunu sonuna kadar bekler; gösterilen grid'in hesaplanan final grid'e eşit kaldığını denetler. Luna'nın gerçek gücünü açar, sinematik sunumu bekler ve bir bonus dönüşünü oynar. Dört grafik profilini sırayla uygular ve kayıt yapar.

Bu test UI düğüm/akış ve çalıştırma doğrulamasıdır. Tüm butonlara fiziksel parmakla basılmış, ekran görüntülerinin sanat kalitesi değerlendirilmiş veya bütün cihaz en-boy oranları test edilmiş gibi yorumlanmamalıdır.

## Yeniden çalıştırma

Proje kökünde:

```bash
bash tools/run_tests.sh
```

Godot farklı konumdaysa:

```bash
GODOT_BIN=/tam/yol/godot bash tools/run_tests.sh
```

Betik Linux geliştirme ortamında Bash, `rg`, `timeout` ve Godot kullanır. Varlıkları içe aktarır; motor, meta, UI, makara, VFX ve yerleşim testlerini çalıştırır. Her aşamada ayrı geçici kullanıcı-verisi, ayar, önbellek ve test-kayıt dizini kullanır. Kişisel oyun kaydını açmaz. Başarılı toplu çıktı `GODSPIN_QA_PASS` olur. Loglar `dist/qa/` altında kalır. Hata kodu, script/parser hatası veya beklenen başarı işaretinin eksikliği betiği başarısız kılar.

## Görsel yükseltme sonrası birleşik doğrulama

8 Ekim 2026 tarihinde son sürüm için `tools/run_tests.sh` başarıyla tamamlandı:

| Test | Gerçek sonuç |
| --- | --- |
| Slot matematiği | 600.319 kontrol, 100.002 simüle ücretli dönüş, 0 hata |
| Ekonomi / kayıt / meta | 2.553 kontrol, 1.200 oyun yöneticisi dönüşü, 0 hata |
| UI akışı | Gerçek dönüş, güç, bonus, önizleme ve menüler: `UI_SMOKE_PASS` |
| Makara sunumu | 16 kontrol, 0 hata; sonuç değişmezliği, doğal sonuç ve gerçek dönüşümler, duruş sırası, Turbo / normal süre |
| Sinematik VFX | Sekiz ayrı beş aşamalı güç, sekiz düşük / azaltılmış önizleme, yedi gerçek tutar seviyesi, güvenli skip; `VFX_UPGRADE_PASS` |
| Ekran / önizleme | 1.427 kontrol, altı pencere boyutu, sekiz tam süreli önizleme; 0 hata |

Son küçük erişilebilirlik düzenlemesinden sonra VFX ve UI akış testleri ayrıca tekrar geçti. Arka planın yumuşak katman ışıkları ve parallax hareketi gerçek dosyada bulunur; düşük ve azaltılmış modda sadeleşir.

Performans için doğrulanan yapısal sınırlar: makara başına toplam iki önbellekli stil, testte en fazla 50 görünür sembol çizimi; sinematikte 100 öğelik sabit parçacık havuzu ve tekrar kullanılan iki shader katmanı. Bunlar Android FPS veya bellek ölçümü değildir. Gerçek GPU ekran yakalama, cihaz / emülatör testi ve Android paket doğrulaması bu ortamda tamamlanmamıştır.

Android export komutu:

```bash
bash tools/build_android.sh
```

## Yayın öncesi gerekli QA

Gerçek Android cihazda kurulum/açılış, dokunmatik kontrol, uygulama arka plana alınıp geri dönünce kayıt, ses sürücüsü, ısınma/bellek/pil ve 30/60 FPS ölçümleri ayrıca yapılmalıdır. Farklı ekran oranlarında çerçeveler, güvenli alanlar ve okunabilirlik kontrolü; sekiz gücün ve yedi kutlama seviyesinin görsel incelemesi; uzun süreli ekonomi/oyuncu deneyimi testi bu raporun kapsamı dışındadır. Debug APK'nın üretilmesi bu kontrolleri tamamlanmış saydırmaz.
