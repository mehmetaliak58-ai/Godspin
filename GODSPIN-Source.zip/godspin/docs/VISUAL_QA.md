# Görsel kalite denetimi

`tools/capture_screenshots.sh` Godot 4.x ile gerçek 720×1280 ekran görüntülerini `dist/lobby.png` ve `dist/slot.png` dosyalarına kaydeder. Her çalıştırma için ayrı, geçici XDG kayıt dizinleri kullanır; mevcut oyuncu kaydına dokunmaz ve başlangıç karakteri Ares / 100.000 sanal çip ile açılır. Yazılım OpenGL / llvmpipe seçilir; GPU gerektirmez.

```bash
./tools/capture_screenshots.sh
```

Gereksinimler: Godot 4.x; çalışır X11 ekranı veya `Xvfb`, alternatif olarak `Xorg` + dummy ekran sürücüsü. Var olan ekran için `DISPLAY=:0` veya `GODSPIN_DISPLAY=:0`; farklı sanal ekran numarası için `GODSPIN_X_DISPLAY_NUMBER=95` kullanılabilir. `GODOT_BIN` alternatif Godot çalıştırılabilir dosyasını seçer.

Yönetilen çalışma alanı yerel X11 UNIX/abstract soketi oluşturulmasını engelliyorsa işlem hemen durur ve hata `dist/qa/display.log` dosyasında kalır. Yerel ekran soketi bağlantılarına izin veren bir ortamda aynı komut yeniden çalıştırılmalıdır. `--headless` Godot'un yalnızca dummy görüntü sürücüsünü destekler; `--display-driver headless --rendering-driver opengl3` kullanmak gerçek ekran görüntüsü sağlamaz. Görsel inceleme yapılmadan headless arayüz testi görsel kalite testi diye sunulmamalıdır.

Görsel denetim: her ekranı gerçek dosyadan açın; metin taşması, karakter kırpılması, buton erişimi, slot sembollerinin okunaklılığı, makara paylaşımları, altın/parlak efektlerin okunaklılığı ve ekran kenarlarını kontrol edin. Sonuçları test raporuna ayrı yazın.

Bu çalışma alanında 2026-10-08 tarihinde Xorg ve dummy sürücüsü bulundu; sandbox yerel X11 soketi açılışını reddetti. Godot 4.6.3 yardım çıktısı `headless (dummy)` desteğini doğruladı. Bu yüzden ekran görüntüsü incelemesi henüz tamamlanamadı; mevcut SVG varlıkların Godot rasterizasyon incelemesi başarıyla yapıldı.
