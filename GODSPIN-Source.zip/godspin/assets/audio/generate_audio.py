#!/usr/bin/env python3
"""Reproduce GODSPIN's original synthesised, royalty-free sound library.
No copyrighted samples, recorded voices, external dependencies beyond numpy.
"""
from pathlib import Path
import wave
import numpy as np

RATE=24000
OUT=Path(__file__).resolve().parent
RNG=np.random.default_rng(77296)

def write(name, y):
    y=np.nan_to_num(y)
    y=np.tanh(y*1.15)
    peak=max(float(np.max(np.abs(y))), .01)
    if peak>.82: y*=.82/peak
    pcm=np.clip(y*32767,-32767,32767).astype('<i2')
    with wave.open(str(OUT/(name+'.wav')), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE); w.writeframes(pcm.tobytes())

def time(seconds): return np.arange(round(seconds*RATE))/RATE

def env(t, attack=.015, decay=2):
    return np.minimum(t/max(attack,.0001),1)*np.exp(-t*decay)*np.minimum((t[-1]-t)/.05,1).clip(0,1)

def bell(t, f, decay=2):
    return (np.sin(2*np.pi*f*t)*.58 + np.sin(2*np.pi*f*2.01*t)*.24*np.exp(-t*3)+np.sin(2*np.pi*f*3.92*t)*.09*np.exp(-t*7))*env(t,.002,decay)

def add_note(y, offset, freq, duration=.5, gain=.2, kind='bell'):
    t=time(duration)
    if kind=='bell': n=bell(t,freq)*gain
    elif kind=='soft': n=(np.sin(2*np.pi*freq*t)+.16*np.sin(2*np.pi*freq*2*t))*env(t,.03,2)*gain
    else: n=(np.sin(2*np.pi*freq*t)+.3*np.sin(2*np.pi*freq*3*t))*env(t,.008,5)*gain
    start=round(offset*RATE)
    length=min(len(n),len(y)-start)
    if length>0:y[start:start+length]+=n[:length]

t=time(.13); write('click',bell(t,660,19)*.24+bell(t,1320,25)*.1)
t=time(.25); write('stop', bell(t,420,16)*.3+RNG.normal(0,.04,len(t))*env(t,.003,25))
t=time(.85); phase=2*np.pi*(90*t+180*t*t); write('spin',np.sin(phase)*env(t,.012,3)*.15+RNG.normal(0,.045,len(t))*env(t,.03,2))
for cue,notes,duration in [('win',[523.25,659.25,783.99,1046.5],1.0),('bonus',[392,523.25,659.25,783.99,1046.5],1.5),('jackpot',[261.63,329.63,392,523.25,659.25,783.99,1046.5],3.5)]:
    y=np.zeros(round(duration*RATE))
    for i,f in enumerate(notes): add_note(y,.075+i*.12,f,.8,.22)
    if cue=='jackpot':
        for f in [130.81,164.81,196,261.63]: add_note(y,1.05,f,2.35,.10,'soft')
    write(cue,y)

characters=['ares','luna','vex','noctis','kael','seraphine','dante','orion']
roots=[130.81,146.83,155.56,110,98,164.81,123.47,82.41]
# Impact times match VFX CHOREOGRAPHY's per-character 2.6 second sequences.
impact_times=[1.04,.91,.858,1.118,.988,1.066,1.092,1.144]
for index,(name,root) in enumerate(zip(characters,roots)):
    t=time(2.6); y=np.zeros_like(t)
    # Anticipation grows into each character's own impact moment.
    impact=impact_times[index]
    charge=np.sin(2*np.pi*(root*.4*t+40*t*t))*np.minimum(t/.8,1)*np.exp(-t*1.9)
    y+=charge*.13
    ti=np.maximum(0,t-impact); impact_mask=(t>=impact).astype(float)
    noise=RNG.normal(0,1,len(t))
    if name=='ares':
        for f in [root*2,root*3,root*4.01]:y+=bell(ti,f,1.4)*impact_mask*.21
        y+=np.sin(2*np.pi*54*ti)*np.exp(-ti*6)*impact_mask*.3
    elif name=='luna':
        phase=2*np.pi*root*ti+4*np.sin(2*np.pi*7*ti)
        y+=np.sin(phase)*env(ti,.02,1.2)*impact_mask*.23
        y+=np.sin(2*np.pi*root*6*ti+np.sin(2*np.pi*43*ti)*3)*np.exp(-ti*2)*impact_mask*.1
    elif name=='vex':
        for i in range(6):
            add_note(y,impact+i*.1,root*(1+i*.19),.25,.17,'sharp')
        y+=noise*np.exp(-ti*12)*impact_mask*.1
    elif name=='noctis':
        y+=(np.sin(2*np.pi*root*ti)+.4*np.sin(2*np.pi*(root*1.498)*ti))*env(ti,.02,1.4)*impact_mask*.18
        y+=np.sin(2*np.pi*root*3.01*ti)*np.exp(-ti*2)*(np.sin(2*np.pi*6*ti)*.5+.5)*impact_mask*.12
    elif name=='kael':
        rumble=np.convolve(noise,np.ones(80)/80,mode='same')
        y+=(rumble*1.5+noise*.05)*np.exp(-ti*2.4)*impact_mask
        y+=np.sin(2*np.pi*(root*5)*ti)*np.exp(-ti*8)*impact_mask*.25
    elif name=='seraphine':
        for i,step in enumerate([1,1.25,1.5,2,2.5,3]):add_note(y,impact+i*.12,root*step,.9,.16)
    elif name=='dante':
        for step in [1,1.25,1.5]:y+=(np.sin(2*np.pi*root*step*ti)+.15*np.sin(2*np.pi*root*step*3*ti))*env(ti,.016,1.5)*impact_mask*.16
        y+=bell(ti,root*4,1.8)*impact_mask*.18
    elif name=='orion':
        y+=np.sin(2*np.pi*(root*.6*ti-5*ti*ti))*np.exp(-ti*1.8)*impact_mask*.3
        y+=np.sin(2*np.pi*root*3*ti+6*np.sin(2*np.pi*.6*ti))*env(ti,.1,1.3)*impact_mask*.17
        y+=noise*.07*np.exp(-ti*3)*impact_mask
    write('ultimate_'+name,y)
    ready=np.zeros(round(.7*RATE))
    for i,step in enumerate([2,2.5,3]):add_note(ready,i*.12,root*step,.38,.18,'soft' if index in [1,3,7] else 'bell')
    write('ready_'+name,ready)

# Exact 12-second, periodic seamless loops at 80 bpm; calm under gameplay.
slots=['golden_empire','neon_chaos','gods_of_thunder','joker_madness','empress_treasure','cosmic_infinity']
roots=[130,146,98,155,164,82]
for k,(slot,root) in enumerate(zip(slots,roots)):
    duration=12.; t=time(duration); y=np.zeros_like(t)
    # Quantise oscillator frequency to a whole number of cycles over this loop.
    freqs=[round(root*step*duration)/duration for step in [0.5,1,1.25,1.5,2]]
    for j,f in enumerate(freqs):
        amplitude=.018 if j<2 else .008
        y+=np.sin(2*np.pi*f*t+np.sin(2*np.pi*(k+1)*t/duration)*.1)*amplitude
    # Sparse arpeggio, with circular note tails for a clean looping seam.
    for i in range(16):
        offset=i*.75
        note_t=np.mod(t-offset,duration)
        frequency=freqs[2+(i+k)%3]*2
        y+=bell(note_t,frequency,3)*.035
    if k in [1,3]:
        y+=np.sin(2*np.pi*freqs[0]*t)*(.008+.012*(np.sin(2*np.pi*8*t/duration)**8))
    if k==5:
        y+=np.sin(2*np.pi*freqs[0]*t+3*np.sin(2*np.pi*t/duration))*.015
    write('ambience_'+slot,y)

(OUT/'LICENSE.txt').write_text('GODSPIN original procedural sound library\nAll WAV files were synthesised for this project using generate_audio.py, without external samples.\nCopyright 2026 GODSPIN project contributors. Released under CC0 1.0 Universal.\nhttps://creativecommons.org/publicdomain/zero/1.0/\nNo recorded or AI-generated speech is included.\n',encoding='utf-8')
print('Generated',len(list(OUT.glob('*.wav'))),'original WAV files')
