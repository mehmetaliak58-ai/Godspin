# GODSPIN sanat kaynakları

Bu projedeki raster karakter, saray ve sembol görselleri 8 Ekim 2026 tarihinde OpenAI görsel üretim aracı ile GODSPIN için özgün olarak üretildi. Başka bir oyundan, sanatçı portföyünden veya stok kütüphanesinden alınmış görsel kullanılmadı. Üretim talimatları tanınabilir franchise karakterlerini dışladı ve yetişkin fantastik karakterleri istedi. Bu açıklama araç/provenans kaydıdır; üçüncü taraf haklarına ilişkin hukuki bir garanti değildir.

## Kullanılan dosyalar

- `art/ares.webp`, `luna.webp`, `vex.webp`, `noctis.webp`, `kael.webp`, `seraphine.webp`, `dante.webp`, `orion.webp`: 4×2 atlasın 443–444 piksel kare hücrelerinden kesilen portreler. WEBP kalite 94. Görseller altın / mor / elektrik mavisi / zümrüt temalı yarı gerçekçi 2.5D koleksiyon kahramanı stilindedir.
- `art/characters_atlas.webp`: 1774×887 piksel karakter atlası, kalite 93. Satır sırası: Ares, Luna, Vex, Noctis; Kael, Seraphine, Dante, Orion.
- `art/casino_palace.webp`: 941×1672 piksel dikey casino-fantasy saray arka planı, kalite 92. Ortadaki boş alan arayüz okunabilirliği için tasarlandı.
- `art/symbol_crown.png`, `symbol_gem.png`, `symbol_joker.png`, `symbol_lightning.png`, `symbol_moon.png`, `symbol_coin.png`, `symbol_wild.png`, `symbol_scatter.png`: 443–444 piksel kare, alfa saydamlığı olan lüks slot sembolleri. Satır sırası bu listedeki sırayla eşleşir.
- `art/symbol_chalice.png`, `symbol_ring.png`, `symbol_ace.png`: 444×444 piksel alfa saydamlıklı ödeme tablosu sembolleri, üçlü atlastan küçültülerek kare hücrelere ortalanmıştır.
- `art/symbols_atlas.png`, `art/symbols_extra_atlas.png`: kayıpsız saydam orijinal sembol atlasları.
- `art/slot_golden_empire.webp`, `slot_neon_chaos.webp`, `slot_gods_of_thunder.webp`, `slot_joker_madness.webp`, `slot_empress_treasure.webp`, `slot_cosmic_infinity.webp`: 512×512 piksel ayrı salon illüstrasyonları, WEBP kalite 92. Altın saray, neon kristal casino, yıldırım tapınağı, joker tiyatrosu, mücevher kasası ve kozmik portal birbirinden farklı ortamlar içerir. `art/slots_atlas.webp` bunların 1536×1024 piksel atlasıdır.

## Üretim kaydı

Aracın orijinal çıktıları geliştirme çalışma alanında korunmuştur:

- Karakterler: `/workspace/generated_images/exec-8b75da0f-5991-4b19-92fd-9e8ac2ac603f.png`
- Saray: `/workspace/generated_images/exec-dd687b6c-de26-489c-a46f-a4855c1eb929.png`
- Ana semboller: `/workspace/generated_images/exec-f048a51f-79fa-4340-9f08-7748a4cbb4b8.png`
- Ek semboller: `/workspace/generated_images/exec-e45a15f2-7c0e-4b40-bc46-e81c457c6afa.png`
- Salonlar: `/workspace/generated_images/exec-9413fcca-7058-4f9e-980c-0b2d474ab603.png`

İşleme yalnızca atlas hücrelerini kesme, oranı koruyarak küçültme, saydam karelere ortalama ve WEBP/PNG olarak kaydetmeden oluşur. Karakterler el ile çizilmiş veya üç boyutlu riglenmiş gibi sunulmamıştır. Oyundaki idle, seçim ve güç hareketleri Godot katmanları, Tween ve VFX ile bu illüstrasyonlara uygulanır.

## Sanat yönü ve sınırlamalar

Karakter yüzleri ve kostümler ayrı üretilmiş parçalar yerine tek tutarlı atlastan gelir. Portreler tam vücut animasyon sprite sheet'i değildir; ayrı iskelet animasyonu veya dudak senkronizasyonu içermez. Arka plan statik bir raster sahnedir; oyun çalışma zamanında sis, ışık ve parçacık katmanlarıyla canlandırılır. Sembol atlasları kayıpsız alfa saklar. Görsel üretim sonuçları ayrıca telefon üzerindeki arayüz ve GPU performans kontrolüne tabidir.
